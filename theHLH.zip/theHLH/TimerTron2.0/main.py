from fastapi import FastAPI, Request, Header, HTTPException
from fastapi.responses import JSONResponse
import os
import logging
from mysql_crud import MySQLCRUD

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = FastAPI()
webhook_map = dict()
secret = ""
ASANA_TOKEN_TT_V2 = os.environ.get('ASANA_TOKEN_TT_V2')
TARGET_PROJECT_GIDS = os.environ.get('TARGET_PROJECT_GIDS').split(',')
WEBHOOK_RECEIVE_ENDPOINT = os.environ.get('WEBHOOK_RECEIVE_ENDPOINT')
PROJECT_WEBHOOK_CREATE_ENDPOINT = os.environ.get('PROJECT_WEBHOOK_CREATE_ENDPOINT')
WEBHOOK_REQUESTS_TABLE_NAME = 'webhook_requests'
WEBHOOK_TABLE_NAME = 'webhooks'
WEBHOOK_TASKS_TABLE_NAME = 'webhook_tasks'

@app.post("/receiveWebhook")
async def receive_webhook(
    request: Request,
    x_hook_secret: str = Header(None),
    x_hook_signature: str = Header(None),
):
    global secret
    if x_hook_secret:
        logger.info("This is a new webhook")
        body = await request.body()
        logger.info(f'---body------: {body}')
        logger.info('request json:')
        logger.info(await request.json())
        secret = x_hook_secret
        return JSONResponse(content={}, headers={"X-Hook-Secret": secret}, status_code=200)
    elif x_hook_signature:
        body = await request.body()
        response = await request.json()
        print(response)
        if response['events']:
            create_entry_in_db(response)
        return JSONResponse(content={}, status_code=200)
    else:
        raise HTTPException(status_code=400, detail="Something went wrong!")

def create_entry_in_db(response):
    events = response['events']
    mysql = MySQLCRUD()
    for event in events:
        data = dict()
        task_id = event['resource']['gid']
        timestamp_parts = event['created_at'].split("T")
        condition = {
            'task_id': event['resource']['gid'],
            'action': event['action'],
            'user_id': event['user']['gid']
        }
        entry_exists = mysql.entry_exists(WEBHOOK_TASKS_TABLE_NAME, condition)
        parent_key = 'parent_' + event['parent']['resource_type'] + '_id'
        missing_keys = {'parent_section_id', 'parent_task_id', 'parent_project_id'} - {parent_key}
        if entry_exists:
            print(f'updating the entry for task id: {task_id}')
            mysql.update_record(WEBHOOK_TASKS_TABLE_NAME, {parent_key: event['parent']['gid'], 'faulty': 0}, condition)
        else:
            print(f'adding new entry for task id: {task_id}')
            data['event_timestamp'] = timestamp_parts[0] + ' ' + timestamp_parts[1][:-5]
            data['action'] = event['action']
            data['user_id'] = event['user']['gid']
            data[parent_key] = event['parent']['gid']
            data['task_id'] = event['resource']['gid']
            for missing_key in missing_keys:
                data[missing_key] = 'NA'
            mysql.insert_record(WEBHOOK_TASKS_TABLE_NAME, data)

def create_webhook_entry_in_db(resource_id, x_hook_secret):
    mysql = MySQLCRUD()
    exists = mysql.entry_exists(WEBHOOK_TABLE_NAME, {'resource_id': resource_id})
    if exists:
        mysql.update_record(WEBHOOK_TABLE_NAME, {'x_hook_secret': x_hook_secret}, {'resource_id': resource_id})
    else:
        mysql.insert_record(WEBHOOK_TABLE_NAME, {'resource_id': resource_id, 'x_hook_secret': x_hook_secret})

@app.post("/serverStatus")
async def server_status(
    request: Request
):
    return JSONResponse(content={'status': 'live'}, status_code=200)

def create_webhook_request_for_project(project_gid: str):
    mysql_obj = MySQLCRUD()
    try:
        mysql_obj.insert_record(table_name=WEBHOOK_REQUESTS_TABLE_NAME, data = {'resource_id': project_gid, 'resource_type': 'project'})
    except Exception as e:
        print(e)

def check_and_load_existing_webhooks():
    '''
    retrieve data from the database about the existing webhooks
    '''
    logger.info("Starting check_and_load_existing_webhooks")
    mysql_obj = MySQLCRUD()
    for project_gid in TARGET_PROJECT_GIDS:
        logger.info(f'Checking webhook existence for {project_gid}')
        webhooks = mysql_obj.select_records(table_name=WEBHOOK_TABLE_NAME, conditions={'resource_id': project_gid})
        if not webhooks:
            logger.info(f'No webhook found for {project_gid}')
            webhook_request = mysql_obj.execute_query(f"select * from {WEBHOOK_REQUESTS_TABLE_NAME} where resource_id='{project_gid}'")
            if not webhook_request:
                create_webhook_request_for_project(project_gid)
            else:
                print('webhook creation request already submitted..')
        # else:
            # for webhook in webhooks:
            #     resource_id = webhook['resource_id']
            #     x_hook_secret = webhook['x_hook_secret']
                # X_HOOK_SECRET_MAP[resource_id] = x_hook_secret
    logger.info("Completed check_and_load_existing_webhooks")

def insert_webhook_record(data: dict):
    '''
    insert data into table about the webhook created
    '''
    mysql_obj = MySQLCRUD()
    mysql_obj.insert_record('webhook', data)

@app.on_event("startup")
async def startup_event():
    check_and_load_existing_webhooks()

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8080)
