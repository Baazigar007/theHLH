import time
from mysql_crud import MySQLCRUD
import asana
import os
import requests
import json

WEBHOOK_REQUESTS_TABLE_NAME = 'webhook_requests'
TIMESTAMP_FORMAT = '%Y-%m-%d %H:%M:%S'
WEBHOOK_RECEIVE_ENDPOINT = os.environ.get('TIMERTRON_BASE_URL') + 'receiveWebhook'
WEBHOOK_X_SECRET_ENDPOINT = os.environ.get('TIMERTRON_BASE_URL') + 'getSecretMap'
ASANA_TOKEN_TT_V2 = os.environ.get('ASANA_TOKEN_TT_V2')
WEBHOOK_TABLE_NAME = 'webhooks'
WEBHOOK_PROCESSED = {}

def create_webhook_on_project(resource_id: str):
    print(f'creating webhook on project with resource id: {resource_id}')
    configuration = asana.Configuration()
    configuration.access_token = ASANA_TOKEN_TT_V2
    api_client = asana.ApiClient(configuration)
    webhooks_api_instance = asana.WebhooksApi(api_client)
    body = {
        "data": {
            "resource": resource_id,
            "target": WEBHOOK_RECEIVE_ENDPOINT,
            "filters": [
                {
                    "resource_type": "task",
                    "action": "added"
                }
            ]
        }
    }
    api_response = webhooks_api_instance.create_webhook(body)
    print(api_response)
    print('webhook creation on project completed')

    mysql = MySQLCRUD()
    mysql.update_record(table_name=WEBHOOK_REQUESTS_TABLE_NAME, data={'status': 'completed'}, conditions={'resource_id': resource_id})

    insert_webhook_details_in_db(api_response, resource_id, 'project', mysql)

def insert_webhook_details_in_db(api_response, resource_id, resource_type, mysql: MySQLCRUD):
    webhook = {
        'webhook_id': api_response.data.gid,
        'resource_id': resource_id,
        'resource_type': resource_type,
        'created_at': api_response.data.created_at.strftime('%Y-%m-%d %H:%M:%S')
    }
    mysql = MySQLCRUD()
    exists = mysql.entry_exists(WEBHOOK_TABLE_NAME, {'resource_id': resource_id})
    if exists:
        mysql.update_record(WEBHOOK_TABLE_NAME, webhook, {'resource_id': resource_id})
    else:
        mysql.insert_record(WEBHOOK_TABLE_NAME, webhook)
    print('entry added!')

def create_webhook_on_task(resource_id: str):
    print(f'creating webhook on task with resource id: {resource_id}')

def create_webhook(webhook_requests: list[dict]):
    print('processing request...')
    for webhook_request in webhook_requests:
        resource_id = webhook_request['resource_id']
        resource_type = webhook_request['resource_type']

        if resource_type == 'project':
            create_webhook_on_project(resource_id)
        else:
            create_webhook_on_task(resource_id)

def check_webhook_requests():
    print('checking.....')
    mysql = MySQLCRUD()
    response = mysql.execute_query(f"select max(created_at) as last_completed_value_date from {WEBHOOK_REQUESTS_TABLE_NAME} where status='completed'")
    last_completed_value_date = None
    try: 
        last_completed_value_date = response[0]['last_completed_value_date']
    except:
        print('no completed request found')
    if last_completed_value_date:
        last_completed_value_date = last_completed_value_date.strftime(TIMESTAMP_FORMAT)
        print(f'last_completed_value_date: {last_completed_value_date}')
        webhook_requests = mysql.execute_query(f"select * from {WEBHOOK_REQUESTS_TABLE_NAME} where status='pending' and created_at > '{last_completed_value_date}'")
        if webhook_requests:
            print(f'found {len(webhook_requests)} new requests')
            create_webhook(webhook_requests)
        else:
            print('no new request found')
    else:
        print('trying to retrieve all pending requests')
        webhook_requests = mysql.select_records(table_name=WEBHOOK_REQUESTS_TABLE_NAME)
        if webhook_requests:
            print(f'found {len(webhook_requests)} requests in pending state')
            create_webhook(webhook_requests)
        else:
            print('no requests found')

if __name__ == '__main__':

    while True:
        check_webhook_requests()
        time.sleep(10)
