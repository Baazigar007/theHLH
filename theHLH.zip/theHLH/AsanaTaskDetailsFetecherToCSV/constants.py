ASANA_ACCESS_TOKEN = "" #provide the access token

AFFINITY_PRODUCT_CATEGORIES_API_ENDPOINT = "https://api.affinitygateway.com/product_categories"
AFFINITY_CLIENTS_API_ENDPOINT = "https://api.affinitygateway.com/clients"