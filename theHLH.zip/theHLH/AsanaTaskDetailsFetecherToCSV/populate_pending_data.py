import requests
import asana
from constants import *
from concurrent.futures import ThreadPoolExecutor
import pandas

CLIENTS_MAP = {}
PRODUCT_CATEGORIES_MAP = {}
SOURCE_DB_DATA = []

SRC_COLUMN_INDEX_MAP = {
    'TaskLink': 0,
    'UPI': 1,
    'title': 2,
    'category': 3,
    'client': 4
}

def collect_product_categories_data():
    response = requests.get(AFFINITY_PRODUCT_CATEGORIES_API_ENDPOINT)
    json_data  = response.json()['data']
    for data in json_data:
        PRODUCT_CATEGORIES_MAP[int(data['id'])] = data
    print('product categories initialized!')

def collect_client_data():
    response = requests.get(AFFINITY_CLIENTS_API_ENDPOINT)
    json_data = response.json()['data']
    for data in json_data:
        CLIENTS_MAP[int(data['id'])] = data
    print('client data collected!')

def get_task_data_from_asana(task_gid):
    try:
        configuration = asana.Configuration()
        configuration.access_token = ASANA_ACCESS_TOKEN
        api_client = asana.ApiClient(configuration)
        tasks_api_instance = asana.TasksApi(api_client)
        api_response = tasks_api_instance.get_task(task_gid=task_gid)
        task_data = api_response.data
        tags = [tag.name for tag in task_data.tags]
        parent_data = None
        if task_data.parent:
            parent_data = tasks_api_instance.get_task(task_data.parent.gid).data        
        return {
            'AffinityStatus': ';'.join(tags),
            'ParentTaskTitle': task_data.parent.name if task_data.parent else None,
            'ParentCreatedAt': parent_data.created_at if parent_data else None
        }
    except Exception as e:
        print(f'failure for {task_gid}')
        return {}
    

def process_data(data):
    task_gid = data['TaskLink']
    try:
        int(task_gid)
    except:
        print(f'skipping {task_gid}')
        return

    print(f'processing {task_gid}')
    asana_data = get_task_data_from_asana(task_gid)
    data.update(asana_data)
    try:
        data['Sorority'] = CLIENTS_MAP[int(data['client'])]['name']
    except:
        print(f'failure for client: {data["client"]}')
        data['Sorority'] = None
    try:
        data['ProductCategory'] = PRODUCT_CATEGORIES_MAP[int(data['category'])]['name']
    except:
        print(f'failure for product: {data["category"]}')
        data['ProductCategory'] = None

def read_task_links_from_csv(input_csv_name):
    df = pandas.read_csv(input_csv_name)
    for row in df.itertuples():
        data = dict(
            TaskLink = row.TaskLink,
            UPI = row.UPI,
            title = row.title,
            category = row.category,
            client = row.client
        )
        SOURCE_DB_DATA.append(data)

def main():
    input_csv_name = input('please provide the csv file name in the following format name.csv: ')
    read_task_links_from_csv(input_csv_name)
    collect_product_categories_data()
    collect_client_data()

    # Use ThreadPoolExecutor for parallel processing
    with ThreadPoolExecutor() as executor:
        executor.map(process_data, SOURCE_DB_DATA)

    df = pandas.DataFrame(SOURCE_DB_DATA)
    df.to_csv('output.csv')
    
if __name__ == '__main__':
    main()
