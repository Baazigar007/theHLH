const router = require("express").Router();
const asyncHander = require("express-async-handler");
const multer = require("multer");
const { protect } = require("./middlewares/authMiddleware");
const Sorority = require("./models/sorority");
const College = require("./models/college");
const isAdmin = require("./middlewares/adminMiddleware");
const {
  getUsersList,
  getUser,
  createUser,
  updateUser,
  getProfile,
  sendPassordToMail,
} = require("./controller/userController");
const { loginUser } = require("./controller/loginController");
const {
  getTaskList,
  getTask,
  createTask,
  updateTask,
  deleteTask,
  updatePriorities,
} = require("./controller/taskController");
const {
  createSubmission,
  getSubmission,
  getSubmissionByLoggedInUser,
  getSubmissionByTaskId,
  getSubmissionMetricsByTaskId,
  getSubmissionByUserId,
  updateSubmission,
  getSubmissionByTaskIdForLoggedInUser,
  getSubmissionByTaskIdAndStatus,
  getAllSubmission,
} = require("./controller/submissionController");

const storage = multer.memoryStorage();
const upload = multer({ storage: storage });

// const { getAuth, getTokenData } = require("./controller/getQBOToken");
// router.get("/callback", handleCallback);
// getOBO Token
// router.get("/auth", getAuth);
// router.get("/getToken", getTokenData);

router.get(
  "/",
  asyncHander(async (request, response) => {
    response.send("Welcome to HLH backend App");
  })
);

router.get(
  "/sororities",
  asyncHander(async (request, response) => {
    const sororities = await Sorority.find();
    response.status(200).json(sororities);
  })
);

router.get(
  "/colleges",
  asyncHander(async (request, response) => {
    const colleges = await College.find();
    response.status(200).json(colleges);
  })
);

router.post("/register", createUser);

router.put("/users/:userId", protect, updateUser);

router.post("/login", loginUser);

router.get("/users", protect, isAdmin, getUsersList);

router.get("/users/:email/forgotpassword", sendPassordToMail);

router.get("/users/:userId", protect, getUser);

router.get("/tasks", protect, getTaskList);

router.get("/tasks/:taskId", getTask);

router.post("/tasks", protect, isAdmin, createTask);

router.put("/tasks/priority", protect, isAdmin, updatePriorities);

router.put("/tasks/:taskId", protect, isAdmin, updateTask);

router.delete("/tasks/:taskId", protect, isAdmin, deleteTask);

router.get("/profile", protect, getProfile);

router.post(
  "/tasks/:taskId/submit",
  protect,
  upload.array("images", 10),
  createSubmission
);

// submission by submission id
router.get("/submission/:submissionId", protect, getSubmission);

// submissions by current logged in user
router.get("/submissions", protect, getSubmissionByLoggedInUser);

// submissions by given userId
router.get("/user/:userId/submissions", protect, getSubmissionByUserId);

// submissions by given taskId
router.get(
  "/task/:taskId/submissions",
  protect,
  isAdmin,
  getSubmissionByTaskId
);

// fetching submission metrics
router.get(
  "/task/:taskId/submissionMetrics",
  protect,
  isAdmin,
  getSubmissionMetricsByTaskId
);

router.get(
  "/task/:taskId/:status/submissionsFilteredByStatus",
  protect,
  isAdmin,
  getSubmissionByTaskIdAndStatus
);

// submission of user for a taskId
router.get(
  "/task/:taskId/submission",
  protect,
  getSubmissionByTaskIdForLoggedInUser
);

// update submission by Admin
router.put("/submission/:submissionId", protect, isAdmin, updateSubmission);
router.get("/task/submissions", getAllSubmission);

// router.get("/callback");
// router.get(
//   "/callback",
//   asyncHander(async (req, res) => {
//     const oauthClient = new OAuthClient({
//       clientId: process.env.clientId,
//       clientSecret: process.env.clientSecret,
//       environment: process.env.environment,
//       redirectUri: process.env.redirectUri,
//     });

//     const oauthCode = req.query.code;
//     console.log("OauthCode: ", oauthCode);
//     if (!oauthCode) {
//       res.status(400).send("No authorization code found in the callback URL");
//       return;
//     }
//     const url = req.protocol + "://" + req.get("host") + req.originalUrl;
//     console.log("URL: ", url);
//     try {
//       const authResponse = await oauthClient.createToken(url);
//       console.log("Token obtained successfully!");
//       console.log("The Token is " + JSON.stringify(authResponse));
//       res.send("Token Generated Successfully");
//       tokenData = authResponse; // Store the token data as needed
//     } catch (error) {
//       console.error("The error message is: " + error.message);
//       console.error(error.intuit_tid);
//       res.status(500).send("Failed to obtain token");
//     }
//   })
// );

module.exports = router;
