const asyncHander = require("express-async-handler");
const { ObjectId } = require("mongodb");
const User = require("../models/user");
const Submission = require("../models/submission");
const nodemailer = require('nodemailer');

// Get Users List
module.exports.getUsersList = asyncHander(async (request, response) => {
  const users = await User.find({isAdmin: false}).select("-password");
  for (let user of users) {
    const rewards = await getRewards(user._doc._id);
    user._doc = {...user._doc, ...rewards};
  }
  response.status(200).json(users);
});

// forget password
module.exports.sendPassordToMail = asyncHander(async (request, response) => {
  const user = await User.findOne({email: request.params.email});
  if(user){
    let transporter = nodemailer.createTransport({
        service: 'gmail',
        auth: {
            user: 'technical@thehangloosehut.com', // Your email address
            pass: process.env.GMAIL_PASSWORD // Your email password or an app-specific password if using Gmail
        }
    });

    let mailOptions = {
        from: 'technical@thehangloosehut.com', // Sender address
        to: request.params.email, // Recipient address
        subject: 'Forgot Password Support', // Email subject
        text: 'Here is your password: ' + user.password // Email body
    };

    transporter.sendMail(mailOptions, (error, info) => {
        if (error) {
            console.error('Error occurred:', error);
            response.status(400);
            throw new Error("Invalid email!");
        } else {
            console.log('Email sent:', info.response);
            response.status(200).json({email: request.params.email});
        }
    });
  }
  else{
    response.status(400);
    throw new Error("No such user exists");
  }
});

// Get User
module.exports.getUser = asyncHander(async (request, response) => {
  if (
    request.user.isAdmin == false &&
    request.user._id != request.params.userId
  ) {
    throw new Error("Not Authorized");
  }

  const user = await User.findOne({
    _id: new ObjectId(request.params.userId),
  }).select("-password");

  const rewards = await getRewards(request.params.userId); 
  response.status(200).json({ ...user._doc, ...rewards });
});

// Create User
module.exports.createUser = asyncHander(async (request, response) => {
  const userExists = await User.findOne({ email: request.body.email });

  if (userExists) {
    response.status(400);
    throw new Error("User already exists");
  }

  const user = await User.create({
    name: request.body.name,
    email: request.body.email,
    password: request.body.password,
    phoneNumber: request.body.phoneNumber,
    college: request.body.college,
    sorority: request.body.sorority,
    paypalId: request.body.paypalId,
    tiktokId: request.body.tiktokId,
    instagram: request.body.instagram,
    vemoId: request.body.vemoId,
  });
  response.status(200).json(user);
});

// Update User
module.exports.updateUser = asyncHander(async (request, response) => {
  if (request.user._id != request.params.userId) {
    response.status(401);
    throw new Error("Not Authorized");
  }

  const user = await User.findOneAndUpdate(
    { _id: new ObjectId(request.params.userId) },
    {
        name: request.body.name,
        email: request.body.email,
        password: request.body.password,
        phoneNumber: request.body.phoneNumber,
        college: request.body.college,
        sorority: request.body.sorority,
        paypalId: request.body.paypalId,
        tiktokId: request.body.tiktokId,
        instagram: request.body.instagramId,
        vemoId: request.body.vemoId,
    },
    { new: true }
  ).select("-password");

  response.status(200).json(user);
});

// get profile of logged in user
module.exports.getProfile = asyncHander(async (request, response) => {
  const rewards = await getRewards(request.user._doc._id);
  response.status(200).json({ ...request.user._doc, ...rewards });
});

const getRewards = asyncHander(async (userId) => {
  const submissions = await Submission.find({
    userId: new ObjectId(userId),
  }).populate("taskId");

  let total_earned = 0,
    balance = 0, unreviewed_balance = 0;
  for (let submission of submissions) {
    if (
      submission._doc.status == "Accepted" ||
      submission._doc.status == "PartiallyAccepted"
    ) {
      if (submission._doc.payment_status == "Unpaid") {
        balance += submission.reward;
      } else {
        total_earned += submission.reward;
      }
    } else if (submission._doc.status == "Pending"){
        if (submission.taskId != null)
            unreviewed_balance += submission.taskId.amount;
    }
  }
  return { total_earned, balance, unreviewed_balance };
});
