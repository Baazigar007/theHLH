const asyncHander = require("express-async-handler");
const { ObjectId } = require("mongodb");
const AWS = require("aws-sdk");
const Submission = require("../models/submission");
const Task = require("../models/task");
const convert = require("heic-convert");
const moment = require("moment-timezone");

const wasabiConfig = {
  endpoint: "https://s3.wasabisys.com",
  accessKeyId: "54BS931IBDSGXXGVV5BX",
  secretAccessKey: "eoDAVfRzgzjETvla8WTaOJCvMqhUC8jKjqAVy5qt",
  region: "us-east-1", // Update with your Wasabi region
};
const wasabiBucketName = "hlhimageuploadsdev";

const s3 = new AWS.S3(wasabiConfig);

// get submission given taskId
module.exports.getSubmissionByTaskId = asyncHander(
  async (request, response) => {
    const submissions = await Submission.find({
      taskId: request.params.taskId,
    }).populate("taskId");

    await attachImagesToSubmission(submissions);
    response.status(200).json(submissions);
  }
);

module.exports.getSubmissionByTaskIdAndStatus = asyncHander(
  async (request, response) => {
    const submissions = await Submission.find({
      taskId: new ObjectId(request.params.taskId),
      status: request.params.status
    }).populate("taskId");

    await attachImagesToSubmission(submissions);
    response.status(200).json(submissions);
  }
);

// metrics for submissions by status
const asyncHandler = require('express-async-handler');

module.exports.getSubmissionMetricsByTaskId = asyncHandler(async (request, response) => {
  const statusMetrics = await Submission.aggregate([
    {
      '$match': {
        'taskId': new ObjectId(request.params.taskId)
      }
    }, {
      '$group': {
        '_id': '$status', 
        'count': {
          '$sum': 1
        }
      }
    }
  ]);

  const formattedMetrics = {
    "PartiallyAccepted": 0,
    "Accepted": 0,
    "Pending": 0,
    "Rejected": 0,
    "TotalSubmissions": 0
  };

  let totalSubmissions = 0;

  statusMetrics.forEach(({ _id, count }) => {
    const modifiedId = _id.replace(' ', '');
    formattedMetrics[modifiedId] = count;
    totalSubmissions += count;
  });

  formattedMetrics["TotalSubmissions"] = totalSubmissions;

  response.status(200).json(formattedMetrics);
});


// get submission for task by current user
module.exports.getSubmissionByTaskIdForLoggedInUser = asyncHander(
  async (request, response) => {
    const submission = await Submission.findOne({
      taskId: request.params.taskId,
      userId: request.user._id,
    }).populate("taskId");

    const imageUrls = await fetchImagesFromWasabi(submission._id);
    submission._doc = { ...submission._doc, imageUrls };
    response.status(200).json(submission._doc);
  }
);

// get submission given user Id
module.exports.getSubmissionByUserId = asyncHander(
  async (request, response) => {
    const submissions = await Submission.find({
      userId: request.params.userId,
    }).populate("taskId");

    await attachImagesToSubmission(submissions);
    response.status(200).json(submissions);
  }
);

// get submissions of logged in user
module.exports.getSubmissionByLoggedInUser = asyncHander(
  async (request, response) => {
    const submissions = await Submission.find({
      userId: request.user._id,
    }).populate("taskId");

    await attachImagesToSubmission(submissions);
    response.status(200).json(submissions);
  }
);

// get submission
module.exports.getSubmission = asyncHander(async (request, response) => {
  const submission = await Submission.findOne({
    _id: new ObjectId(request.params.submissionId),
  }).populate("taskId");

  if (submission == null) {
    response.status(404).json({ message: "Submission not found" });
  }
  const imageUrls = await fetchImagesFromWasabi(submission._id);
  response.status(200).json({ ...submission._doc, imageUrls });
});

// update submission
module.exports.updateSubmission = asyncHander(async (request, response) => {
  const submission = await Submission.findOneAndUpdate(
    { _id: request.params.submissionId },
    {
      user_comment: request.body.user_comment,
      review_comment: request.body.review_comment,
      reward: request.body.reward,
      status: request.body.status,
      payment_status: request.body.payment_status,
    },
    { new: true }
  ).populate("taskId");
  response.status(200).json(submission);
});

// Create Submission
module.exports.createSubmission = asyncHander(async (request, response) => {
  const files = request.files;

  if (!files || files.length === 0) {
    res.status(400).send("No files uploaded.");
  }

  const task = await Task.findById(request.params.taskId);

  if (!task) {
    return response.status(404).json({ error: "Task not found" });
  }

  // Get the current date in PST without the time
  // const currentDateInPST = moment().tz("America/Los_Angeles").startOf("day");

  // Convert the task deadline to PST without the time
  // const taskDeadlineInPST = moment(task.deadline)
  //   .tz("America/Los_Angeles")
  //   .startOf("day");

  /**
   * If a task is expired people will not be able to upload in it.
   */
  // Compare the dates
  // if (currentDateInPST.isAfter(taskDeadlineInPST)) {
  //   console.log(currentDateInPST, taskDeadlineInPST);
  //   return response
  //     .status(404)
  //     .json({ error: "Task deadline has already passed" });
  // }

  // Convert each file to JPEG
  const convertedImages = await Promise.all(
    files.map(async (file) => {
      const splittedFileName = file.originalname.split('.');
      if (file.mimetype === "image/heic" || splittedFileName[splittedFileName.length-1] == 'HEIC' ) {
        // Handle HEIC conversion
        const data = await convert({ buffer: file.buffer, format: "JPEG" });
        console.log(data);
        file.buffer = data;
        file.mimetype = "image/jpeg";
        file.originalname = splittedFileName.slice(0, -1).join('.') + '.jpg'
      }
      console.log(file)
      return file;
    })
  );

  const submission = await Submission.findOneAndUpdate(
    { userId: request.user._id, taskId: new ObjectId(request.params.taskId) },
    {
      taskId: new ObjectId(request.params.taskId),
      userId: request.user._id,
      user_comment: request.body.user_comment,
    },
    { new: true, upsert: true }
  ).populate("taskId");

  const imageCount = await getFileNamesInFolder(submission._id);
  if (imageCount.length + convertedImages.length > 10) {
    throw new Error("Cannot upload more than 10 files for a submission");
  }

  const uploadPromises = convertedImages.map((file) => {
    const params = {
      Bucket: wasabiBucketName,
      Key: `${submission._id}/${Date.now()}_${file.originalname}`,
      Body: file.buffer,
      ContentType: file.mimetype,
      ACL: "public-read", // Adjust the ACL as needed
    };

    // Return a promise for each upload
    return new Promise((resolve, reject) => {
      s3.upload(params, (err, data) => {
        if (err) {
          console.error(err);
          reject(`Error uploading file ${file.originalname}`);
        } else {
          resolve(data.Location);
        }
      });
    });
  });

  // Wait for all uploads to complete before responding
  Promise.all(uploadPromises)
    .then(async (imageUrls) => {
      imageUrls = await fetchImagesFromWasabi(submission._id);
      response.status(200).json({ ...submission._doc, imageUrls });
    })
    .catch(async (error) => {
      if (imageCount == 0) {
        const ack = await Submission.deleteOne({ _id: submission._id });
      }
      response.status(500).send(`Error uploading files: ${error}`);
    });
});

const fetchImagesFromWasabi = async (submissionId) => {
  try {
    const fileNames = await getFileNamesInFolder(submissionId);
    const images = [];
    for (let fileName of fileNames) {
      const objectKey = `${submissionId}/${fileName}`;
      const presignedUrl = await s3.getSignedUrlPromise("getObject", {
        Bucket: wasabiBucketName,
        Key: objectKey,
        Expires: 3600, // URL expiration time in seconds (adjust as needed)
      });
      images.push(presignedUrl);
    }
    return images;
  } catch (error) {
    return [];
  }
};

const getFileNamesInFolder = async (folderPath) => {
  try {
    const data = await s3
      .listObjectsV2({
        Bucket: wasabiBucketName,
        Prefix: `${folderPath}/`,
      })
      .promise();

    const fileNames = data.Contents.filter(obj => !obj.Key.endsWith('/'))
                                    .map(obj => obj.Key.replace(`${folderPath}/`, ""));
    return fileNames;
  } catch (error) {
    console.error("Error getting file names in folder:", error);
    return [];
  }
};


const attachImagesToSubmission = asyncHander(async (submissions) => {
  for (let submission of submissions) {
    const imageUrls = await fetchImagesFromWasabi(submission._id);
    submission._doc = { ...submission._doc, imageUrls };
  }
});
