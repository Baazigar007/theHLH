const asyncHander = require("express-async-handler");
const jwt = require("jsonwebtoken");
const User = require("../models/user");

const generateToken = (id) => {
  return jwt.sign({ id }, "process.env.JWT_SECRET", {
    expiresIn: "30d",
  });
};

module.exports.loginUser = asyncHander(async (request, response) => {
  const user = await User.findOne({
    email: request.body.email,
    password: request.body.password,
  }).select("-password");
  if (!user) {
    response.status(401);
    throw new Error("InValid Credentials");
  }
  response.status(200).json({ ...user._doc, token: generateToken(user._id) });
});
