const asyncHander = require("express-async-handler");
const { ObjectId } = require("mongodb");
const Task = require("../models/task");
const Submission = require("../models/submission");
const moment = require("moment-timezone");

// Get All Tasks
module.exports.getTaskList = asyncHander(async (request, response) => {
  const currentDateInPST = moment().tz("America/Los_Angeles").startOf("day");
  let tasks;

  if (request.query.expired == "true") {
    tasks = await Task.find({
      $expr: {
        $lt: [
          {
            $dateFromParts: {
              year: { $year: "$deadline" },
              month: { $month: "$deadline" },
              day: { $dayOfMonth: "$deadline" },
              timezone: "America/Los_Angeles",
            },
          },
          currentDateInPST.toDate(),
        ],
      },
    }).populate("assignedTo");
  } else if (request.query.expired == "false") {
    tasks = await Task.find({
      $expr: {
        $gte: [
          {
            $dateFromParts: {
              year: { $year: "$deadline" },
              month: { $month: "$deadline" },
              day: { $dayOfMonth: "$deadline" },
              timezone: "America/Los_Angeles",
            },
          },
          currentDateInPST.toDate(),
        ],
      },
    }).populate("assignedTo");
  } else {
    tasks = await Task.find().populate("assignedTo");
  }

  if (request.user.isAdmin == false) {
    tasks = tasks.filter(
      (task) =>
        task.type == "BULK" ||
        (task.assignedTo != null &&
          task.assignedTo._id.toString() == request.user._id.toString())
    );
  }

  response.status(200).json(tasks);
});

// Get A Task
module.exports.getTask = asyncHander(async (request, response) => {
  const task = await Task.findOne({
    _id: new ObjectId(request.params.taskId),
  }).populate("assignedTo");
  response.status(200).json(task);
});

// Create Task
module.exports.createTask = asyncHander(async (request, response) => {
  const highestPriority = await Task.aggregate([
    {
      $group: {
        _id: null,
        maxField: { $max: "$priority" },
      },
    },
  ]);
  console.log(highestPriority);
  const tasks = await Task.create({
    name: request.body.name,
    description: request.body.description,
    amount: request.body.amount,
    deadline: request.body.deadline,
    assignedTo:
      request.body.type == "INDIVIDUAL" ? request.body.assignedTo : null,
    type: request.body.type != null ? request.body.type : "BULK",
    priority: highestPriority[0].maxField + 1,
  });
  response.json(tasks);
});

// Update Task
module.exports.updateTask = asyncHander(async (request, response) => {
  const task = await Task.findOneAndUpdate(
    { _id: new ObjectId(request.params.taskId) },
    {
      name: request.body.name,
      description: request.body.description,
      amount: request.body.amount,
      deadline: request.body.deadline,
      assignedTo:
        request.body.type == "INDIVIDUAL" ? request.body.assignedTo : null,
      type: request.body.type != null ? request.body.type : "BULK",
    },
    { new: true }
  );
  response.json(task);
});

// Delete Task
module.exports.deleteTask = asyncHander(async (request, response) => {
  const submissions = await Submission.countDocuments({
    taskId: request.params.taskId,
  });
  if (submissions == 0) {
    const task = await Task.deleteOne({ _id: request.params.taskId });
    console.log(task);
    response.status(200).json({ message: "Task Deleted Successfully." });
  } else {
    response.status(400).json({
      message: "Submissions Exist for this task, Task Deletion failed.",
    });
  }
});

// Update Task Priority
module.exports.updatePriorities = asyncHander(async (request, response) => {
  console.log(request.body);
  const bulkOperations = request.body.map((update) => ({
    updateOne: {
      filter: { _id: new ObjectId(update._id) },
      update: { $set: { priority: update.priority } },
    },
  }));

  const result = await Task.bulkWrite(bulkOperations);
  response.json({
    success: true,
    message: `${result.modifiedCount} tasks updated successfully.`,
  });
});
