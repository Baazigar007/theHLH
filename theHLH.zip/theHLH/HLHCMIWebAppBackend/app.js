const express = require("express");
const winston = require("winston");
const fs = require("fs");
const cors = require("cors");
const helmet = require("helmet");
const compression = require("compression");
const { errorHandler } = require("./middlewares/errorMiddleware");
const OauthClient = require("intuit-oauth");
const dotenv = require("dotenv");
const asyncHander = require("express-async-handler");
const databaseConnection = require("./databaseConnection");
const constants = require("./constants");
const { request } = require("https");
dotenv.config();

const logDir = "winston_logs";
if (!fs.existsSync(logDir)) {
  fs.mkdirSync(logDir);
}

winston.add(new winston.transports.Console());
const app = express();
app.use(express.json());
app.use(cors());
app.use(helmet());
app.use(compression());

function logRequest(req, res, next) {
  winston.info(`[${process.pid}]: Request received: ${req.url}`);
  next();
}
app.use(logRequest);
app.use("/api", require("./routes"));
app.use(errorHandler);

const oauthClient = new OauthClient({
  clientId: process.env.clientId,
  clientSecret: process.env.clientSecret,
  environment: process.env.environment,
  redirectUri: process.env.redirectUri,
});
let tokenData;
let authUri;

const getTokenData = () => {
  return new Promise((resolve, reject) => {
    app.get("/callback", async (req, res) => {
      const oauthCode = req.query.code;
      if (!oauthCode) {
        res.status(400).send("No authorization code found in the callback URL");
        reject("No authorization code found");
        return;
      }
      // const url = req.url;
      const url = req.protocol + "://" + req.get("host") + req.originalUrl;
      try {
        const authResponse = await oauthClient.createToken(url);
        // console.log("Token obtained successfully!");
        // console.log("The Token is " + JSON.stringify(authResponse));
        console.log();
        res.send("Token Genreated Successfully");
        resolve(authResponse);
      } catch (error) {
        console.error("The error message is: " + error.message);
        console.error(error.intuit_tid);
        reject(error);
      }
    });
  });
};

// automatically genrated url with help of `authUri` to redirect the users
app.get("/auth", async (req, res) => {
  authUri = oauthClient.authorizeUri({
    scope: [OauthClient.scopes.Accounting, OauthClient.scopes.OpenId],
    state: "testState",
  });
  // console.log("URL: ", authUri);

  res.json({
    message: "URL Genreated Successfully",
    url: authUri,
  });
});

app.get("/getToken", async (req, res) => {
  const tokenExpiry = 3600;
  try {
    tokenData = await getTokenData();
    // console.log("TokenData: ", tokenData);
    res.json({
      message: "Token Data Genreated Successfully",
      token: tokenData,
      expiry: tokenExpiry,
    });
  } catch (error) {
    console.log("Error: ", error.message);
  }
});

app.listen(constants.PORT, () => {
  console.log(`Server started on port: ${constants.PORT}`);
});

// handling rejected promises
process.on("unhandledRejection", (ex) => {
  throw ex;
});

//Graceful shutdown
process.on("SIGINT", function () {
  server.close(() => {
    winston.info(`[${process.pid}]: Server closed mode on port ${port}...`);
    sleep(100).then(() => {
      process.exit(0);
    });
  });
});

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}
