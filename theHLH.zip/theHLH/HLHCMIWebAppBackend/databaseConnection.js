const mongoose = require('mongoose');
const winston = require("winston");

const options = {
    readPreference: 'secondary',
    useNewUrlParser: true,
    useUnifiedTopology: true,
};

mongoose.connect("mongodb+srv://hlh_backend:hlh_backend_password@cluster0.lw7wbg8.mongodb.net/HLH_APP?retryWrites=true&w=majority", options).then(() => winston.info('Connected to MongoDb...'));

module.exports.closeMongoDBConnection = function () {
    return mongoose.disconnect();
};
