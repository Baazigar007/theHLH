const asyncHander = require('express-async-handler');


module.exports = asyncHander((request, response, next)=>{
    if (request.user.isAdmin != true) {
        throw new Error("UnAuthorized");
    } 
    next();
});
