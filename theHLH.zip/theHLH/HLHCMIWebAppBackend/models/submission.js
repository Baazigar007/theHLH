const mongoose = require("mongoose");
const moment = require("moment-timezone");

const getCurrentTimeInTimeZone = (timeZone) => moment().tz(timeZone).toDate();
const SubmissionSchema = new mongoose.Schema(
  {
    taskId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Tasks",
    },
    userId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Users",
    },
    user_comment: {
      type: String,
    },
    review_comment: {
      type: String,
    },
    reward: {
      type: Number,
      default: 0,
    },
    status: {
      type: String,
      required: true,
      default: "Pending",
    },
    payment_status: {
      type: String,
      required: true,
      default: "Unpaid",
    },
    createdAt: {
      type: Date,
      default: () => getCurrentTimeInTimeZone("America/Los_Angeles"), // Default to current time in PST
    },
    updatedAt: {
      type: Date,
      default: () => getCurrentTimeInTimeZone("America/Los_Angeles"), // Default to current time in PST
    },
  },
  {
    timestamps: true,
  }
);

const Submission = mongoose.model("Submission", SubmissionSchema);
module.exports = Submission;
