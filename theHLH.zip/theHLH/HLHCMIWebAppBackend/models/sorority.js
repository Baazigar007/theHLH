const mongoose = require("mongoose");

const SororitySchema = new mongoose.Schema(
  {
    text: {
        type: String,
    }
  },
  { timestamps: false }
);

const Sorority = mongoose.model("sorority", SororitySchema, 'sorority');
module.exports = Sorority;
