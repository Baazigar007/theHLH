const mongoose = require("mongoose");
const moment = require("moment-timezone");

const getCurrentTimeInTimeZone = (timeZone) => moment().tz(timeZone).toDate();
const TaskSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: true,
    },
    description: {
      type: String,
      required: String,
    },
    amount: {
      type: Number,
      required: true,
      default: 0,
    },
    deadline: {
      type: Date,
      required: true,
      default: () => getCurrentTimeInTimeZone("America/Los_Angeles"),
    },
    priority: {
      type: Number,
      default: 0,
    },
    assignedTo: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Users",
      select: "-password",
    },
    type: {
      type: String,
      enum: ["BULK", "INDIVIDUAL"],
      default: "BULK",
    },
    createdAt: {
      type: Date,
      default: () => getCurrentTimeInTimeZone("America/Los_Angeles"), // Default to current time in PST
    },
    updatedAt: {
      type: Date,
      default: () => getCurrentTimeInTimeZone("America/Los_Angeles"), // Default to current time in PST
    },
  },
  { timestamps: true }
);

const Task = mongoose.model("Tasks", TaskSchema);
module.exports = Task;
