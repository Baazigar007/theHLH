const mongoose = require("mongoose");
const moment = require("moment-timezone");

const getCurrentTimeInTimeZone = (timeZone) => moment().tz(timeZone).toDate();
const UserSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: true,
    },
    email: {
      type: String,
      required: [true, "Please add an email"],
      unique: true,
      trim: true,
      lowercase: true,
    },
    password: {
      type: String,
      required: true,
    },
    phoneNumber: {
      type: String,
      require: true,
    },
    college: {
      type: String,
      required: true,
    },
    sorority: {
      type: String,
    },
    paypalId: {
      type: String,
    },
    tiktokId: {
      type: String,
    },
    instagram: {
      type: String,
    },
    vemoId: {
        type: String,
    },
    isAdmin: {
      type: Boolean,
      default: false,
    },
    createdAt: {
      type: Date,
      default: () => getCurrentTimeInTimeZone("America/Los_Angeles"), // Default to current time in PST
    },
    updatedAt: {
      type: Date,
      default: () => getCurrentTimeInTimeZone("America/Los_Angeles"), // Default to current time in PST
    },
  },
  { timestamps: true }
);

const User = mongoose.model("Users", UserSchema, "users");
module.exports = User;
