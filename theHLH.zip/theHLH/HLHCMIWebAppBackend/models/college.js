const mongoose = require("mongoose");

const CollegeSchema = new mongoose.Schema(
  {
    name: {
        type: String,
    }
  },
  { timestamps: false }
);

const College = mongoose.model("college", CollegeSchema);
module.exports = College;
