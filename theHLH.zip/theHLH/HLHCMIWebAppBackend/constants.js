const PORT = process.env.PORT || 8080;
const MONGODB_URI = "mongodb+srv://hlh_backend:hlh_backend_password@cluster0.lw7wbg8.mongodb.net/?retryWrites=true&w=majority";

module.exports = {
    'PORT': Object.freeze(PORT),
    'MONGODB_URI': Object.freeze(MONGODB_URI)
}
