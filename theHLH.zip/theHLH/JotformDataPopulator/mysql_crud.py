import mysql.connector
from typing import Dict, Optional, Any, List
from datetime import datetime
import os

class MySQLCRUD:
    def __init__(self, 
                 mysql_host: str = None,
                 mysql_user: str = None,
                 mysql_pwd: str = None,
                 database: Optional[str] = None):
        """
        Initialize MySQLCRUD with a connection to the specified database.
        """
        self.connection = mysql.connector.connect(
            host=mysql_host or os.environ.get('MYSQL_HOST'),
            user=mysql_user or os.environ.get('MYSQL_USER'),
            password=mysql_pwd or os.environ.get('MYSQL_PWD'),
            database=database or os.environ.get('DATABASE')
        )
        self.cursor = self.connection.cursor(dictionary=True)

    def create_table(self, table_name: str, columns: str):
        """
        Create a table with the specified columns.
        """
        create_table_query = f"CREATE TABLE IF NOT EXISTS {table_name} ({columns})"
        self.execute_query(create_table_query)

    def insert_record(self, table_name: str, data: Dict[str, Any]):
        """
        Insert a record into the specified table.
        """
        columns = ', '.join(data.keys())
        values = ', '.join(['%s'] * len(data))
        insert_query = f"INSERT INTO {table_name} ({columns}) VALUES ({values})"
        self.execute_query(insert_query, tuple(self._convert_value(value) for value in data.values()))

    def select_records(self, table_name: str, conditions: Optional[Dict[str, Any]] = None) -> List[Dict[str, Any]]:
        """
        Select records from the specified table based on the given conditions.
        """
        where_clause, values = self._build_where_clause(conditions)
        select_query = f"SELECT * FROM {table_name} {where_clause}"
        return self.execute_query(select_query, values)

    def update_record(self, table_name: str, data: Dict[str, Any], conditions: Optional[Dict[str, Any]] = None):
        """
        Update records in the specified table based on the given conditions.
        """
        set_clause = ', '.join(f"{key} = %s" for key in data.keys())
        where_clause, where_values = self._build_where_clause(conditions)
        update_query = f"UPDATE {table_name} SET {set_clause} {where_clause}"
        self.execute_query(update_query, tuple(self._convert_value(value) for value in data.values()) + where_values)

    def delete_records(self, table_name: str, conditions: Optional[Dict[str, Any]] = None):
        """
        Delete records from the specified table based on the given conditions.
        """
        where_clause, values = self._build_where_clause(conditions)
        delete_query = f"DELETE FROM {table_name} {where_clause}"
        self.execute_query(delete_query, values)

    def execute_query(self, query: str, values: Optional[tuple] = None) -> Optional[List[Dict[str, Any]]]:
        """
        Execute a query and return the result if applicable.
        """
        self.cursor.execute(query, values)
        # Fetch all results if the query returns rows
        if self.cursor.with_rows:
            result = self.cursor.fetchall()
            return result
        self.connection.commit()

    def _build_where_clause(self, conditions: Optional[Dict[str, Any]]) -> (str, tuple): # type: ignore
        """
        Build a WHERE clause from the given conditions and return it with the values.
        """
        if conditions:
            where_conditions = [f"{key} = %s" for key in conditions.keys()]
            values = tuple(conditions.values())
            return f"WHERE {' AND '.join(where_conditions)}", values
        return "", ()

    def _convert_value(self, value: Any) -> Any:
        """
        Convert values to a suitable format for SQL queries.
        """
        if value is None:
            return None
        elif isinstance(value, datetime):
            return value
        else:
            return str(value)
        
    def entry_exists(self, table_name: str, conditions: Optional[Dict[str, Any]]) -> bool:
        """
        Check if an entry exists in the specified table based on the given conditions.
        """
        where_clause, values = self._build_where_clause(conditions)
        select_query = f"SELECT 1 FROM {table_name} {where_clause} LIMIT 1"
        self.cursor.execute(select_query, values)
        result = self.cursor.fetchone()
        return bool(result)