import requests
import asana
from datetime import datetime, timedelta
from mysql_crud import MySQLCRUD
import os
import time

ITEMS_FIELD_ID = os.environ.get('ITEMS_FIELD_ID')
HANGLOOSEHUT_WORKSPACE_ID = os.environ.get('HANGLOOSEHUT_WORKSPACE_ID')
NEW_CUSTOMER_INQUIRY_PROJECT_ID = os.environ.get('NEW_CUSTOMER_INQUIRY_PROJECT_ID')
NEW_CUSTOMER_SECTION_ID = os.environ.get('NEW_CUSTOMER_SECTION_ID')
START_TIME = os.environ.get('START_TIME')
ASANA_ACCESS_TOKEN = os.environ.get('ASANA_ACCESS_TOKEN')
JOTFORM_API_KEY = os.environ.get('JOTFORM_API_KEY')
JOTFORM_FORM_ID = os.environ.get('JOTFORM_FORM_ID')
JOTFORM_ASANA_TABLE = os.environ.get('JOTFORM_ASANA_TABLE')

opts = {
    'opt_fields': "actual_time_minutes,approval_status,assignee,assignee.name,assignee_section,assignee_section.name,assignee_status,completed,completed_at,completed_by,completed_by.name,created_at,created_by,custom_fields,custom_fields.asana_created_field,custom_fields.created_by,custom_fields.created_by.name,custom_fields.currency_code,custom_fields.custom_label,custom_fields.custom_label_position,custom_fields.date_value,custom_fields.date_value.date,custom_fields.date_value.date_time,custom_fields.description,custom_fields.display_value,custom_fields.enabled,custom_fields.enum_options,custom_fields.enum_options.color,custom_fields.enum_options.enabled,custom_fields.enum_options.name,custom_fields.enum_value,custom_fields.enum_value.color,custom_fields.enum_value.enabled,custom_fields.enum_value.name,custom_fields.format,custom_fields.has_notifications_enabled,custom_fields.id_prefix,custom_fields.is_formula_field,custom_fields.is_global_to_workspace,custom_fields.is_value_read_only,custom_fields.multi_enum_values,custom_fields.multi_enum_values.color,custom_fields.multi_enum_values.enabled,custom_fields.multi_enum_values.name,custom_fields.name,custom_fields.number_value,custom_fields.people_value,custom_fields.people_value.name,custom_fields.precision,custom_fields.representation_type,custom_fields.resource_subtype,custom_fields.text_value,custom_fields.type,dependencies,dependents,due_at,due_on,external,external.data,followers,followers.name,hearted,hearts,hearts.user,hearts.user.name,html_notes,is_rendered_as_separator,liked,likes,likes.user,likes.user.name,memberships,memberships.project,memberships.project.name,memberships.section,memberships.section.name,modified_at,name,notes,num_hearts,num_likes,num_subtasks,parent,parent.created_by,parent.name,parent.resource_subtype,permalink_url,projects,projects.name,resource_subtype,start_at,start_on,tags,tags.name,workspace,workspace.name", # list[str] | This endpoint returns a compact resource, which excludes some properties by default. To include those optional properties, set this query parameter to a comma-separated list of the properties you wish to include.
}

def extract_items_data(content):
    answers = content.get('answers', {})
    if not answers:
        return {}
    items, name, notes, created_at = None, None, None, datetime.strptime(content['created_at'], '%Y-%m-%d %H:%M:%S')
    for key, value in answers.items():
        if value['name'] == 'name':
            name = value['prettyFormat']
        if value['name'] == 'typeA29':
            items = value['answer']
        if value['name'] == 'anyAdditional':
            notes = value.get('answer', '')
    items = eval(items)
    item_str = ""
    if items:
        for item in items:
            for key, value in item.items():
                key = key.replace('amp;','')
                item_str += f'{key}: {value}\n'
            item_str += '\n'
    return {'id': content['id'], 'items': item_str, 'notes': notes, 'name': name, 'created_at': created_at}

def write_in_asana_description(task: dict, submission_data: dict):
    configuration = asana.Configuration()
    configuration.access_token = ASANA_ACCESS_TOKEN
    api_client = asana.ApiClient(configuration)
    task_client = asana.TasksApi(api_client)
    body = {'data': {"custom_fields": {ITEMS_FIELD_ID: submission_data['items']}}}
    task_client.update_task(body=body, task_gid=task['gid'], opts=opts)

def fetch_jotform_data(date_part, hour, minute, seconds):
    url = f"https://api.jotform.com/form/{JOTFORM_FORM_ID}/submissions?apikey={JOTFORM_API_KEY}&filter=%7B%22created_at%3Agt%22%3A%22{date_part}+{hour}%3A{minute}%3A{seconds}%22%7D&orderby=created_at"
    response = requests.get(url)
    if response.status_code == 200:
        return response.json()
    else:
        response.raise_for_status()

def fetch_modified_tasks_from_project(modified_since):
    configuration = asana.Configuration()
    configuration.access_token = ASANA_ACCESS_TOKEN
    api_client = asana.ApiClient(configuration)
    task_client = asana.TasksApi(api_client)
    tasks = task_client.get_tasks_for_section(
        section_gid=NEW_CUSTOMER_INQUIRY_PROJECT_ID, 
        opts={
            'modified_since': modified_since.strftime('%Y-%m-%d %H:%M:%S'), 
            'opt_fields': "name,created_at,notes"
        }
    )
    return tasks

def fetch_tasks_from_section():
    configuration = asana.Configuration()
    configuration.access_token = ASANA_ACCESS_TOKEN
    api_client = asana.ApiClient(configuration)
    task_client = asana.TasksApi(api_client)
    tasks = task_client.get_tasks_for_section(section_gid=NEW_CUSTOMER_SECTION_ID, opts={'opt_fields': "name,created_at,notes"})
    return tasks

def find_task_id(tasks, submission_data):
    for task in tasks:
        created_date_parts =  task['created_at'].split('T')
        created_at = datetime.strptime(created_date_parts[0] + ' ' + created_date_parts[1][:-5], '%Y-%m-%d %H:%M:%S')
        if task['notes'] == submission_data['notes'] and \
            task['name'] == submission_data['name'] and \
            (created_at - submission_data['created_at'] - timedelta(hours=4)).seconds < 5:
            return task
    return None

def write_to_db(task: dict, submission_data: dict):
    created_date_parts =  task['created_at'].split('T')
    data = {
        'task_id': task['gid'],
        'submission_id': submission_data['id'],
        'submission_created_at': datetime.strftime(submission_data['created_at'], '%Y-%m-%d %H:%M:%S'),
        'task_created_at': created_date_parts[0] + ' ' + created_date_parts[1][:-5]
    }
    mysql = MySQLCRUD()
    mysql.insert_record(JOTFORM_ASANA_TABLE, data)

def main():
    mysql = MySQLCRUD()
    start_time = None
    
    response = mysql.execute_query(f'select max(submission_created_at) created_at from {JOTFORM_ASANA_TABLE}')
    if response:
        start_time = response[0]['created_at'] or START_TIME

    if isinstance(start_time, datetime):
        start_time = datetime.strftime(start_time, '%Y-%m-%d %H:%M:%S')
    
    print(f'checking submissions added after {start_time}')
    try:
        date_part, time_part = start_time.split(' ')[0], start_time.split(' ')[1]
        submissions = fetch_jotform_data(date_part, time_part.split(':')[0], time_part.split(':')[1], time_part.split(':')[2])
        if submissions["content"]:
            tasks = fetch_tasks_from_section()
            print(f'found {len(submissions["content"])} new submissions')
            for submission in submissions['content']:
                submission_data = extract_items_data(submission)
                if submission_data:
                    print(f'processing submission id: {submission_data["id"]}')
                    task = find_task_id(tasks, submission_data)
                    if task:
                        print(task['gid'], submission_data['id'])
                        write_in_asana_description(task, submission_data)
                        write_to_db(task, submission_data)
                    else:
                        print(f'no matching tasks found for submission id: {submission_data["id"]}')
        else:
            print('no new submissions found!')
    except requests.exceptions.RequestException as e:
        print(f"An error occurred: {e}")

if __name__ == '__main__':
    while True:
        main()
        time.sleep(120)
