import mysql.connector
from typing import Dict, Optional, Any
from datetime import datetime
import os
MYSQL_HOST = None
MYSQL_PWD = None
MYSQL_USER = None

class MySQLCRUD:
    def __init__(self, database: str):
        self.connection = mysql.connector.connect(
            host=os.environ.get('MYSQL_HOST') or MYSQL_HOST,
            user=os.environ.get('MYSQL_USER') or MYSQL_USER,
            password=os.environ.get('MYSQL_PWD') or MYSQL_PWD,
            database=database
        )
        self.cursor = self.connection.cursor()

    def create_table(self, table_name: str, columns: str):
        create_table_query = f"CREATE TABLE IF NOT EXISTS {table_name} ({columns})"
        self.execute_query(create_table_query)

    def insert_record(self, table_name: str, data: Dict[str, Any]):
        columns = ', '.join(data.keys())
        values = ', '.join('%s' for _ in data.values())
        insert_query = f"INSERT INTO {table_name} ({columns}) VALUES ({values})"
        print(insert_query)
        self.execute_query(insert_query, tuple(self._convert_value(value) for value in data.values()))

    def select_records(self, table_name: str, conditions: Optional[Dict[str, Any]] = None):
        where_clause = self._build_where_clause(conditions)
        select_query = f"SELECT * FROM {table_name} {where_clause}"
        self.execute_query(select_query)
        return self.cursor.fetchall()

    def update_record(self, table_name: str, data: Dict[str, Any], conditions: Optional[Dict[str, Any]] = None):
        set_clause = ', '.join(f"{key} = %s" for key in data.keys())
        where_clause = self._build_where_clause(conditions)
        update_query = f"UPDATE {table_name} SET {set_clause} {where_clause}"
        self.execute_query(update_query, tuple(self._convert_value(value) for value in data.values()))

    def delete_records(self, table_name: str, conditions: Optional[Dict[str, Any]] = None):
        where_clause = self._build_where_clause(conditions)
        delete_query = f"DELETE FROM {table_name} {where_clause}"
        self.execute_query(delete_query)

    def execute_query(self, query: str, values: Optional[tuple] = None):
        self.cursor.execute(query, values)
        self.connection.commit()

    def _build_where_clause(self, conditions: Optional[Dict[str, Any]]) -> str:
        if conditions:
            where_conditions = []
            for key, value in conditions.items():
                if isinstance(value, int) or isinstance(value, float):
                    where_conditions.append(f"{key} = {value}")
                else:
                    where_conditions.append(f"{key} = '{value}'")
            return f"WHERE {' AND '.join(where_conditions)}"
        return ""

    def _convert_value(self, value: Any) -> Any:
        if value is None:
            return None
        elif isinstance(value, datetime):
            return value
        else:
            return str(value)
        
    def entry_exists(self, table_name: str, conditions: Optional[Dict[str, Any]]) -> bool:
        where_clause = self._build_where_clause(conditions)
        select_query = f"SELECT 1 FROM {table_name} {where_clause} LIMIT 1"
        self.cursor.execute(select_query)
        result = self.cursor.fetchone()
        return bool(result)
