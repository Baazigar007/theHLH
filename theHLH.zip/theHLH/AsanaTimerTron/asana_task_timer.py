import time
import asana
import math
from datetime import datetime
import os
from asana_task import AsanaTask
import json

TASKS_MAP = {}

# loading tokens
try:
    with open('constants.json') as file:
        json_data = json.load(file)
        ACCESS_TOKEN = json_data['ASANA_ACCESS_TOKEN']
        SECTION_GID = json_data['TARGET_SECTION_GID']
except:
    ACCESS_TOKEN = os.environ.get("ASANA_ACCESS_TOKEN")
    SECTION_GID = os.environ.get("TARGET_SECTION_GID")
    print('using creds stored in heroku!')

# Fetching tasks present in section using section_gid
def get_tasks_by_section_gid(client: asana.ApiClient):
    api_client = asana.TasksApi(client)
    response = api_client.get_tasks_for_section(section_gid=SECTION_GID)
    return response.data

# Function to start the timer on a task
def create_time_tracking_entry(client: asana.ApiClient, task_gid: str, timestamp: datetime):
    api_instance = asana.TimeTrackingEntriesApi(client)
    minutes = math.ceil((datetime.now()-timestamp).seconds/60)

    body = asana.TaskGidTimeTrackingEntriesBody({"duration_minutes": minutes})
    api_instance.create_time_tracking_entry(body, task_gid)

def get_task_details(task_gid: str, client: asana.ApiClient):
    api_client = asana.TasksApi(client)
    data = api_client.get_task(task_gid).data
    tags = [tag.name for tag in data.tags]
    task = AsanaTask(
        actual_time_minutes=int(data.actual_time_minutes) if data.actual_time_minutes else 0,
        approval_status=data.approval_status,
        assignee_name= None if not data.assignee else data.assignee.name,
        assignee_gid=None if not data.assignee else data.assignee.gid,
        assignee_status=data.assignee_status,
        completed=data.completed,
        completed_at=data.completed_at,
        completed_by=data.completed_by,
        created_at=data.created_at,
        created_by=data.created_by,
        due_on=data.due_on,
        gid=data.gid,
        modified_at=data.modified_at,
        name=data.name,
        description=data.notes,
        permalink=data.permalink_url,
        number_of_hearts=data.num_hearts,
        number_of_likes=data.num_likes,
        tags = None if not tags else ';'.join(tags)
    )

    TASKS_MAP[task_gid] = task

def create_required_tables():
    AsanaTask.create_table()

# Main function
def main():
    """
    Driver Function
    """
    # stores the active tasks present in the target section
    active_tasks = dict()

    # create the necessary required tables
    create_required_tables()
    
    while True:
        configuration = asana.Configuration()
        configuration.access_token = ACCESS_TOKEN
        client = asana.ApiClient(configuration)
        tasks = get_tasks_by_section_gid(client)
        task_gids = []
        for task in tasks:
            task_gids.append(task.gid)
            get_task_details(task.gid, client)

        if tasks:
            for task in tasks:
                task_gid = task.gid
                if task_gid not in active_tasks:
                    active_tasks[task_gid] = datetime.now()
                    print(f"Timer started for task: {task.name}")
                    TASKS_MAP[task_gid].timer_status = 'Running'
                    TASKS_MAP[task_gid].insert_to_mysql()
        else:
            print("No tasks in the section")

        tasks_to_remove = set()
        for task_gid, timestamp in active_tasks.items():
            if task_gid not in task_gids:
                create_time_tracking_entry(client, task_gid, timestamp)
                print(f"Timer stopped for task: {task_gid}")
                tasks_to_remove.add(task_gid)
                get_task_details(task_gid, client)
                TASKS_MAP[task_gid].insert_to_mysql()

        for task_gid in tasks_to_remove:
            active_tasks.pop(task_gid)

        time.sleep(10)

if __name__ == "__main__":
    main()
