from datetime import datetime
from mysql_crud import MySQLCRUD

DATA_STRUCTURE = """
gid
resource_type
name
resource_subtype
created_by
approval_status
assignee_status
completed
completed_at
completed_by
created_at
dependencies
dependents
due_at
due_on
external
html_notes
hearted
hearts
is_rendered_as_separator
liked
likes
memberships
modified_at
notes
num_hearts
num_likes
num_subtasks
start_at
start_on
actual_time_minutes
assignee
assignee_section
custom_fields
followers: list
    - gid
    - name
parent
projects: list
    - gid
    - name
tags: list
    - gid
    - name
workspace
    - gid
    - name
permalink_url
"""

ASANA_TABLE_SCHEMA = """
    gid VARCHAR(50) PRIMARY KEY,
    actual_time_minutes INTEGER,
    approval_status VARCHAR(20),
    assignee_name VARCHAR(100),
    assignee_gid VARCHAR(50),
    assignee_status VARCHAR(50),
    completed BOOLEAN,
    completed_at DATETIME,
    completed_by VARCHAR(50),
    created_at DATETIME,
    created_by VARCHAR(50),
    due_on DATETIME,
    modified_at DATETIME,
    name VARCHAR(100),
    description VARCHAR(10000),
    permalink VARCHAR(100),
    number_of_hearts INTEGER,
    number_of_likes INTEGER,
    timer_status VARCHAR(20),
    tags VARCHAR(1000)
"""

TABLE_NAME = "ASANA_TASK"
DATABASE = "timer-dash"

class AsanaTask():
    mysql_conn = MySQLCRUD(DATABASE)

    def __init__(self,
                actual_time_minutes: int,
                approval_status: str,
                assignee_name: str,
                assignee_gid: str,
                assignee_status: str,
                completed: bool,
                completed_at: datetime,
                completed_by: str,
                created_at: datetime,
                created_by: str,
                due_on: datetime,
                gid: str,
                modified_at: datetime,
                name: str,
                description: str,
                permalink: str,
                number_of_hearts: int,
                number_of_likes: int,
                tags: str) -> None:
        self.actual_time_minutes = actual_time_minutes
        self.approval_status = approval_status
        self.assignee_name = assignee_name
        self.assignee_gid = assignee_gid
        self.assignee_status = assignee_status
        self.completed = completed
        self.completed_at = completed_at
        self.completed_by = completed_by
        self.created_by = created_by
        self.created_at = created_at
        self.due_on = due_on
        self.gid = gid
        self.modified_at = modified_at
        self.name = name
        self.description = description
        self.permalink = permalink
        self.number_of_hearts = number_of_hearts
        self.number_of_likes = number_of_likes
        self.timer_status = 'stopped'
        self.tags = tags

    def to_dict(self):
        return {
            "actual_time_minutes": self.actual_time_minutes,
            "approval_status": self.approval_status,
            "assignee_name": self.assignee_name,
            "assignee_gid": self.assignee_gid,
            "assignee_status": self.assignee_status,
            "completed": self.completed,
            "completed_at": self.completed_at,
            "completed_by": self.completed_by,
            "created_at": self.created_at,
            "created_by": self.created_by,
            "due_on": self.due_on,
            "gid": self.gid,
            "modified_at": self.modified_at,
            "name": self.name,
            "description": self.description,
            "permalink": self.permalink,
            "number_of_hearts": self.number_of_hearts,
            "number_of_likes": self.number_of_likes,
            "timer_status": self.timer_status,
            "tags": self.tags
        }
    
    def insert_to_mysql(self):
        entry_exists = self.mysql_conn.entry_exists(TABLE_NAME, {'gid': self.gid})
        if entry_exists:
            self.mysql_conn.update_record(TABLE_NAME, self.to_dict(), {'gid': self.gid})
        else:
            self.mysql_conn.insert_record(TABLE_NAME, self.to_dict())

    @staticmethod
    def create_table():
        AsanaTask.mysql_conn.create_table(TABLE_NAME, ASANA_TABLE_SCHEMA)

    def update_record(self, data, conditions):
        self.mysql_conn.update_record(TABLE_NAME, data, conditions)
    
