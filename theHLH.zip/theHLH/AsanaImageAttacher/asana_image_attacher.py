import json
import os
import time
import asana
import requests
import io

SECRET_MAP = {}


def load_secrets() -> None:
    """
    Loading secrets from json or heroku environment
    """
    try:
        with open("constants.json") as file:
            json_data = json.load(file)
            for key in json_data:
                SECRET_MAP[key] = json_data[key]
    except:
        SECRET_MAP["ACCESS_TOKEN"] = os.environ.get("ACCESS_TOKEN")
        SECRET_MAP["PROJECT_GID"] = os.environ.get("PROJECT_GID")
        print("using creds stored in heroku!")


def attach_image_to_task(client: asana.ApiClient, task_gid: str, name: str):
    attachment_client = asana.AttachmentsApi(client)
    attachment_client.create_attachment_for_object(
        file=os.getcwd() + f"//{name}.jpeg", parent=task_gid
    )

    delete_image_file(os.getcwd() + f"//{name}.jpeg")


def get_all_tasks_from_project(client: asana.ApiClient):
    task_client = asana.TasksApi(client)
    tasks = task_client.get_tasks_for_project(project_gid=SECRET_MAP["PROJECT_GID"], opt_fields=['notes'])
    return tasks


def get_image_data_from_cdn(url: str, name: str):
    response = requests.get(url)
    data = io.BytesIO(response.content)
    with open(os.getcwd() + f"//{name}.jpeg", "wb") as file:
        file.write(data.getvalue())


def get_urls_from_task_description(task_gid: str, client: asana.ApiClient) -> list:
    task_client = asana.TasksApi(client)
    task_data = task_client.get_task(task_gid)
    notes = task_data.data.notes.split("\n")
    urls = []
    if 'Attached!' == notes[len(notes)-1]:
        print('Skipping! Images are already attached.')
        return urls
    name = 'attachment'
    for note in notes:
        if 'Product Name' in note:
            data = note.split(": ")
            name = data[len(data)-1]
        elif "Product Image" in note:
            data = note.split(": ")
            url = name + ';' + data[len(data)-1]
            urls.append(url)
        elif "Upload Design Inspiration" in note:
            data = note.split(": ")
            url = name + '_inspiration;' + data[len(data)-1]
            urls.append(url)
    return urls

def delete_image_file(file_path):
    try:
        os.remove(file_path)
    except FileNotFoundError:
        print(f"File '{file_path}' not found.")
    except Exception as e:
        print(f"Error deleting file '{file_path}': {e}")

def remove_attachments_if_any(client: asana.ApiClient, task_gid: str):
    attachment_api = asana.AttachmentsApi(client)
    attachments = attachment_api.get_attachments_for_object(parent=task_gid)
    for attachment in attachments.data:
        attachment_api.delete_attachment(attachment_gid=attachment.gid)


def main():
    load_secrets()

    # preparing client object for accessing asana data
    configuration = asana.Configuration()
    configuration.access_token = SECRET_MAP["ACCESS_TOKEN"]
    client = asana.ApiClient(configuration)

    # get all tasks present in the project
    tasks = get_all_tasks_from_project(client)
    task_client = asana.TasksApi(client)

    for task in tasks.data:
        print(f'Processing Task GID: {task.gid}')
        urls_in_task_desc = get_urls_from_task_description(task.gid, client)
        if urls_in_task_desc:
            updated = True
            remove_attachments_if_any(client, task.gid)
            for urlinfo in urls_in_task_desc:
                try:
                    name, url =urlinfo.split(';')
                    name = name.replace(' ','')
                    # print(f"Getting image from URL: {url}")
                    get_image_data_from_cdn(url, name)
                    # print("Image generated!")
                    attach_image_to_task(client, task.gid, name)
                    # print("uploaded!")
                except Exception as e:
                    print('failure: ', e)
                    updated = False
            if updated:
                notes = task.notes
                if notes:
                    notes += '\nAttached!'
                    body = {'data': {'notes': notes}}
                    task_client.update_task(body=body, task_gid=task.gid)
            else:
                remove_attachments_if_any(client, task.gid)

if __name__ == "__main__":
    while(True):
        main()
        time.sleep(120)
