// App.js
import "./App.css";
import { Route, Routes } from "react-router-dom";
import Login from "./components/login/login";
import Signup from "./components/signup/signup";
import ForgotPassword from "./components/ForgotPassword/ForgotPassword";
import Dashboard from "./pages/Admin/Dashboard/Dashboard";
import CreateTask from "./pages/Admin/CreateTask/createTask";
import ShopifyQuickbook from "./pages/Admin/SalesData/shopifyQuickbook";
import ExpiredTask from "./pages/Admin/ExpiredTask/expiredTask";
import ViewUsers from "./pages/Admin/Users/viewUsers";
import EditTask from "./pages/Admin/EditTask/editTask";
import Submissions from "./pages/Admin/Submission/taskSubmissions";
import TaskDetail from "./pages/Admin/taskDetails/taskDetail";
import UserTasks from "./pages/Admin/userTasks/userTasks";
import Missing from "./pages/Common/missing";
import DashboardUser from "./pages/User/Dashboard/dashboard";
import AuthMiddleWare from "./components/auth/AuthMiddleware";
import Logout from "./components/logout/logout";
import ExpiredTaskUser from "./pages/User/ExpiredTasks/expiredtasks";
import ProfileUser from "./pages/User/Profile/profile";
import PastSubmissions from "./pages/User/PastSubmissions/pastsubmissions";
import BalanceUser from "./pages/User/Balance/balance";
import SubmiTask from "./pages/User/SubmitTask/submitask";
// import SampleCode from "./pages/Admin/CreateTask/SampleCode";

function App() {
  return (
    <>
      <Routes>
        {/* Public Routes */}
        <Route path="/" element={<Login />} />
        <Route path="/ForgotPassword" element={<ForgotPassword />} />
        <Route path="/signup" element={<Signup />} />
        <Route path="/logout" element={<Logout />} />
        {/* Private Routes for Admin only*/}
        <Route
          path="/admin/dashboard"
          element={
            <AuthMiddleWare>
              <Dashboard />
            </AuthMiddleWare>
          }
        />
        <Route
          path="/admin/createTask"
          element={
            <AuthMiddleWare>
              <CreateTask />
            </AuthMiddleWare>
          }
        />
        <Route
          path="/admin/viewUsers"
          element={
            <AuthMiddleWare>
              <ViewUsers />
            </AuthMiddleWare>
          }
        />
        <Route
          path="/admin/salesData"
          element={
            <AuthMiddleWare>
              <ShopifyQuickbook />
            </AuthMiddleWare>
          }
        />
        <Route
          path="/admin/expireTasks"
          element={
            <AuthMiddleWare>
              <ExpiredTask />
            </AuthMiddleWare>
          }
        />
        <Route
          path="/admin/submission"
          element={
            <AuthMiddleWare>
              <Submissions />
            </AuthMiddleWare>
          }
        />
        <Route
          path="/admin/editTask"
          element={
            <AuthMiddleWare>
              <EditTask />
            </AuthMiddleWare>
          }
        />
        <Route
          path="/admin/taskdetails"
          element={
            <AuthMiddleWare>
              <TaskDetail />
            </AuthMiddleWare>
          }
        />
        <Route
          path="/admin/user"
          element={
            <AuthMiddleWare>
              <UserTasks />
            </AuthMiddleWare>
          }
        />
        {/* Private Routes for user only*/}
        <Route
          path="/user/activetasks"
          element={
            <AuthMiddleWare>
              <DashboardUser />
            </AuthMiddleWare>
          }
        />
        <Route
          path="/user/expireTasks"
          element={
            <AuthMiddleWare>
              <ExpiredTaskUser />
            </AuthMiddleWare>
          }
        />
        <Route
          path="/user/profile"
          element={
            <AuthMiddleWare>
              <ProfileUser />
            </AuthMiddleWare>
          }
        />
        Past submission route
        <Route
          path="/user/pastsubmissions"
          element={
            <AuthMiddleWare>
              <PastSubmissions />
            </AuthMiddleWare>
          }
        />
        <Route
          path="/user/balance"
          element={
            <AuthMiddleWare>
              <BalanceUser />
            </AuthMiddleWare>
          }
        />
        <Route
          path="/user/submitask"
          element={
            <AuthMiddleWare>
              <SubmiTask />
            </AuthMiddleWare>
          }
        />
        {/* Error Route */}
        <Route path="/404" element={<Missing />} />
      </Routes>
    </>
  );
}

export default App;
