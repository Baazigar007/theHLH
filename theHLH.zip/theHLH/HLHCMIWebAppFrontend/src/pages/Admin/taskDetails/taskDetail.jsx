import { useState, useEffect, useContext } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import axios from "axios";
import {
  notification,
  Image,
  Input,
  Button,
  Divider,
  Row,
  Col,
  InputNumber,
} from "antd";
import Navbar from "../Navbar/navbar";
import "./style3.css";
import { AuthContext } from "../../../components/auth/AuthWrapper";
import Background from "../../../assets/images/Background.png";
import { LeftOutlined, RightOutlined } from "@ant-design/icons";

const TaskDetails = () => {
  const [details, setDetails] = useState(null);
  const [adminComment, setAdminComment] = useState("");
  const [payStatus, setPayStatus] = useState("Unpaid");
  const [completionStatus, setCompletionStatus] = useState(null);
  const [reward, setReward] = useState(0);
  const [user_comment, setuserComment] = useState("");
  const [rewardStatus, setRewardStatus] = useState("");
  const [rewardError, setRewardError] = useState("");
  const [statusChanged, setStatusChanged] = useState(false);
  const [payStatusChanged, setPayStatusChanged] = useState(false);
  const [user, setUser] = useState({
    name: "",
    college: "",
    sorority: "",
  });

  const { token } = useContext(AuthContext);
  const location = useLocation();
  const User_Id = location?.state.User_Id;
  const [taskData, setTaskData] = useState("");
  const [taskamount, setTaskAmount] = useState();

  const yourPropValue = location.state?.data;
  const filterOption = location.state?.filterOption;
  const [submissions, setSubmissions] = useState([]);
  const [subIndex, setSubIndex] = useState(0);
  const navigate = useNavigate();

  useEffect(() => {
    if (User_Id) {
      setUser((prevUser) => ({ ...prevUser, name: location.state.Username }));
      const fetchDatafromUser = async () => {
        try {
          // Fetch task submissions
          const tasksubmissionsResponse = await axios.get(
            `https://hlh-v2-29a03c04aeb6.herokuapp.com/api/user/${User_Id}/submissions`,
            {
              headers: {
                authorization: `Bearer ${token}`,
              },
            }
          );
          // Check if task submissions are available
          if (tasksubmissionsResponse && tasksubmissionsResponse.data) {
            const tasksubmissions = tasksubmissionsResponse.data;
            const detailsArray = [];
            // Loop through each task submission and fetch details
            for (let submission of tasksubmissions) {
              const submissionDetailsResponse = await axios.get(
                `https://hlh-v2-29a03c04aeb6.herokuapp.com/api/submission/${submission._id}`,
                {
                  headers: {
                    authorization: `Bearer ${token}`,
                  },
                }
              );

              detailsArray.push(submissionDetailsResponse.data);
            }
            console.log("User submissions ->", detailsArray);
            setSubmissions(detailsArray);
          } else {
            notification.error({
              message: "No tasks submissions found.",
              duration: 2,
            });
          }
        } catch (error) {
          console.error("Error fetching data:", error);
        } finally {
          // setLoading(false);
        }
      };
      fetchDatafromUser();
    } else {
      const fetchData = async () => {
        try {
          const taskData = location.state.data;
          setTaskData(location.state.data);
          setTaskAmount(taskData.amount);
          let res;
          if (filterOption === "All") {
            res = await axios.get(
              `https://hlh-v2-29a03c04aeb6.herokuapp.com/api/task/${yourPropValue._id}/submissions`,
              {
                headers: {
                  authorization: `Bearer ${token}`,
                },
              }
            );
          } else {
            res = await axios.get(
              `https://hlh-v2-29a03c04aeb6.herokuapp.com/api/task/${yourPropValue._id}/${filterOption}/submissionsFilteredByStatus`,
              {
                headers: {
                  authorization: `Bearer ${token}`,
                },
              }
            );
          }
          console.log(res.data);
          setSubmissions(res.data);
        } catch (error) {
          console.log("Error fetching submissions:", error);
        }
      };

      fetchData();
    }
  }, []);

  useEffect(() => {
    // console.log("Updateing ");
    const fetchData = async () => {
      try {
        const current_submission = await submissions[subIndex];
        // console.log("Current ", current_submission);
        if (current_submission?.taskId) {
          //When UserId is present then only update otherwise these both fields are same.
          setTaskData(current_submission.taskId);
          setTaskAmount(current_submission.taskId.amount);
        }
        setDetails(current_submission);
        setPayStatus(current_submission?.payment_status);
        setCompletionStatus(current_submission?.status);
        setuserComment(current_submission?.user_comment);
        setAdminComment(current_submission?.review_comment);
        if (current_submission?.status === "Rejected") {
          setReward(0);
        } else if (current_submission?.status === "Pending") {
          setReward("NA");
        } else {
          setReward(current_submission?.reward);
        }
      } catch (error) {
        console.log(error);
      }
    };
    fetchData();

    const func = async () => {
      try {
        const current_submission = await submissions[subIndex];
        const res = await axios.get(
          `https://hlh-v2-29a03c04aeb6.herokuapp.com/api/users/${current_submission.userId}`,
          {
            headers: {
              Authorization: `Bearer ${token}`,
            },
          }
        );
        setUser(res.data);
      } catch (error) {
        console.log(error);
      }
    };
    if (!User_Id) func();
  }, [subIndex, submissions]);

  const handleStatusChange = (evt) => {
    const newStatus = evt.target.value;
    setCompletionStatus(newStatus);
    setStatusChanged(true);
    if (newStatus === "Accepted") {
      setReward(taskamount);
    } else if (newStatus === "Rejected") {
      setReward(0);
      setRewardStatus("");
      setRewardError("");
      setPayStatus("Unpaid");
      setPayStatusChanged(true);
    } else if (newStatus === "Pending") {
      setReward("NA");
      setRewardStatus("");
      setRewardError("");
      setPayStatus("Unpaid");
      setPayStatusChanged(true);
    } else if (newStatus === "PartiallyAccepted") {
      setReward(taskamount);
    }
  };
  const handlePayStatusChange = (evt) => {
    if (
      (completionStatus === "Accepted" ||
        completionStatus === "PartiallyAccepted") &&
      evt.target.value === "Paid"
    ) {
      setPayStatus(evt.target.value);
      setPayStatusChanged(true);
    } else if (
      (completionStatus === "Accepted" ||
        completionStatus === "PartiallyAccepted") &&
      evt.target.value === "Unpaid"
    ) {
      setPayStatus(evt.target.value);
      setPayStatusChanged(true);
    } else if (evt.target.value === "Paid") {
      notification.warning({
        message: "Warning",
        description:
          "You can only mark paid when status is Accepted or PartiallyAccepted.",
        duration: 2,
      });
    }
  };
  const handleSuccess = () => {
    notification.success({
      message: "Success",
      description:
        "Your action was successful. You can see changes after refresh.",
      duration: 2,
    });

    setTimeout(() => {
      if (subIndex === submissions.length - 1) {
        // setSubIndex(0);
        //Navigate to Home page
        navigate("/admin/dashboard");
      } else setSubIndex((prevSubIndex) => prevSubIndex + 1);
    }, 1000);
  };
  const onChangeReward = (value) => {
    setReward(value);
    if (value > taskamount) {
      setRewardStatus("error");
      setRewardError("Reward cannot be greater than the task amount.");
    } else {
      setRewardStatus("");
      setRewardError("");
    }
  };
  async function saveTask() {
    try {
      if (reward > taskamount) {
        setRewardError("Reward cannot be greater than the task amount.");
        return;
      } else {
        setRewardError("");
      }

      await axios.put(
        `https://hlh-v2-29a03c04aeb6.herokuapp.com/api/submission/${submissions[subIndex]._id}`,
        {
          user_comment: user_comment,
          review_comment: adminComment,
          reward: reward,
          status: completionStatus,
          payment_status: payStatus,
        },
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );
      handleSuccess();
    } catch (error) {
      console.log(error);
    }
  }

  return (
    <>
      <Navbar />
      <div
        className="task-container"
        style={{
          backgroundImage: `url(${Background})`,
          backgroundSize: "100% 100%",
          height: "100%",
        }}
      >
        <div className="content-container">
          <div className="task-details-header">
            <div className="user-task-header-l">
              <br />
              <center>
                Task Title: <b>{taskData ? taskData.name : ""}</b>
              </center>
              <br />
              <center>
                Submitted by <b>{user.name}</b>
              </center>
            </div>
          </div>

          <div className="task-info-parent">
            <div className="toggles">
              <div className="button-container">
                <Button
                  type="primary"
                  className="previous-button"
                  icon={<LeftOutlined />}
                  onClick={() =>
                    setSubIndex((prevSubIndex) => prevSubIndex - 1)
                  }
                  disabled={subIndex === 0}
                />
                <Button
                  type="primary"
                  className="next-button"
                  icon={<RightOutlined />}
                  onClick={() =>
                    setSubIndex((prevSubIndex) => prevSubIndex + 1)
                  }
                  disabled={subIndex === submissions.length - 1}
                />
              </div>
              <div className="status-filter">
                <label htmlFor="status" className="label-details">
                  Status:
                </label>
                <select
                  name="status"
                  className="taskdetails-select"
                  value={completionStatus}
                  id="status"
                  onChange={handleStatusChange}
                  disabled={completionStatus === "Accepted" && !statusChanged}
                >
                  <option value="Pending">Pending</option>
                  <option value="Accepted">Accepted</option>
                  <option value="Rejected">Rejected</option>
                  <option value="PartiallyAccepted">Partially Accepted</option>
                </select>
                <select
                  name="paystatus"
                  className="taskdetails-select"
                  value={payStatus}
                  id="paystatus"
                  onChange={handlePayStatusChange}
                  disabled={payStatus === "Paid" && !payStatusChanged}
                >
                  <option value="Unpaid">Unpaid</option>
                  <option value="Paid">Paid</option>
                </select>
              </div>
              <br />
              <div className="status-filter">
                <label htmlFor="paystatus" className="label-details">
                  Rewarded:
                  <InputNumber
                    className="reward"
                    min={0}
                    value={reward}
                    onChange={onChangeReward}
                    status={rewardStatus}
                    disabled={
                      (completionStatus === "Rejected" && reward === 0) ||
                      (completionStatus === "Pending" && reward === "NA") ||
                      payStatus === "Paid"
                    }
                  />
                </label>
                <br />
                <p className="taskamount">TaskAmount : {taskamount}</p>
                {rewardError && <p style={{ color: "red" }}>{rewardError}</p>}
              </div>
            </div>
            <Divider />
            <div className="Comments">
              <p className="comments">
                User Comment :
                <Input value={user_comment} style={{ pointerEvents: "none" }} />
              </p>
            </div>

            <div className="Comments">
              <p className="comments">Add Review :</p>
              <Input
                type="text"
                value={adminComment}
                onChange={(e) => setAdminComment(e.target.value)}
              />
            </div>
            <br />
            <Row justify="center" align="middle">
              <Col>
                <Button
                  onClick={saveTask}
                  type="primary"
                  className="save-button"
                >
                  Save
                </Button>
              </Col>
            </Row>
          </div>
          <Divider />

          <div className="image-container">
            {details && details.imageUrls && details.imageUrls.length > 0 ? (
              details.imageUrls.map((imgUrl, idx) => (
                <Image
                  width={300}
                  height={300}
                  src={imgUrl}
                  key={idx}
                  className="uploaded-image"
                />
              ))
            ) : (
              <h2 className="alttext">No Images in the task</h2>
            )}
          </div>
        </div>
      </div>
    </>
  );
};

export default TaskDetails;
