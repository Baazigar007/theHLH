/* eslint-disable no-unused-vars */
import { useContext, useEffect, useState } from "react";
import { Spin, Space, Layout, Modal } from "antd";
import { ExclamationCircleFilled } from "@ant-design/icons";
import { AuthContext } from "../../../components/auth/AuthWrapper";
import TaskTile from "../TaskTile/taskTile";
import axios from "axios";
import Navbar from "../Navbar/navbar";
import "./style.css";

import Background from "../../../assets/images/Background.png";

const { confirm } = Modal;

function Dashboard() {
  const { getAllTasks, token } = useContext(AuthContext);
  const [tasks, setAllTasks] = useState([]);
  const [loading, setLoading] = useState(true);
  const [dragItem, setDragItem] = useState(null);
  const [dragOverItem, setDragOverItem] = useState(null);
  const [temp, setTemp] = useState(false);
  const [oldTask, setOldTask] = useState([]);

  useEffect(() => {
    setLoading(true);
    const getTasks = async () => {
      try {
        const tasksResponse = await getAllTasks();
        console.log("Old Task->", tasksResponse);
        tasksResponse.sort((a, b) => b.priority - a.priority);
        setOldTask(tasksResponse);
        setAllTasks(tasksResponse);
      } catch (error) {
        console.error("Error fetching tasks:", error);
      } finally {
        setLoading(false);
      }
    };
    getTasks();
  }, [getAllTasks]);

  const handleSort = () => {
    setTemp(true);
    let _tasks = [...tasks];
    const draggedItemContent = _tasks.splice(dragItem, 1)[0];
    _tasks.splice(dragOverItem, 0, draggedItemContent);
    setAllTasks(_tasks);
  };

  const saveOrder = async () => {
    const newOrder = tasks
      .filter((task, index) => task._id !== oldTask[index]._id)
      .map((task, index) => ({
        _id: task._id,
        priority: oldTask[index].priority,
      }));
    console.log(newOrder);
    const res = await axios.put(
      `https://hlh-v2-29a03c04aeb6.herokuapp.com/api/tasks/priority`,
      newOrder,
      {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      }
    );
    setTemp(false);
  };

  useEffect(() => {
    if (temp === true) {
      const showConfirm = () => {
        confirm({
          title: "Do you want to permanently save it?",
          icon: <ExclamationCircleFilled />,
          onOk() {
            console.log("List updated");
            saveOrder();
          },
          onCancel() {
            console.log("Cancel");
          },
        });
      };
      showConfirm();
    }
  }, [tasks, temp]);

  const handleDragStart = (e, index) => {
    setDragItem(index);
  };

  const handleDragEnter = (e, index) => {
    setDragOverItem(index);
  };

  return (
    <div
      className="dashboard-container"
      style={{ backgroundImage: `url(${Background})` }}
    >
      <Navbar />
      <h1>ACTIVE TASKS</h1>
      {loading ? (
        <div className="spinner-container">
          <Spin size="large" fullscreen />
        </div>
      ) : tasks.length ? (
        <Layout
          style={{
            padding: 10,
            minHeight: "100vh",
            backgroundColor: "transparent",
          }}
        >
          <Space direction="vertical" style={{ width: "100%" }}>
            {tasks.map((details, index) => (
              <div
                draggable
                key={index}
                onDragStart={(e) => handleDragStart(e, index)}
                onDragEnter={(e) => handleDragEnter(e, index)}
                onDragEnd={handleSort}
              >
                <TaskTile key={index} data={details} />
              </div>
            ))}
          </Space>
        </Layout>
      ) : (
        <div style={{ textAlign: 'center' }}>No active tasks</div>
      )}
    </div>
  );
}

export default Dashboard;
