import { Button, Form, Input, InputNumber, notification, Select } from "antd";
import { useState, useContext, useEffect } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import Navbar from "../Navbar/navbar";
import "./editstyle.css";
import { AuthContext } from "../../../components/auth/AuthWrapper";
import axios from "axios";
import Background from "../../../assets/images/Background.png";


const validateMessages = {
  required: "${label} is required!",
  types: {
    email: "${label} is not a valid email!",
    number: "${label} is not a valid number!",
  },
  number: {
    range: "${label} must be between ${min} and ${max}",
  },
};

function editTask() {
  const location = useLocation();
  const taskData = location.state.data;
  console.log("TaskData- ", taskData);
  //Deadline update
  const deadlineDate = new Date(taskData.deadline);
  let day = deadlineDate.getDate();
  let month = deadlineDate.getMonth() + 1; // Months are zero-indexed
  const year = deadlineDate.getFullYear();
  if (month < 10) {
    month = `0${month}`;
  }
  if (day < 10) {
    day = `0${day}`;
  }
  const formattedDeadline = `${year}-${month}-${day}`;

  const navigate = useNavigate();
  const [tasktype, settasktype] = useState(taskData.type);
  const [assigned, setAssigned] = useState(taskData.assignedTo?._id || null);
  const [title, setTitle] = useState(taskData.name);
  const [amount, setAmount] = useState(taskData.amount);
  const [deadline1, setDeadline1] = useState(formattedDeadline);
  const [desc, setDesc] = useState(taskData.description);
  const { token, getAllUsers } = useContext(AuthContext);
  const [users, setUsers] = useState([]);

  const handleSuccess = () => {
    notification.success({
      message: "Success",
      description: "Your action was successful.",
      duration: 2,
    });

    setTimeout(() => {
      navigate("/admin/dashboard");
    }, 1000);
  };

  const deleteTask = async () => {
    try {
      await axios.delete(
        `https://hlh-v2-29a03c04aeb6.herokuapp.com/api/tasks/${taskData._id}`,
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );
      handleSuccess();
    } catch (error) {
      notification.error({
        message: "Error",
        description: "Task was not deleted or someone has submitted this task.",
        duration: 2,
      });
      console.log(error);
    }
  };

  const DuplicateTask = async () => {
    //Deadline update

    const taskDetails = {
      name: title,
      amount: amount,
      deadline: deadline1,
      description: desc,
      assignedTo: assigned,
    };
    console.log(tasktype);
    console.log("2 ", taskDetails);
    if (tasktype === "INDIVIDUAL") {
      try {
        const response = await axios.post(
          "https://hlh-v2-29a03c04aeb6.herokuapp.com/api/tasks/",
          {
            name: taskDetails.name,
            description: taskDetails.description,
            amount: taskDetails.amount,
            deadline: taskDetails.deadline,
            assignedTo: taskDetails.assignedTo,
            type: "INDIVIDUAL",
          },
          {
            headers: {
              "Access-Control-Allow-Origin": "*",
              Authorization: `Bearer ${token}`,
              "Content-Type": "application/json",
            },
          }
        );
        console.log(response);
        notification.success({
          message: "Duplicate Task Created",
          duration: 2,
        });
        navigate("/admin/dashboard");
      } catch (error) {
        console.log("ERROR WHILE CREATING TASK TO DB");
      }
    } else {
      try {
        const response = await axios.post(
          "https://hlh-v2-29a03c04aeb6.herokuapp.com/api/tasks/",
          {
            name: taskDetails.name,
            description: taskDetails.description,
            amount: taskDetails.amount,
            deadline: taskDetails.deadline,
            type: "BULK",
          },
          {
            headers: {
              "Access-Control-Allow-Origin": "*",
              Authorization: `Bearer ${token}`,
              "Content-Type": "application/json",
            },
          }
        );
        console.log(response);
        notification.success({
          message: "Duplicate Task Created",
          duration: 2,
        });
        navigate("/admin/dashboard");
      } catch (error) {
        console.log("ERROR WHILE CREATING TASK TO DB");
        console.log(error);
      }
    }
  };

  useEffect(() => {
    const temp = async () => {
      const res = await getAllUsers();
      setUsers(res);
    };
    temp();
  }, [getAllUsers]);

  const onFinish = async (values) => {
    if (tasktype === "INDIVIDUAL" && assigned === null) {
      notification.warning({
        message: "Warning",
        description: "Please select a user.",
        duration: 2,
      });
      return;
    }
    try {
      await axios.put(
        `https://hlh-v2-29a03c04aeb6.herokuapp.com/api/tasks/${taskData._id}`,
        {
          name: values.task.title,
          description: values.task.description,
          amount: values.task.amount,
          deadline: values.task.deadline,
          type: tasktype,
          assignedTo: assigned,
        },
        {
          headers: {
            "Access-Control-Allow-Origin": "*",
            Authorization: `Bearer ${token}`,
            "Content-Type": "application/json",
          },
        }
      );
      handleSuccess();
    } catch (error) {
      console.log("22 ", error);
    }
  };


  return (
    <div className="edit-task-container" style={{
      backgroundImage: `url(${Background})`,
      backgroundSize: 'cover',
      height: '100%'
    }}>
        <Navbar/>
        <h1>EDIT TASK DETAILS</h1>
        <Form className="edit-form" size = "large" name="nest-messages" onFinish={onFinish} validateMessages={validateMessages}>
          <div className="input-container">
            <Form.Item
              name={["task", "title"]}
              label="Title"
              rules={[{ required: true }]}
              initialValue={taskData.name}
            >
              <Input className="input-item" onChange={(e) => setTitle(e.target.value)} />
            </Form.Item>

            <Form.Item
              name={["task", "amount"]}
              label="Amount"
              rules={[
                {
                  type: "number",
                  min: 0,
                  max: 999,
                  required: true,
                },
              ]}
              initialValue={taskData.amount}
            >
              <InputNumber className="input-item" onChange={(e) => setAmount(e)} />
            </Form.Item>

            <Form.Item
              label="Deadline"
              name={["task", "deadline"]}
              rules={[{ required: true }]}
              initialValue={formattedDeadline}
            >
              <Input className="input-item" type="date" onChange={(e) => setDeadline1(e.target.value)} />
            </Form.Item>

            <Form.Item label="Select" className="form-item">
              <Select className="input-item" name={["task", "type"]} onChange={(evt) => settasktype(evt)} value={tasktype}>
                <Select.Option value="BULK">Bulk Task</Select.Option>
                <Select.Option value="INDIVIDUAL">Single Task</Select.Option>
                <Select.Option value="BONUS">Bonus</Select.Option>
              </Select>
            </Form.Item>

            {tasktype === "INDIVIDUAL" && (
              <Form.Item label="Assign to" className="form-item">
                <Select className="input-item" name={["task", "assigned"]} onChange={(evt) => setAssigned(evt)} value={assigned}>
                  {users.map((user) => {
                    if (!user.isAdmin) {
                      return (
                        <Select.Option key={user._id} value={user._id}>
                          {user.name}
                        </Select.Option>
                      );
                    }
                  })}
                </Select>
              </Form.Item>
            )}

            <Form.Item
              name={["task", "description"]}
              label="Description"
              initialValue={taskData.description}
            >
              <Input.TextArea className="input-item" rows={5} onChange={(e) => setDesc(e.target.value)} />
            </Form.Item>
          </div>

          <div>
            <Button type="secondary" htmlType="submit" className="submit-btn">Submit</Button>
            <Button type="secondary" onClick={DuplicateTask} className="duplicate-btn">Duplicate</Button>
            <Button type="secondary" onClick={deleteTask} className="delete-btn">Delete</Button>
          </div>
        </Form>
      </div>
  );
}
export default editTask;
