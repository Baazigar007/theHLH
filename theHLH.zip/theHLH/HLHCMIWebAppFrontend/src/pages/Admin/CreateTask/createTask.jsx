/* eslint-disable react-hooks/rules-of-hooks */
/* eslint-disable no-unused-vars */
import React, { useContext, useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import Navbar from "../Navbar/navbar";
import { Button, Form, Input, InputNumber, Select, DatePicker, notification } from "antd";
import axios from "axios";
import { AuthContext } from "../../../components/auth/AuthWrapper";
import moment from "moment-timezone";
import "./createstyle.css";
import Background from "../../../assets/images/Background.png";

const layout = {
  labelCol: {
    span: 8,
  },
  wrapperCol: {
    span: 10,
  },
};

/* eslint-disable no-template-curly-in-string */
const validateMessages = {
  required: "${label} is required!",
  types: {
    email: "${label} is not a valid email!",
    number: "${label} is not a valid number!",
  },
  number: {
    range: "${label} must be between ${min} and ${max}",
  },
};

const createTask = () => {
  const [assigned, setAssigned] = useState(null);
  const { token, getAllUsers } = useContext(AuthContext);
  const [tasktype, settasktype] = useState("BULK");
  const navigate = useNavigate();
  const [users, setUsers] = useState([]);

  // const getCurrentTimeInTimeZone = (timeZone) => moment().tz(timeZone).toDate();

  const getCurrentTimeInTimeZone = (timeZone) => {
    const currentDate = moment().tz(timeZone); // Get current date in the specified time zone
    return (date) => date.isBefore(currentDate, "day"); // Return true for dates before the current date
  };

  useEffect(() => {
    const temp = async () => {
      const res = await getAllUsers();
      // console.log(res);
      setUsers(res);
    };
    temp();
  }, [getAllUsers]);
  const onFinish = async (values) => {
    const taskDetails = values.task;
    console.log(taskDetails);
    const dateObj = values.task.deadline;
    let mon = parseInt(dateObj.$M) + 1;
    if (dateObj.$M < 10) {
      mon = `0${mon}`;
    }
    const date = `${dateObj.$y}-${mon}-${dateObj.$D}`;

    if (tasktype === "SINGLETASK") {
      if (assigned === null) {
        notification.warning({
          message: "Warning",
          description: "Please select a user.",
          duration: 2,
        });
        return;
      }
      try {
        const response = await axios.post(
          "https://hlh-v2-29a03c04aeb6.herokuapp.com/api/tasks/",
          {
            name: taskDetails.title,
            description: taskDetails.description,
            amount: taskDetails.amount,
            deadline: date,
            assignedTo: assigned,
            type: "INDIVIDUAL",
          },
          // assignto: taskDetails.assignTo,
          {
            headers: {
              "Access-Control-Allow-Origin": "*",
              Authorization: `Bearer ${token}`,
              "Content-Type": "application/json",
            },
          }
        );
        console.log(response);
        notification.success({
          message: "Success",
          description: "Task Created. Please return to Dashboard.",
          duration: 2,
        });
        navigate("/admin/dashboard");
      } catch (error) {
        console.log("ERROR WHILE CREATING TASK TO DB");
      }
    } else {
      try {
        const response = await axios.post(
          "https://hlh-v2-29a03c04aeb6.herokuapp.com/api/tasks/",
          {
            name: taskDetails.title,
            description: taskDetails.description,
            amount: taskDetails.amount,
            deadline: date,
            type: "BULK",
          },
          {
            headers: {
              "Access-Control-Allow-Origin": "*",
              Authorization: `Bearer ${token}`,
              "Content-Type": "application/json",
            },
          }
        );

        console.log(response);
        notification.success({
          message: "Success",
          description: "Task Created. Please return to Dashboard.",
          duration: 2,
        });
        navigate("/admin/dashboard");
      } catch (error) {
        console.log("ERROR WHILE CREATING TASK TO DB");
        console.log(error);
      }
    }
  };

  return (
    <div className="edit-task-container" style={{
      backgroundImage: `url(${Background})`,
      height: '100%'
    }}>
      <Navbar />
      <h1>CREATE A TASK</h1>
      <Form className="create-form"
        size="large"
        name="nest-messages"
        onFinish={onFinish}
        validateMessages={validateMessages}
      >
        <Form.Item
          name={["task", "title"]}
          label="Title"
          rules={[
            {
              required: true,
            },
          ]}
        >
          <Input className="input-item"/>
        </Form.Item>

        <Form.Item
          name={["task", "amount"]}
          label="Amount"
          rules={[
            {
              type: "number",
              min: 0,
              max: 999,
              required: true,
            },
          ]}
        >
          <InputNumber className="input-item"/>
        </Form.Item>
        <Form.Item
          label="Deadline"
          name={["task", "deadline"]}
          rules={[{ required: true }]}
        >
          <DatePicker className="input-item"
            disabledDate={getCurrentTimeInTimeZone("America/Los_Angeles")}
          />
        </Form.Item>
        <Form.Item label="Select">
          <Select className="input-item" onChange={(evt) => settasktype(evt)} value={tasktype}>
            <Select.Option value="BULK">Bulk Task</Select.Option>
            <Select.Option value="SINGLETASK">Single Task</Select.Option>
            <Select.Option value="BONUS">Bonus</Select.Option>
          </Select>
        </Form.Item>
        {tasktype === "SINGLETASK" ? (
          <Form.Item label="Assign to">
            <Select
              className="input-item"
              name={["task", "assigned"]}
              onChange={(evt) => setAssigned(evt)}
              value={assigned}
            >
              {users.map((user) => {
                if (!user.isAdmin) {
                  return (
                    <Select.Option key={user._id} value={user._id}>
                      {user.name}
                    </Select.Option>
                  );
                }
              })}
            </Select>
          </Form.Item>
        ) : (
          <></>
        )}

        <Form.Item name={["task", "description"]} label="Description">
          <Input.TextArea className="input-item" rows={5} />
        </Form.Item>
        <Form.Item
          // wrapperCol={{
          //   ...layout.wrapperCol,
          //   offset: 8,
          // }}
        >
          <Button type="secondary" htmlType="submit" className="submit_button">
            Submit
          </Button>
        </Form.Item>
      </Form>
    </div>
  );
};
export default createTask;
