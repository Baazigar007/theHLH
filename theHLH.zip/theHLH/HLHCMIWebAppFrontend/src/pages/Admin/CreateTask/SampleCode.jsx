import { Table } from "antd";

const columns = [
  {
    title: "Name",
    dataIndex: "name",
    key: "name",
    // You can add additional configurations for the column
    // For example, specify a fixed width for the column
    // width: 150
  },
  {
    title: "Age",
    dataIndex: "age",
    key: "age",
  },
  {
    title: "Age",
    dataIndex: "age",
    key: "age",
  },
  {
    title: "Age",
    dataIndex: "age",
    key: "age",
  },
  {
    title: "Age",
    dataIndex: "age",
    key: "age",
  },
  {
    title: "Age",
    dataIndex: "age",
    key: "age",
  },
  {
    title: "Age",
    dataIndex: "age",
    key: "age",
  },
  {
    title: "Address",
    dataIndex: "address",
    width: 200,
    // Add ellipsis to show truncated text
    ellipsis: true,
    key: "address",
  },
];

const data = [
  {
    key: "1",
    name: "John Brown",
    age: 32,
    address: "New York No. 1 Lake Park",
  },
  {
    key: "2",
    name: "Jim Green",
    age: 42,
    address: "London No. 1 Lake Park",
  },
  {
    key: "3",
    name: "Joe Black",
    age: 32,
    address: "Sidney No. 1 Lake Park",
  },
];

const SampleCode = () => {
  return (
    <Table
      columns={columns}
      dataSource={data}
      responsive // Enable responsive behavior
      scroll={{ x: true }}
    />
  );
};

export default SampleCode;
