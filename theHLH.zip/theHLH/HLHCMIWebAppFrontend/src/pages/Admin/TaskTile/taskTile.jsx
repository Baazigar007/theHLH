/* eslint-disable react-hooks/rules-of-hooks */
import { Card } from "antd";
import { useNavigate } from "react-router-dom";
import { Typography } from "antd";
const { Title } = Typography;
import "./style4.css";
import { DownOutlined, LoadingOutlined } from "@ant-design/icons";
import { Dropdown, Space } from "antd";
import axios from "axios";
import { useContext, useState } from "react";
import { AuthContext } from "../../../components/auth/AuthWrapper";

function taskTile(details1) {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const { token } = useContext(AuthContext);
  const details = details1.data;
  const [metrics, setMetrics] = useState({
    Accepted: 0,
    Pending: 0,
    PartiallyAccepted: 0,
    Rejected: 0,
    submissions: 0,
  });

  const items = [
    {
      label: (
        <a
          onClick={
            metrics.submissions === 0
              ? null
              : () => {
                  navigate("/admin/taskdetails", {
                    state: { data: details, filterOption: "All" },
                  });
                }
          }
          style={{
            pointerEvents: metrics.submissions === 0 ? "none" : "auto",
            color: metrics.submissions === 0 ? "gray" : "black",
          }}
        >
          Submissions: {metrics.submissions}
        </a>
      ),
      key: "0",
    },
    {
      type: "divider",
    },
    {
      label: (
        <a
          onClick={
            metrics.Accepted === 0
              ? null
              : () => {
                  navigate("/admin/taskdetails", {
                    state: { data: details, filterOption: "Accepted" },
                  });
                }
          }
          style={{
            pointerEvents: metrics.Accepted === 0 ? "none" : "auto",
            color: metrics.Accepted === 0 ? "gray" : "black",
          }}
        >
          Accepted: {metrics.Accepted}
        </a>
      ),
      key: "1",
    },
    {
      type: "divider",
    },
    {
      label: (
        <a
          onClick={
            metrics.PartiallyAccepted === 0
              ? null
              : () => {
                  navigate("/admin/taskdetails", {
                    state: { data: details, filterOption: "PartiallyAccepted" },
                  });
                }
          }
          style={{
            pointerEvents: metrics.PartiallyAccepted === 0 ? "none" : "auto",
            color: metrics.PartiallyAccepted === 0 ? "gray" : "black",
          }}
        >
          PartiallyAccepted: {metrics.PartiallyAccepted}
        </a>
      ),
      key: "2",
    },
    {
      type: "divider",
    },
    {
      label: (
        <a
          onClick={
            metrics.Pending === 0
              ? null
              : () => {
                  navigate("/admin/taskdetails", {
                    state: { data: details, filterOption: "Pending" },
                  });
                }
          }
          style={{
            pointerEvents: metrics.Pending === 0 ? "none" : "auto",
            color: metrics.Pending === 0 ? "gray" : "black",
          }}
        >
          Pending: {metrics.Pending}
        </a>
      ),
      key: "3",
    },
    {
      type: "divider",
    },
    {
      label: (
        <a
          onClick={
            metrics.Rejected === 0
              ? null
              : () => {
                  navigate("/admin/taskdetails", {
                    state: { data: details, filterOption: "Rejected" },
                  });
                }
          }
          style={{
            pointerEvents: metrics.Rejected === 0 ? "none" : "auto",
            color: metrics.Rejected === 0 ? "gray" : "black",
          }}
        >
          Rejected: {metrics.Rejected}
        </a>
      ),
      key: "4",
    },
  ];

  const fetchMetrices = async (e) => {
    setLoading(true);
    e.preventDefault();
    try {
      const res = await axios.get(
        `https://hlh-v2-29a03c04aeb6.herokuapp.com/api/task/${details._id}/submissionMetrics`,
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );
      // Extract relevant data from the response
      const data = res.data;

      // Update the metrics state with the extracted data
      setMetrics({
        Accepted: data.Accepted,
        Pending: data.Pending,
        PartiallyAccepted: data.PartiallyAccepted,
        Rejected: data.Rejected,
        submissions: data.TotalSubmissions,
      });
    } catch (err) {
      console.log(err);
    } finally {
      setLoading(false);
    }
  };

  //Deadline update
  const deadlineDate = new Date(details.deadline);
  // Get day, month, and year from the deadline date
  const day = deadlineDate.getDate();
  let month = deadlineDate.getMonth() + 1; // Months are zero-indexed
  const year = deadlineDate.getFullYear();
  if (month < 10) {
    month = `0${month}`;
  }
  const formattedDeadline = `${month}-${day}-${year}`;

  return (
    <div>
      <Card
        className="CardsContainer"
        type="inner"
        title={
          <Title level={4} className="Title" id="title">
            {details.name}
          </Title>
        }
        extra={
          <h3
            className="ExtraLink"
            onClick={() => {
              navigate("/admin/editTask", { state: { data: details } });
            }}
          >
            Edit
          </h3>
        }
        hoverable={true}
      >
        <div>
          <Title level={5} id="desc">
            Description : {details.description}
          </Title>
          <Title level={5} id="amount">
            Amount : ${details.amount}
          </Title>
          <Title level={5} id="deadline">
            Deadline : {formattedDeadline}
          </Title>
        </div>

        <Dropdown
          menu={{
            items,
          }}
          overlayStyle={{ minWidth: "200px", margin: "20px" }} // Add margin here
          placement="bottom"
          disabled={loading}
          trigger={["click"]}
        >
          <a onClick={(e) => fetchMetrices(e)}>
            <Space>
              {loading ? (
                <LoadingOutlined />
              ) : (
                <>
                  <span
                    style={{
                      fontFamily: "Hope Sans",
                      fontWeight: "360",
                      fontSize: "16px",
                      color: "#4495E7",
                    }}
                  >
                    Check Submissions
                  </span>
                  <DownOutlined />
                </>
              )}
            </Space>
          </a>
        </Dropdown>
      </Card>
    </div>
  );
}

export default taskTile;
