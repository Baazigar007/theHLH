import React, { useState, useEffect, useContext } from "react";
import { Input, Select, Button, Spin, Layout, Space } from "antd";
import Navbar from "../Navbar/navbar";
import UserTile from "./userTile";
import { AuthContext } from "../../../components/auth/AuthWrapper";
import * as ExcelJS from "exceljs";
import { saveAs } from "file-saver";
import axios from "axios";
import "./style.css";

function ViewUsers() {
  const { token } = useContext(AuthContext);
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [sortBy, setSortBy] = useState(null);
  const [collegeFilter, setCollegeFilter] = useState([]);
  const [filteredUsers, setFilteredUsers] = useState([]);
  const [searchValue, setSearchValue] = useState("");
  const [selectedUsername, setSelectedUsername] = useState(null);
  const [filteredUsernames, setFilteredUsernames] = useState([]);
  const [collegeFilterValue, setCollegeFilterValue] = useState("all");

  useEffect(() => {
    setFilteredUsers(users);
  }, [users]);

  useEffect(() => {
    try {
      const getColeges = async () => {
        const res = await axios.get("https://hlh-v2-29a03c04aeb6.herokuapp.com/api/colleges");
        setCollegeFilter(res.data);
      };
      getColeges();
    } catch (error) {
      console.log(error);
    }
  }, []);

  useEffect(() => {
    setLoading(true);
    try {
      const getAllUsers = async () => {
        const res = await axios.get("https://hlh-v2-29a03c04aeb6.herokuapp.com/api/users/", {
          headers: {
            "Access-Control-Allow-Origin": "*",
            Authorization: `Bearer ${token}`,
          },
        });
        setUsers(res.data);
        const uniqueUsernames = [...new Set(res.data.map(user => user.name))];
        setFilteredUsernames(uniqueUsernames.sort());
      };
      getAllUsers();
    } catch (error) {
      console.log("4 ", error);
    } finally {
      setLoading(false);
    }
  }, [token]);

  const handleSort = (sortByField) => {
    setSortBy(sortByField);
    let sortedUsers = [...users];
    if (sortedUsers.length > 0) {
      sortedUsers.sort((a, b) => b[sortByField] - a[sortByField]);
      setUsers(sortedUsers);
    }
  };

  const downloadExcel = async () => {
    const workbook = new ExcelJS.Workbook();
    const worksheet = workbook.addWorksheet("Users");

    worksheet.addRow(["Name", "Balance", "Total Earned", "Unreviewed Balance"]);

    users.forEach((user) => {
      worksheet.addRow([user.name, user.balance, user.total_earned, user.unreviewed_balance]);
    });

    const buffer = await workbook.xlsx.writeBuffer();
    saveAs(new Blob([buffer]), "users.xlsx");
  };

  const handleCollegeUsernameFilter = (collegeValue, usernameValue) => {
    setLoading(true);
    let filtered = users;
    
    if (collegeValue && collegeValue !== "all") {
      filtered = filtered.filter((user) => user.college.toLowerCase() === collegeValue.toLowerCase());
    }

    if (usernameValue && usernameValue !== "all") {
      filtered = filtered.filter((user) => user.name.toLowerCase() === usernameValue.toLowerCase());
    }

    setFilteredUsers(filtered);
    setLoading(false);
  };

  const handleSearch = (value) => {
    setSearchValue(value);
    const filtered = users.filter((user) => user.name.toLowerCase().includes(value.toLowerCase()));
    setFilteredUsers(filtered);
  };

  return (
    <div className="user-tile-container">
      <Navbar />
      <div className="container1">
        <div className="button-group">
          <Button onClick={() => handleSort("balance")} className="button">
            Sort by Balance
          </Button>
          <Button onClick={() => handleSort("total_earned")} className="button">
            Sort by Total Earned
          </Button>
          <Button onClick={() => handleSort("unreviewed_balance")} className="button">
            Sort by Unreviewed Balance
          </Button>
          <Button type="primary" onClick={downloadExcel} className="download">
            Download
          </Button>
        </div>
        <div className="select-search-container" style={{ display: "flex", alignItems: "center" }}>
          <Select
            placeholder={<span style={{ color: "#1c1c1ca8" }}>Filter by College</span>}
            style={{ width: "70%", fontFamily: "Hope Sans" }}
            className="college-select"
            onChange={(value) => {
              setCollegeFilterValue(value);
              handleCollegeUsernameFilter(value, selectedUsername);
            }}
            showSearch
            optionFilterProp="children"
            filterOption={(input, option) => option.children.toLowerCase().indexOf(input.toLowerCase()) >= 0}
            value={collegeFilterValue}
          >
            <Select.Option value="all">All</Select.Option>
            {collegeFilter.map((college) => (
              <Select.Option key={college._id} value={college.name}>
                {college.name}
              </Select.Option>
            ))}
          </Select>
          <Select
            placeholder={<span style={{ color: "#1c1c1ca8" }}>Search by Username</span>}
            style={{ width: "70%", fontFamily: "Hope Sans", marginLeft: 18 }}
            className="username-select"
            onChange={(value) => {
              setSelectedUsername(value);
              handleCollegeUsernameFilter(collegeFilterValue, value);
            }}
            value={selectedUsername}
            showSearch
            optionFilterProp="children"
            filterOption={(input, option) => option.children.toLowerCase().indexOf(input.toLowerCase()) >= 0}
          >
            <Select.Option value="all">All</Select.Option>
            {filteredUsernames.map((username) => (
              <Select.Option key={username} value={username}>
                {username}
              </Select.Option>
            ))}
          </Select>
        </div>
      </div>
      <h1>VIEW USERS</h1>
      {loading ? (
        <center className="spinner-container">
          <Spin size="medium" fullscreen />
        </center>
      ) : filteredUsers.length > 0 ? (
        <Layout
          style={{
            padding: 10,
            minHeight: "100vh",
            backgroundColor: "transparent",
          }}
        >
          <Space direction="vertical" style={{ width: "100%" }}>
            {filteredUsers.map((details, index) => (
              <UserTile key={index} data={details} />
            ))}
          </Space>
        </Layout>
      ) : (
        <div style={{ textAlign: "center", marginTop: 20 }}>
          <h4>No data available</h4>
        </div>
      )}
    </div>
  );
}

export default ViewUsers;
