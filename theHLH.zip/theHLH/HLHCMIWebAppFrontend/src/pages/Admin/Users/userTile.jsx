import { Card, Button, Spin, notification, message, Popconfirm } from "antd";
import { useNavigate } from "react-router-dom";
import { useContext, useState } from "react";
import instaLogo from "../../../assets/images/instagram.png";
import tiktokLogo from "../../../assets/images/tiktok.png";
import paypalLogo from "../../../assets/images/paypal.png";
import venmoLogo from "../../../assets/images/venmo.png";
import axios from "axios";
import { AuthContext } from "../../../components/auth/AuthWrapper";

function UserTile(details) {
  const navigate = useNavigate();
  const EachUser = details.data;
  const [loading, setLoading] = useState(false);
  const { token } = useContext(AuthContext);

  const openInsta = () => {
    window.open(`https://instagram.com/${EachUser.instagram}`, "_blank");
  };

  const openTiktok = () => {
    window.open(`https://tiktok.com/@${EachUser.tiktokId}`, "_blank");
  };

  const openVenmo = () => {
    window.open(`https://venmo.com/u/${EachUser.vemoId}`, "_blank");
  };

  const openPayPal = () => {
    window.open(`https://paypal.com/paypalme/${EachUser.paypalId}`, "_blank");
  };

  const confirm = (e) => {
    console.log(e);
    handleAllTasksPay();
    // message.success("Click on Yes");
  };
  const cancel = (e) => {
    console.log(e);
    message.error("Cancelled");
  };

  const handleAllTasksPay = async () => {
    setLoading(true);
    try {
      const res = await axios.get(
        `https://hlh-v2-29a03c04aeb6.herokuapp.com/api/user/${EachUser._id}/submissions`,
        {
          headers: {
            authorization: `Bearer ${token}`,
          },
        }
      );
      const unpaidSubmissions = res.data.filter(
        (submission) => submission.payment_status === "Unpaid"
      );

      for (let subIndex = 0; subIndex < unpaidSubmissions.length; subIndex++) {
        if (
          unpaidSubmissions[subIndex].status === "Pending" ||
          unpaidSubmissions[subIndex].status === "Rejected"
        ) {
          const taskAmount = unpaidSubmissions[subIndex].taskId.amount;
          await axios.put(
            `https://hlh-v2-29a03c04aeb6.herokuapp.com/api/submission/${unpaidSubmissions[subIndex]._id}`,
            {
              status: "Accepted",
              payment_status: "Paid",
              reward: taskAmount,
            },
            {
              headers: {
                Authorization: `Bearer ${token}`,
              },
            }
          );
        } else {
          let taskAmount = unpaidSubmissions[subIndex].taskId.amount;
          if (
            unpaidSubmissions[subIndex].reward &&
            unpaidSubmissions[subIndex].reward !== 0
          ) {
            taskAmount = unpaidSubmissions[subIndex].reward;
          }
          await axios.put(
            `https://hlh-v2-29a03c04aeb6.herokuapp.com/api/submission/${unpaidSubmissions[subIndex]._id}`,
            {
              payment_status: "Paid",
              reward: taskAmount,
            },
            {
              headers: {
                Authorization: `Bearer ${token}`,
              },
            }
          );
        }
      }

      handleSuccess();
      setLoading(false);
      console.log("OK");
    } catch (error) {
      alert("Could not connect, Please try again.");
    }
  };

  const handleSuccess = () => {
    notification.success({
      message: "Success",
      description:
        "Your action was successful. You can see changes after refresh.",
      duration: 2,
    });

    setTimeout(() => {
      navigate("/admin/viewUsers"); // Redirect to view users page
    }, 1000);
  };
  return (
    <div>
      {loading ? (
        <center className="spinner-container">
          <Spin size="medium" fullscreen />
        </center>
      ) : (
        <Card
          hoverable={true}
          className="CardsContainer"
          type="inner"
          title={<h3 className="Name">{EachUser.name}</h3>}
          extra={
            <>
              <Button
                className="OpenSubmissions"
                onClick={() => {
                  navigate("/admin/taskdetails", {
                    state: { User_Id: EachUser._id, Username: EachUser.name },
                  });
                }}
              >
                Open Submissions
              </Button>

              <Popconfirm
                title={`Did you pay ${EachUser.name} ?`}
                description={`The balance will be updated to $0.`}
                onConfirm={confirm}
                placement="left"
                onCancel={cancel}
                okText="Yes"
                cancelText="No"
              >
                <Button className="OpenSubmissions">
                  Update Balance to $0
                </Button>
              </Popconfirm>
            </>
          }
        >
          <div>
            <h4>Earned: ${EachUser.total_earned}</h4>
            <h4>Balance: ${EachUser.balance}</h4>
            <h4>Unreviewed Balance: ${EachUser.unreviewed_balance}</h4>
            <h4>College: {EachUser.college}</h4>
            <h4>{EachUser.paypalId ? <>Paypal: {EachUser.paypalId}</> : ""}</h4>
            <h4>{EachUser.vemoId ? <> Venmo: {EachUser.vemoId}</> : ""}</h4>
            <div style={{ display: "flex", justifyContent: "flex-end" }}>
              {EachUser.instagram ? (
                <img
                  src={instaLogo}
                  alt="Instagram"
                  height={20}
                  width={20}
                  style={{ margin: "0 5px" }}
                  onClick={openInsta}
                />
              ) : null}
              {EachUser.tiktokId ? (
                <img
                  src={tiktokLogo}
                  alt="TikTok"
                  height={20}
                  width={20}
                  style={{ margin: "0 5px" }}
                  onClick={openTiktok}
                />
              ) : null}
              {EachUser.vemoId ? (
                <img
                  src={venmoLogo}
                  alt="Venmo"
                  height={20}
                  width={20}
                  style={{ margin: "0 5px" }}
                  onClick={openVenmo}
                />
              ) : null}
              {EachUser.paypalId ? (
                <img
                  src={paypalLogo}
                  alt="PayPal"
                  height={20}
                  width={20}
                  style={{ margin: "0 5px" }}
                  onClick={openPayPal}
                />
              ) : null}
            </div>
          </div>
        </Card>
      )}
    </div>
  );
}

export default UserTile;

