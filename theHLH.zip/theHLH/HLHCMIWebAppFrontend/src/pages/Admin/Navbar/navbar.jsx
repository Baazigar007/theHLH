import { Drawer, Menu } from "antd";
import { useState } from "react";
import { MenuOutlined } from "@ant-design/icons";
import "./navbar.css";
import { useNavigate } from "react-router-dom";
import navlogo from "../../../assets/images/HLHlogo.svg";

function Navbar() {
  const [openMenu, setOpenMenu] = useState(false);

  return (
    <div>
      <div className="menuIcon" style={{ padding: 8 }}>
        <MenuOutlined
          style={{ fontSize: 30 }}
          onClick={() => {
            setOpenMenu(true);
          }}
        />
      </div>
      <span className="headerMenu">
        <AppMenu />
      </span>
      <Drawer
        placement="left"
        open={openMenu}
        width="60%"
        onClose={() => {
          setOpenMenu(false);
        }}
        closable={false}
      >
        <AppMenu isInline />
      </Drawer>
    </div>
  );
}

function AppMenu({ isInline = false }) {
  const navigate = useNavigate();
  return (
    <Menu
      className="NavBar"
      onClick={({ key }) => {
        if (key === "logout") {
          //LOGOUT FEATURE IMPLEMENTATION
        } else {
          navigate(key);
        }
      }}
      defaultSelectedKeys={[window.location.pathname]}
      mode={isInline ? "inline" : "horizontal"}
    >
      <img src={navlogo} alt="Logo" className="navlogo" />
      <Menu.Item key="/admin/dashboard" className="LabelMenu">
        Dashboard
      </Menu.Item>
      <Menu.Item key="/admin/expireTasks" className="LabelMenu">
        Expired Tasks
      </Menu.Item>
      <Menu.Item key="/admin/viewUsers" className="LabelMenu">
        View Users
      </Menu.Item>
      <Menu.Item key="/admin/createTask" className="LabelMenu">
        Create Task
      </Menu.Item>
      <Menu.Item key="/admin/salesData" className="LabelMenu">
        Sales Data
      </Menu.Item>
      <Menu.Item key="/logout" danger className="LabelMenu">
        Logout
      </Menu.Item>
    </Menu>
  );
}

export default Navbar;
