export const storage_data = {
  labels: ["Used", "Available"],
  datasets: [
    {
      data: [30, 70],
      backgroundColor: ["#ff69b4", "#36A2EB"],
    },
  ],

  plugins: {
    labels: {
      render: "percentage",
      fontColor: ["green", "white", "red"],
      precision: 2,
    },
  },
  text: "23%",
};
