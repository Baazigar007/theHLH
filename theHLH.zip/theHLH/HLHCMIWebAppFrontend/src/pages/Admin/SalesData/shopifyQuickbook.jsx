import React, { useEffect, useMemo, useState } from "react";
import "./newDashbord.css";
import { Box, Grid, Typography } from "@mui/material";
import Button from "@mui/material/Button";
import Menu from "@mui/material/Menu";
import MenuItem from "@mui/material/MenuItem";
import PopupState, { bindTrigger, bindMenu } from "material-ui-popup-state";
import { storage_data } from "./mockdata";
import ChartRender from "./ChartRender";
import { createTheme, ThemeProvider } from "@mui/material/styles";
import axios from "axios";
import Modal from "@mui/material/Modal";
import Fade from "@mui/material/Fade";
// import "dotenv/config";
// custom style:
const style = {
  position: "absolute",
  top: "50%",
  left: "50%",
  transform: "translate(-50%, -50%)",
  width: 450,
  bgcolor: "rgb(139, 140, 247)",
  boxShadow: 5,
  p: 5,
  borderRadius: 5,
};

const ShopifyQuickbook = () => {
  // states for QBO and ASANA
  const [totalSales, setTotalSales] = useState(0);
  const [totalProfit, setTotalProfit] = useState(0);
  const [totalTask, setTotalTask] = useState([]);
  const [taskName, setTaskName] = useState("");
  const [open, setOpen] = useState(false);
  const [count, setCount] = useState(0);
  const [token, setToken] = useState("");
  const [url, setURL] = useState("");
  // states for SHOPIFY
  const [dailysales, setDailySales] = useState(0);
  const [weeklysales, setWeeklySales] = useState(0);
  const [monthlysales, setMonthlySales] = useState(0);
  const ASANA_ACCESS_TOKEN = import.meta.env.VITE_ASANA_ACCESS_TOKEN;
  const project_gid = import.meta.env.VITE_project_gid;
  const SHOPIFY_ACCESS_TOKEN = import.meta.env.VITE_SHOPIFY_ACCESS_TOKEN;
  let countFun = 0;
  const fetchData = async () => {
    try {
      // fetch all task from HanglooseHut
      const getAllTask = await axios.get(
        `https://app.asana.com/api/1.0/tasks?project=${project_gid}`,
        {
          headers: {
            Authorization: `Bearer ${ASANA_ACCESS_TOKEN}`,
          },
        }
      );
      let data1 = getAllTask.data.data.map((object) => {
        return { gid: object.gid, name: object.name };
      });
      setTotalTask(data1);

      // fetch the sales data
      const response = await axios.get(
        "/api/quickbooks/v3/company/9341452383230510/reports/ClassSales?start_date=2024-05-01&end_date=2024-05-31&minorversion=70",
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );
      setTotalSales(
        parseFloat(response.data?.Rows?.Row[2]?.Summary?.ColData[1]?.value)
      );

      // fetch the profit data
      const responseProfit = await axios.get(
        "/api/quickbooks/v3/company/9341452383230510/reports/ProfitAndLoss?start_date=2024-04-01&end_date=2024-04-30&minorversion=70",
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );
      let data = responseProfit?.data?.Rows?.Row[3]?.Summary?.ColData[1]?.value;
      setTotalProfit(Math.abs(Math.round(data)));
    } catch (error) {
      console.log("Error: ", error);
    }
  };

  const fetchOrders = async (url, orders = []) => {
    try {
      const response = await axios.get(url, {
        headers: {
          "X-Shopify-Access-Token": SHOPIFY_ACCESS_TOKEN,
        },
      });
      const newOrders = response.data.orders;
      orders = orders.concat(newOrders);

      // Check for pagination
      const linkHeader = response.headers["link"];
      if (linkHeader) {
        const nextLinkMatch = linkHeader.match(/<([^>]+)>;\s*rel="next"/);
        if (nextLinkMatch) {
          let nextUrl = nextLinkMatch[1];

          // Ensure the URL is correctly handled
          if (!nextUrl.startsWith("http")) {
            nextUrl = `https://volleyballjewels.myshopify.com${nextUrl}`;
          }
          nextUrl = nextUrl.replace(
            "https://volleyballjewels.myshopify.com",
            "/api/shopify"
          );
          countFun++;
          return fetchOrders(nextUrl, orders);
        }
      }
      console.log("Count: ", countFun);
      console.log("Orders: ", orders);
      return orders;
    } catch (error) {
      console.error("Error fetching orders:", error);
      return orders;
    }
  };

  const fetchShopify = async () => {
    const initialUrl =
      "/api/shopify/admin/api/2024-04/orders.json?status=any&limit=250";
    const orders = await fetchOrders(initialUrl);
    console.log("Orders: ", orders);

    try {
      let dailySales = 0;
      let weeklySales = 0;
      let monthlySales = 0;
      const currentDate = new Date();
      orders.forEach((element) => {
        const orderDate = new Date(element.created_at);
        const orderPrice = Number(element.total_price);
        if (isSameDay(orderDate, currentDate)) {
          dailySales += orderPrice;
        }
        if (isSameWeek(orderDate, currentDate)) {
          weeklySales += orderPrice;
        }
        if (isSameMonth(orderDate, currentDate)) {
          monthlySales += orderPrice;
        }
      });
      setDailySales(dailySales);
      setWeeklySales(weeklySales);
      setMonthlySales(monthlySales);
      console.log("Daily Sales: ", dailySales.toFixed(2));
      console.log("Weekly Sales: ", weeklySales.toFixed(2));
      console.log("Monthly Sales: ", monthlySales.toFixed(2));
    } catch (error) {
      console.error("Error fetching Shopify orders:", error.message);
    }
  };

  const isSameDay = (date1, date2) => {
    return (
      date1.getDate() === date2.getDate() &&
      date1.getMonth() === date2.getMonth() &&
      date1.getFullYear() === date2.getFullYear()
    );
  };

  const isSameWeek = (date1, date2) => {
    const startOfWeek = (date) => {
      const dateCopy = new Date(date);
      const day = dateCopy.getDay();
      const diff = dateCopy.getDate() - day + (day === 0 ? -6 : 1); // Adjust if day is Sunday
      dateCopy.setDate(diff);
      dateCopy.setHours(0, 0, 0, 0);
      return dateCopy;
    };
    const startOfDate1Week = startOfWeek(date1);
    const startOfDate2Week = startOfWeek(date2);
    return startOfDate1Week.getTime() === startOfDate2Week.getTime();
  };

  const isSameMonth = (date1, date2) => {
    return (
      date1.getMonth() === date2.getMonth() &&
      date1.getFullYear() === date2.getFullYear()
    );
  };
  const getOAuth = async () => {
    try {
      // const response = await axios.get(`${proccss.env.dev}/auth`);
      const response = await axios.get(`${import.meta.env.VITE_DEV}/auth`);
      setURL(response.data.url);
      console.log(response.data);
      const responseToken = await axios.get(`${import.meta.env.VITE_DEV}/getToken`);
      setToken(responseToken.data.token.token.access_token);
      console.log(responseToken.data);
    } catch (error) {
      console.log("ErrorIngetOAuthfun call : ", error.message);
    }
  };

  useEffect(() => {
    fetchShopify();
    fetchData();
    getOAuth();

    const intervalId = setInterval(fetchData, 15 * 60 * 1000);
    const intervalIdForQBO = setInterval(getOAuth, 60 * 60 * 1000);

    return () => {
      clearInterval(intervalId);
      clearInterval(intervalIdForQBO);
    };
  }, [token]);

  const mockData = [
    { label: "MONTHLY SALES", value: totalSales || 99 },
    { label: "TOTAL PROFIT", value: totalProfit || 99 },
  ];
  const pieChartData = useMemo(
    () => ({
      labels: ["Live daily sales", "Live weekly sales", "Live monthly sales"],
      datasets: [
        {
          label: "Analysis",
          data: [750, 2515, totalSales],
          backgroundColor: ["#ff69b4", "#ffeb3b", "#2196f3"],
        },
      ],
      options: {
        responsive: true,
        plugins: {
          legend: {
            display: false,
          },
          title: {
            display: false,
            text: "Bar Chart Representation",
          },
        },
        scales: {
          y: {
            beginAtZero: true,
            title: {
              display: true,
              text: "Value",
            },
          },
          x: {
            title: {
              display: true,
              text: "Categories",
            },
          },
        },
      },
    }),
    [totalSales]
  );

  const barChartData = useMemo(
    () => ({
      labels: ["Live daily sales", "Live weekly sales", "Live monthly sales"],
      datasets: [
        {
          label: "Analysis",
          data: [750, 2515, totalSales],
          backgroundColor: ["#ff69b4", "#ffeb3b", "#2196f3"],
        },
      ],
      options: {
        responsive: true,
        plugins: {
          legend: {
            display: false,
          },
          title: {
            display: true,
            text: "Bar Chart Representation",
          },
        },
        scales: {
          y: {
            beginAtZero: true,
            title: {
              display: true,
              text: "Value",
            },
          },
          x: {
            title: {
              display: true,
              text: "Categories",
            },
          },
        },
      },
    }),
    [totalSales]
  );

  const barChartData1 = useMemo(
    () => ({
      labels: ["Live daily sales", "Live weekly sales", "Live Monthly sales"],
      datasets: [
        {
          label: "Analysis",
          data: [
            dailysales || 1343.65,
            weeklysales || 8486.6,
            monthlysales || 18540.38,
          ],
          backgroundColor: ["#ff69b4", "#ffeb3b", "#2196f3"],
        },
      ],
      options: {
        responsive: true,
        plugins: {
          legend: {
            display: false,
          },
          title: {
            display: true,
            text: "Bar Chart Representation",
          },
        },
        scales: {
          y: {
            beginAtZero: true,
            title: {
              display: true,
              text: "Value",
            },
          },
          x: {
            title: {
              display: true,
              text: "Categories",
            },
          },
        },
      },
    }),
    [monthlysales]
  );

  const theme = createTheme({
    breakpoints: {
      values: {
        xs: 0,
        sm: 800,
        md: 1200,
        lg: 1400,
        xl: 1600,
      },
    },
  });
  const pieChartOptions = {
    responsive: true,
    plugins: {
      legend: {
        position: "right",
      },
    },
  };
  const doughnutChartOptions = {
    responsive: true,
    cutout: "80%",
    plugins: {
      legend: {
        position: "right",
      },
    },
  };
  const horizontalBarOption = {
    responsive: true,
    indexAxis: "y",
  };

  //Get Task Details
  const handleGetTaskDetails = async (id) => {
    try {
      const taskDetails = await axios.get(
        `https://app.asana.com/api/1.0/tasks/${id}/stories`,
        {
          headers: {
            Authorization: `Bearer ${ASANA_ACCESS_TOKEN}`,
          },
        }
      );
      // console.log(taskDetails.data.data);
      let data = taskDetails.data.data;
      let count = 0;
      let phrase =
        'moved this task from "WAITING ON CUSTOMER APPROVAL" to "CUSTOMER DESIGNS"';
      for (let i = 0; i < data.length; i++) {
        if (data[i].text.includes(phrase)) {
          count++;
        }
      }
      // console.log(count);
      setCount(count);
    } catch (error) {
      console.log("Error: ", error.message);
    }
  };

  // close Modal Function
  const handleModalClose = () => {
    setOpen(!open);
    setCount(0);
    setTaskName("");
  };
  return (
    <>
      <ThemeProvider theme={theme}>
        <Box className="dashboard_container">
          <Typography
            className="container_heading"
            variant="h2"
            fontWeight={600}
          >
            Sales Performance Dashboard
          </Typography>
          <Box className="DB_main">
            {/* Side Bar */}
            <Box className="DB_calculation_list_container">
              {mockData.map((data, index) => {
                return (
                  <Box className="card_primary" key={index} sx={{ mb: "3rem" }}>
                    <Typography className="border_bottom pt-15 pb-15 f-20px">
                      {data.label}
                    </Typography>
                    <Typography className="pt-15 pb-15 f-30">
                      {data.value}
                    </Typography>
                  </Box>
                );
              })}

              {/* DropDown Menu */}
              <Box>
                <PopupState variant="popover" popupId="demo-popup-menu">
                  {(popupState) => {
                    const handleTwoFunctions = (taskID, taskName) => {
                      popupState.close();
                      handleGetTaskDetails(taskID);
                      setTaskName(taskName);
                      setOpen(!open);
                    };
                    return (
                      <React.Fragment>
                        <Button
                          variant="contained"
                          {...bindTrigger(popupState)}
                          size="large"
                          style={{
                            width: "100%",
                            height: "3rem",
                            fontSize: "1.35rem",
                            fontWeight: "bold",
                            marginTop: "1rem",
                          }}
                        >
                          Select a Task
                        </Button>
                        <Menu {...bindMenu(popupState)}>
                          {totalTask.map((object) => (
                            <MenuItem
                              key={object.gid}
                              onClick={() =>
                                handleTwoFunctions(object.gid, object.name)
                              }
                            >
                              {object.name}
                            </MenuItem>
                          ))}
                        </Menu>
                      </React.Fragment>
                    );
                  }}
                </PopupState>
              </Box>
              {/* button */}
              {url && (
                <Box>
                  <Button
                    variant="contained"
                    size="large"
                    style={{
                      width: "100%",
                      height: "3rem",
                      fontSize: "1.35rem",
                      fontWeight: "bold",
                      marginTop: "2rem",
                    }}
                    onClick={() => window.open(url, "_blank", "noopener")}
                  >
                    Get a Token
                  </Button>
                </Box>
              )}
            </Box>

            {/* Charts and Graphs */}
            <Box className="DB_analytics_Container">
              <Grid container className="grid_container" spacing={3}>
                <Grid item lg={4} md={6} sm={6} xs={12}>
                  <Box className="grid_item">
                    <Typography>QUICKBOOKS SALES</Typography>
                    <ChartRender
                      data={pieChartData}
                      type="pie"
                      options={pieChartOptions}
                    />
                  </Box>
                </Grid>
                <Grid item lg={4} md={6} sm={6} xs={12}>
                  <Box className="grid_item">
                    <Typography>QuUICKBOOKS SALES</Typography>
                    <ChartRender
                      data={storage_data}
                      type="doughnut"
                      options={doughnutChartOptions}
                    />
                  </Box>
                </Grid>
                <Grid item lg={4} md={6} sm={6} xs={12}>
                  <Box className="grid_item">
                    <Typography>QUICKBOOKS SALES</Typography>
                    <ChartRender data={barChartData} type="bar" options={{}} />
                  </Box>
                </Grid>
              </Grid>

              <Grid container className="grid_container" spacing={3}>
                <Grid item lg={4} md={6} sm={6} xs={12}>
                  <Box className="grid_item">
                    <Typography>SHOPIFY SALES</Typography>
                    <ChartRender
                      data={barChartData1}
                      type="bar"
                      options={horizontalBarOption}
                    />
                  </Box>
                </Grid>
                <Grid item lg={4} md={6} sm={6} xs={12}>
                  <Box className="grid_item">
                    <Typography>SHOPIFY SALES</Typography>
                    <ChartRender data={barChartData1} type="line" />
                  </Box>
                </Grid>
                <Grid item lg={4} md={6} sm={6} xs={12}>
                  <Box className="grid_item">
                    <Typography>SHOPIFY SALES</Typography>
                    <ChartRender data={barChartData1} type="bar" options={{}} />
                  </Box>
                </Grid>
              </Grid>
            </Box>
          </Box>
        </Box>
      </ThemeProvider>

      {/* Modal */}
      <Modal open={open} onClose={() => setOpen(!open)}>
        <Fade in={open}>
          <Box sx={style}>
            <Typography
              sx={{
                marginBottom: 2,
                color: "white",
                fontSize: "2rem",
                fontWeight: "bold",
              }}
            >
              Task: {taskName}
            </Typography>
            <Typography
              sx={{
                marginBottom: 2,
                color: "white",
                fontSize: "1.5rem",
                fontWeight: "bold",
              }}
            >
              Count: {count}
            </Typography>

            <Button
              variant="text"
              onClick={() => handleModalClose()}
              sx={{ color: "white", fontSize: "1.15rem", fontWeight: "bold" }}
            >
              Close
            </Button>
          </Box>
        </Fade>
      </Modal>
    </>
  );
};
export default ShopifyQuickbook;
