import { useEffect, useRef } from "react";
import Chart from "chart.js/auto";

const ChartRender = ({ type, data, options }) => {
  const canvasRef = useRef(null);
  const chartRef = useRef(null);

  // Initialize the chart
  useEffect(() => {
    const ctx = canvasRef.current.getContext("2d");
    if (chartRef.current) {
      chartRef.current.destroy();
    }
    chartRef.current = new Chart(ctx, {
      type: type,
      data: data,
      options: options,
    });

    return () => {
      if (chartRef.current) {
        chartRef.current.destroy();
      }
    };
  }, []); // Only runs on initial render or if type changes

  // Update chart data and options
  useEffect(() => {
    if (chartRef.current) {
      chartRef.current.data = data;
      chartRef.current.options = options;
      chartRef.current.update();
    }
  }, [data, options]); // Runs only when data or options change

  return (
    <div>
      <canvas ref={canvasRef} />
    </div>
  );
};

export default ChartRender;
