/* eslint-disable react-hooks/rules-of-hooks */
import Navbar from "../Navbar/navbar";
import { Space, Layout } from "antd";
import TaskTile from "../TaskTile/taskTile";
import { AuthContext } from "../../../components/auth/AuthWrapper";
import { useContext, useEffect, useState } from "react";
import { Spin } from "antd";
import Background from "../../../assets/images/Background.png";

function expiredTask() {
  const [tasks, setAllTasks] = useState([]);
  const { getAllTasksExpired } = useContext(AuthContext);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    setLoading(true);
    const getTasks = async () => {
      const tasksResponse = await getAllTasksExpired();
      tasksResponse.sort((a, b) => new Date(b.deadline) - new Date(a.deadline));

      console.log(tasksResponse);
      setAllTasks(tasksResponse);
      setLoading(false);
    };
    getTasks();
  }, [getAllTasksExpired]);
  return (
    <div
      className="expired-container"
      style={{
        backgroundImage: `url(${Background})`,
        backgroundSize: "100% 100%",
        backgroundRepeat: "no-repeat",
      }}
    >
      <Navbar />
      <h1>EXPIRED TASKS</h1>
      {loading ? (
        <div className="spinner-container">
          <Spin size="large" fullscreen />
        </div>
      ) : tasks ? (
        <Layout
          style={{
            padding: 10,
            minHeight: "100vh",
            backgroundColor: "transparent",
          }}
        >
          <Space direction="vertical" style={{ width: "100%" }}>
            {tasks ? (
              tasks.map((details, index) => (
                <TaskTile key={index} data={details} />
              ))
            ) : (
              <h1>Wait...</h1>
            )}
          </Space>
        </Layout>
      ) : (
        <div>No data available</div>
      )}
    </div>
  );
}

export default expiredTask;
