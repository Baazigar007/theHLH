/* eslint-disable react/prop-types */
/* eslint-disable no-prototype-builtins */
import "./SubmitBy.css";
// import { useState } from "react";
import { Card, Button } from "antd";
import { useNavigate } from "react-router-dom";
import { useEffect, useContext, useState } from "react";
import axios from "axios";
import { AuthContext } from "../../../components/auth/AuthWrapper";
import { Spin } from "antd";

const SubmitBy = (props) => {
  console.log("Submitby ", props.data);
  const url = window.location.pathname;
  const navigate = useNavigate();
  const { token } = useContext(AuthContext);
  const [loading, setLoading] = useState(true);

  const [user, setUser] = useState({
    name: "",
    college: "",
    sorority: "",
  });
  useEffect(() => {
    setLoading(true);
    const func = async () => {
      try {
        const res = await axios.get(
          `https://hlh-v2-29a03c04aeb6.herokuapp.com/api/users/${props.data.userId}`,
          {
            headers: {
              Authorization: `Bearer ${token}`,
            },
          }
        );
        // console.log(res);
        setUser(res.data);
      } catch (error) {
        console.log(error);
      } finally {
        setLoading(false);
      }
    };
    func();
  }, []);
  return (
    <div>
      <div>
        {loading ? (
          <center className="spinner-container">
            <Spin size="medium" />
          </center>
        ) : user ? (
          <div>
            <div style={{ padding: 10 }}>
              <Card
                className="CardsContainer"
                hoverable={true}
                type="inner"
                title={
                  url === "/admin/user" ? (
                    <p className="Title">{props?.data.taskId.name}</p>
                  ) : (
                    <p>{user.name}</p>
                  )
                }
                extra={
                  <Button
                    className="OpenSubmissions"
                    onClick={() =>
                      navigate("/admin/taskdetails", {
                        state: {
                          data: props.data._id,
                          userName: user.name,
                          taskDetail: props.data.taskId,
                        },
                      })
                    }
                  >
                    Open Submission
                  </Button>
                }
              >
                <p className="cardinfo">College: {user.college}</p>
                <p className="cardinfo">Sorority: {user.sorority}</p>
                <h4 className="taskstatus">
                  Status: {props.data.status} | {props.data.payment_status}
                </h4>
              </Card>
            </div>
          </div>
        ) : (
          <div>No data available</div>
        )}
      </div>
    </div>
  );
};

export default SubmitBy;
