/* eslint-disable react/no-unknown-property */
import SubmitBy from "../SubmitBy/Submitby";
import { useLocation } from "react-router-dom";
import { useEffect, useContext, useState } from "react";
import axios from "axios";
import { Spin } from "antd";
import { AuthContext } from "../../../components/auth/AuthWrapper";
import Navbar from "../Navbar/navbar";

const TaskSubmission = () => {
  const location = useLocation();
  const [loading, setLoading] = useState(true);

  const yourPropValue = location.state?.data;

  const filterOption = location.state?.filterOption;
  const { token } = useContext(AuthContext);
  const [submissions, setSubmissions] = useState([]);

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      try {
        let res;
        if (filterOption === "All") {
          res = await axios.get(
            `https://hlh-v2-29a03c04aeb6.herokuapp.com/api/task/${yourPropValue._id}/submissions`,
            {
              headers: {
                authorization: `Bearer ${token}`,
              },
            }
          );
        } else {
          res = await axios.get(
            `https://hlh-v2-29a03c04aeb6.herokuapp.com/api/task/${yourPropValue._id}/${filterOption}/submissionsFilteredByStatus`,
            {
              headers: {
                authorization: `Bearer ${token}`,
              },
            }
          );
        }
        setSubmissions(res.data);
      } catch (error) {
        console.log("Error fetching submissions:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [filterOption, token, yourPropValue._id]);

  return (
    <>
      <Navbar />
      <div style={{ backgroundColor: "#f5f5f5", minHeight: "100vh" }}>
        {loading ? (
          // Display loading spinner while data is being fetched
          <div className="spinner-container">
            <Spin size="large" fullscreen />
          </div>
        ) : // Display fetched data or "No data available" message
        submissions && submissions.length > 0 ? (
          // Display fetched data here
          <div>
            {submissions ? (
              submissions.map((details, index) => (
                <SubmitBy
                  key={index}
                  data={details}
                  taskDetails={yourPropValue}
                />
              ))
            ) : (
              <center>
                <h1>Wait please...</h1>
              </center>
            )}
          </div>
        ) : (
          <center>No data available</center>
        )}
      </div>
    </>
  );
};

export default TaskSubmission;
