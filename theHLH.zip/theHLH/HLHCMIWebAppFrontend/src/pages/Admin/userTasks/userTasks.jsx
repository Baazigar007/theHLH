/* eslint-disable react-hooks/rules-of-hooks */
import Navbar from "../Navbar/navbar";
import { useLocation } from "react-router-dom";
import { useEffect, useState, useContext } from "react";
import axios from "axios";
import { Spin, notification } from "antd";
import { AuthContext } from "../../../components/auth/AuthWrapper";
import SubmitBy from "../SubmitBy/Submitby";
import Background from "../../../assets/images/Background.png";


function userTasks() {
  const location = useLocation();
  const { data } = location.state;
  const [loading, setLoading] = useState(true);
  const [submissionDetails, setSubmissionDetails] = useState();
  const { token } = useContext(AuthContext);

  useEffect(() => {
    setLoading(true);
    const fetchData = async () => {
      try {
        // Fetch task submissions
        const tasksubmissionsResponse = await axios.get(
          `https://hlh-v2-29a03c04aeb6.herokuapp.com/api/user/${data}/submissions`,
          {
            headers: {
              authorization: `Bearer ${token}`,
            },
          }
        );

        // Check if task submissions are available
        if (tasksubmissionsResponse && tasksubmissionsResponse.data) {
          const tasksubmissions = tasksubmissionsResponse.data;
          const detailsArray = [];
          // Loop through each task submission and fetch details
          for (let submission of tasksubmissions) {
            const submissionDetailsResponse = await axios.get(
              `https://hlh-v2-29a03c04aeb6.herokuapp.com/api/submission/${submission._id}`,
              {
                headers: {
                  authorization: `Bearer ${token}`,
                },
              }
            );

            detailsArray.push(submissionDetailsResponse.data);
          }
          console.log("2 ", detailsArray);
          await setSubmissionDetails(detailsArray);
        } else {
          notification.error({
            message: "No tasks submissions found.",
            duration: 2,
          });
        }
      } catch (error) {
        console.error("Error fetching data:", error);
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, [data, token]);

  return (
    <div className="User-task-container" style={{
      backgroundImage: `url(${Background})`,
      backgroundSize: '100% 100%',
    }}>
      <Navbar />
      <h1>SUBMISSIONS</h1>
      {loading ? (
        <div className="spinner-container">
          <Spin size="large" fullscreen />
        </div>
      ) : submissionDetails.length > 0 ? (
        <div>
          {submissionDetails ? (
            submissionDetails.map((details, index) => (
              <SubmitBy key={index} data={details} />
            ))
          ) : (
            <h3>Fetching submissions...</h3>
          )}
        </div>
      ) : (
        <center>No data available</center>
      )}
    </div>
  );
}

export default userTasks;
