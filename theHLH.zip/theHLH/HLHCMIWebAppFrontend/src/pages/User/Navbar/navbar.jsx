import { Drawer, Menu } from "antd";
import { useState } from "react";
import { MenuOutlined } from "@ant-design/icons";
import "./navbar.css";
import { useNavigate } from "react-router-dom";
import navlogo from "../../../assets/images/HLHlogo.svg"; // Import the logo image

function Navbar() {
  const [openMenu, setOpenMenu] = useState(false);
  const navigate = useNavigate();

  return (
    <div>
      <div className="menuIcon" style={{ padding: 8 }}>
        <MenuOutlined
          style={{ fontSize: 30 }}
          onClick={() => {
            setOpenMenu(true);
          }}
        />
      </div>
      <span className="headerMenu">
        <MenuComponent />
      </span>
      <Drawer
        placement="left"
        open={openMenu}
        width="60%"
        onClose={() => {
          setOpenMenu(false);
        }}
        closable={false}
      >
        <MenuComponent isInline={true} />
      </Drawer>
    </div>
  );
}

function MenuComponent({ isInline = false }) {
  const navigate = useNavigate();

  return (
    <Menu className="NavBar"
    onClick={({ key }) => {
      if (key === "logout") {
        //LOGOUT FEATURE IMPLEMENTATION
      } else {
        navigate(key);
      }
    }}
      defaultSelectedKeys={[window.location.pathname]}
      mode={isInline ? "inline" : "horizontal"}
    >
      <img src={navlogo} alt="Logo" className="navlogo" />
      <Menu.Item key="/user/activetasks" className="LabelMenu">
        Dashboard
      </Menu.Item>
      <Menu.Item key="/user/expireTasks" className="LabelMenu">
        Expired Tasks
      </Menu.Item>
      <Menu.Item key="/user/profile" className="LabelMenu">
        Profile
      </Menu.Item>
      <Menu.Item key="/user/pastsubmissions" className="LabelMenu">
        Past Submissions
      </Menu.Item>
      <Menu.Item key="/user/balance" className="LabelMenu">
        Wallet
      </Menu.Item>
      <Menu.Item key="/logout" danger className="LabelMenu">Logout</Menu.Item>
    </Menu>
  );
}

export default Navbar;
