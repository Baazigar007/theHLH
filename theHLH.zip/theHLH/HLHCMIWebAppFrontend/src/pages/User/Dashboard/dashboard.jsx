/* eslint-disable react-hooks/rules-of-hooks */
import Navbar from "../Navbar/navbar";
import { useContext, useEffect, useState } from "react";
import { AuthContext } from "../../../components/auth/AuthWrapper";
import { Space, Layout } from "antd";
import TaskTileUser from "../TaskTile/tasktileUser";
import { Spin } from "antd";
import Background from "../../../assets/images/Background.png";


function dashboard() {
  const { getAllTasks } = useContext(AuthContext);
  const [tasks, setAllTasks] = useState();
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    setLoading(true);
    const getTasks = async () => {
      try {
        const tasksResponse = await getAllTasks();
        console.log("getalltasks ", tasksResponse);
        if (tasksResponse) {
          setAllTasks(tasksResponse);
        }

        setLoading(false);
      } catch (error) {
        console.error("Error fetching tasks:", error);
        setLoading(false);
      }
    };
    getTasks();
  }, [getAllTasks]);

  return (
    <div
      className="dashboard-container"
      style={{ backgroundImage: `url(${Background})` }}
    >
      <Navbar />
      <h1>ACTIVE TASKS</h1>
      {loading ? (
        // Display loading spinner while data is being fetched
        <Spin size="large" fullscreen />
      ) : // Display fetched data or "No data available" message
      tasks && tasks.length > 0 ? (
        // Display fetched data here
        <div>
          {/* Your data rendering logic */}
          <Layout
            style={{
              padding: 12,
              minHeight: "100vh",
              backgroundColor: "transparent",
            }}
          >
            <Space direction="vertical" style={{ width: "100%" }}>
              {tasks ? (
                tasks.map((details, index) => (
                  <TaskTileUser key={index} data={details} CanSubmit={true} />
                ))
              ) : (
                <h1>Wait...</h1>
              )}
            </Space>
          </Layout>
        </div>
      ) : (
        <div style={{ textAlign: 'center' }}>No active tasks</div>
      )}
    </div>
  );
}

export default dashboard;
