/* eslint-disable react-hooks/rules-of-hooks */
import Navbar from "../Navbar/navbar";
import { Space, Layout } from "antd";
import TaskTileUser from "../TaskTile/tasktileUser";
import { AuthContext } from "../../../components/auth/AuthWrapper";
import { useContext, useEffect, useState } from "react";
import { Spin } from "antd";
import Background from "../../../assets/images/Background.png";


function expiredtasks() {
  const [tasks, setAllTasks] = useState([]);
  const { getAllTasksExpired } = useContext(AuthContext);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    setLoading(true);
    const getTasks = async () => {
      const tasksResponse = await getAllTasksExpired();
      setAllTasks(tasksResponse);
      setLoading(false);
    };
    getTasks();
  }, [getAllTasksExpired]);
  return (
    <div
      className="expired-container"
      style={{
        backgroundImage: `url(${Background})`,
        backgroundSize: "100% 100%",
        backgroundRepeat: "no-repeat"
      }}
    >
      <Navbar />
      <h1>EXPIRED TASKS</h1>
      {loading ? (
        // Display loading spinner while data is being fetched
        <div className="spinner-container">
          <Spin size="large" fullscreen />
        </div>
      ) : // Display fetched data or "No data available" message
      tasks ? (
        // Display fetched data here
        <div>
          {/* Your data rendering logic */}
          <Layout
            style={{
              padding: 10,
              minHeight: "100vh",
              backgroundColor: "transparent",
            }}
          >
            <Space direction="vertical" style={{ width: "100%" }}>
              {tasks ? (
                tasks.map((details, index) => (
                  <TaskTileUser key={index} data={details} CanSubmit={false} />
                ))
              ) : (
                <h1>Wait...</h1>
              )}
            </Space>
          </Layout>
        </div>
      ) : (
        <div>No data available</div>
      )}
    </div>
  );
}

export default expiredtasks;
