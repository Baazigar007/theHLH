/* eslint-disable react-hooks/rules-of-hooks */
import Navbar from "../Navbar/navbar";
import { AuthContext } from "../../../components/auth/AuthWrapper";
import { useContext } from "react";
import "./style2.css";
import { Card, Descriptions } from "antd";
import Background from "../../../assets/images/Background.png";

function Profile() {
  const { user } = useContext(AuthContext);
  console.log(user);
  return (
    <div className="dashboard-container" style={{ backgroundImage: `url(${Background})` }}>
      <Navbar />
      <div className="container profile-container"> {/* Apply profile-container class here */}
      <Card title={<span style={{ fontFamily: 'Hope Sans', fontSize: '20px', color: '1c1c1c'}}>Profile: {user.name}</span>}>          <Descriptions bordered column={1}>
            <Descriptions.Item label="Email" className="infofont">{user.email}</Descriptions.Item>
            <Descriptions.Item label="ID" className="infofont">{user._id}</Descriptions.Item>
            <Descriptions.Item label="Phone Number" className="infofont">{user.phoneNumber}</Descriptions.Item>
            <Descriptions.Item label="College" className="infofont">{user.college}</Descriptions.Item>
            <Descriptions.Item label="Sorority" className="infofont">{user.sorority}</Descriptions.Item>
            {user.paypalId ? (
              <Descriptions.Item label="Paypal ID" className="infofont">{user.paypalId}</Descriptions.Item>
            ) : (
              <></>
            )}
            {user.tiktokId ? (
              <Descriptions.Item label="TikTok ID" className="infofont">{user.tiktokId}</Descriptions.Item>
            ) : (
              <></>
            )}
            {user.instagram ? (
              <Descriptions.Item label="instagram" className="infofont">{user.instagram}</Descriptions.Item>
            ) : (
              <></>
            )}
            {user.vemoId ? (
              <Descriptions.Item label="Venmo ID" className="infofont">{user.vemoId}</Descriptions.Item>
            ) : (
              <></>
            )}
          </Descriptions>
        </Card>
      </div>
    </div>
  );
}

export default Profile;
