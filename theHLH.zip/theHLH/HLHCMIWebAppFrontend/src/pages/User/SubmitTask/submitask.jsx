/* eslint-disable react/no-unescaped-entities */
/* eslint-disable react-hooks/rules-of-hooks */
/* eslint-disable no-unused-vars */
import Navbar from "../Navbar/navbar";
import axios from "axios";
import "./style1.css";
import { Image, Input, Button, Upload, notification } from "antd";
import { useState, useContext, useEffect } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { AuthContext } from "../../../components/auth/AuthWrapper";
import { Spin } from "antd";
import Background from "../../../assets/images/Background.png";

function submitask() {
  const { token } = useContext(AuthContext);
  const location = useLocation();
  const { data, taskDetail, CanSubmit } = location.state;
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  const [images, setImages] = useState([]);
  const [userComment, setuserComment] = useState("");
  const [details, setDetails] = useState();
  const [PayStatus, setPayStatus] = useState("");
  const [Reward, setReward] = useState();
  const [CompletionStatus, setCompletionStatus] = useState();
  const [AdminCmment, setAdminComment] = useState();
  const [prevImages, setPrevImages] = useState([]);
  const prev_len = prevImages ? prevImages.length : 0;

  let images_count_left = 10;
  if (prevImages && prev_len > 0) {
    images_count_left = 10 - prev_len;
  }
  const handleImageChange = (e) => {
    const selectedImages = e.target.files;
    const sel_len = e.target.files.length;
    if (prev_len === 10) {
      alert("You can't upload any more images");
      e.target.value = null;
    } else if (sel_len + prev_len > 10) {
      // Display a message or take any action if the user exceeds the limit
      notification.warning({
        message: "Warning",
        description: `You can select only ${images_count_left} more images.`,
        duration: 2,
      });
      e.target.value = null;
    } else if (!selectedImages || sel_len == 0) {
      notification.warning({
        message: "Warning",
        description: "Please select some images.",
        duration: 2,
      });
    } else {
      console.log("Putting in images...");
      setImages(selectedImages);
    }
  };
  const handleCommentChange = (e) => {
    const value = e.target.value;
    if (value !== undefined && value.trim() !== "" && value !== "undefined") {
      setuserComment(value);
    }
  };
  const handleSubmit = async (e) => {
    setLoading(true);
    e.preventDefault();
    if (images.length + prev_len > 10) {
      // Display a message or take any action if the user exceeds the limit
      notification.warning({
        message: "Warning",
        description: `You can select only ${images_count_left} more images.`,
        duration: 2,
      });
      setLoading(false);
      return;
    } else if (!images || images.length == 0) {
      notification.warning({
        message: "Warning",
        description: `Please select some images.`,
        duration: 2,
      });
      setLoading(false);
      return;
    }

    const formData = new FormData();
    for (let i = 0; i < images.length; i++) {
      formData.append("images", images[i]);
    }
    // Append user_comment only if it's not undefined or empty
    if (
      userComment &&
      userComment.trim() !== "" &&
      userComment !== undefined &&
      userComment !== "undefined"
    ) {
      formData.append("user_comment", userComment);
    }

    try {
      const response = await axios.post(
        `https://hlh-v2-29a03c04aeb6.herokuapp.com/api/tasks/${data._id}/submit`,
        formData,
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );
      console.log("OK SUBMITTED", response);
      notification.success({
        message: "Success",
        description: "Task submitted successfully.",
        duration: 2,
      });
      navigate("/user/activetasks");
      // console.log(response.data);
    } catch (error) {
      notification.error({
        message: "Error",
        description: "Please try again or uplaod one image at a time.",
        duration: 2,
      });
      console.error(error);
    } finally {
      setLoading(false);
    }
  };
  useEffect(() => {
    setLoading(true);
    const fetchData = async () => {
      try {
        let res;
        if (!taskDetail) {
          res = await axios.get(
            `https://hlh-v2-29a03c04aeb6.herokuapp.com/api/task/${data._id}/submission/`,
            {
              headers: {
                Authorization: `Bearer ${token}`,
              },
            }
          );
        } else {
          res = await axios.get(
            `https://hlh-v2-29a03c04aeb6.herokuapp.com/api/task/${taskDetail._id}/submission/`,
            {
              headers: {
                Authorization: `Bearer ${token}`,
              },
            }
          );
        }

        console.log("Previous data-> ", res.data);
        setDetails(res.data);
        setPayStatus(res.data.payment_status);
        setReward(res.data.reward);
        setCompletionStatus(res.data.status);
        if (res.data.user_comment !== "undefined")
          setuserComment(res.data.user_comment);
        if (res.data.user_comment === "undefined") {
          setuserComment("");
        }
        setAdminComment(res.data.review_comment);
        setPrevImages(res.data.imageUrls);
      } catch (error) {
        console.log(error);
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, [data, token]);

  return (
    <div
      className="main-container"
      style={{ backgroundImage: `url(${Background})` }}
    >
      <Navbar />
      {loading ? (
        // Display loading spinner while data is being fetched
        <div className="spinner-container">
          <Spin size="large" fullscreen />
        </div>
      ) : // Display fetched data or "No data available" message
      data ? (
        // Display fetched data here
        <div>
          <div className="content-container">
            <div className="task-status-container">
              {CanSubmit == true ? (
                <>
                  <h3 className="title">SUBMIT YOUR TASK HERE</h3>
                  <div className="file-input-container">
                    {PayStatus === "Paid" ? (
                      <></>
                    ) : (
                      <input
                        type="file"
                        name="file"
                        className="image"
                        onChange={handleImageChange}
                        multiple
                      />
                    )}
                  </div>
                  <Input
                    className="comment-input"
                    name="comment"
                    placeholder="Add comments..."
                    defaultValue={userComment ? userComment : ""}
                    onChange={handleCommentChange}
                  />
                  {PayStatus === "Paid" ? (
                    <></>
                  ) : (
                    <Button
                      type="secondary"
                      onClick={handleSubmit}
                      className="submit-btn"
                    >
                      Submit
                    </Button>
                  )}
                </>
              ) : (
                <></>
              )}

              <h3 className="info">
                Payment status: {PayStatus ? PayStatus : "Not submitted"}
              </h3>
              <h3 className="info">
                {Reward ? `Reward: ${Reward}` : "Reward: NA"}
              </h3>
              <h3 className="info">
                {CompletionStatus
                  ? `Admin Review: ${CompletionStatus}`
                  : "Admin Review: NA"}
              </h3>
              {/* <h3 className="info">Your Comment: {userComment}</h3> */}
              <h3 className="info">
                {AdminCmment ? `Admin Comment: ${AdminCmment}` : ""}
              </h3>
            </div>
            <div className="image-container">
              {prevImages && prevImages.length > 0 ? (
                details.imageUrls.map((details, idx) => (
                  <Image
                    className="uploaded-image"
                    src={details}
                    key={idx}
                    height={300}
                    width={300}
                  />
                ))
              ) : (
                <h3 className="no-image-message">No images uploaded!</h3>
              )}
            </div>
          </div>
        </div>
      ) : (
        <div>No data available</div>
      )}
    </div>
  );
}

export default submitask;
