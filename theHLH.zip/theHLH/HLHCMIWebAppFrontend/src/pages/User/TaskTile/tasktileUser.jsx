/* eslint-disable react-hooks/rules-of-hooks */
import { Card } from "antd";
import { useNavigate, useLocation } from "react-router-dom";
function taskTileUser(details1) {
  const location = useLocation();
  const isPastSubmissionsRoute = location.pathname.includes("/pastsubmissions");
  const navigate = useNavigate();
  const details = details1.data;
  const taskDetails = details.taskId;

  // console.log(details);
  const formatDeadline = (prop) => {
    //Deadline update
    const deadlineDate = new Date(prop);
    // Get day, month, and year from the deadline date
    const day = deadlineDate.getDate();
    let month = deadlineDate.getMonth() + 1; // Months are zero-indexed
    const year = deadlineDate.getFullYear();
    if (month < 10) {
      month = `0${month}`;
    }
    return `${month}-${day}-${year}`;
  };

  return (
    <>
      {isPastSubmissionsRoute ? (
        <div>
          <Card
            className="CardsContainer"
            type="inner"
            title={
              <h2 className="Title" id="title">
                {taskDetails.name}
              </h2>
            }
            hoverable={true}
          >
            <div
              onClick={() => {
                navigate("/user/submitask", {
                  state: {
                    data: details,
                    taskDetail: taskDetails,
                    CanSubmit: details1.CanSubmit,
                  },
                });
              }}
            >
              <h4 id="desc">Description : {taskDetails.description}</h4>
              <h4 id="amount">Amount : ${taskDetails.amount}</h4>
              <h4 id="deadline">
                Deadline : {formatDeadline(taskDetails.deadline)}
              </h4>
            </div>
          </Card>
        </div>
      ) : (
        <div>
          <Card
            className="CardsContainer"
            type="inner"
            title={
              <h2 className="Title" id="title">
                {details.name}
              </h2>
            }
            hoverable={true}
          >
            <div
              onClick={() => {
                navigate("/user/submitask", {
                  state: {
                    data: details,
                    taskDetail: taskDetails,
                    CanSubmit: details1.CanSubmit,
                  },
                });
              }}
            >
              <h4 id="desc">Description : {details.description}</h4>
              <h4 id="amount">Amount : ${details.amount}</h4>
              <h4 id="deadline">
                Deadline : {formatDeadline(details.deadline)}
              </h4>
            </div>
          </Card>
        </div>
      )}
    </>
  );
}

export default taskTileUser;
