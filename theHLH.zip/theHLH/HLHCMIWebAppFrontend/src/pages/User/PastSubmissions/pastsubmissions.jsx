/* eslint-disable react-hooks/rules-of-hooks */
import Navbar from "../Navbar/navbar";
import { useContext, useEffect, useState } from "react";
import { AuthContext } from "../../../components/auth/AuthWrapper";
import { Space, Layout } from "antd";
import TaskTile from "../TaskTile/tasktileUser";
import axios from "axios";
import { Spin } from "antd";
import Background from "../../../assets/images/Background.png";

function pastsubmissions() {
  const { token, user } = useContext(AuthContext);
  const [tasks, setAllTasks] = useState();
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    setLoading(true);

    function compareDatesOnly(date1, date2) {
      const timelist = date1.split("-");
      // Extract the date components from each Date object
      const year1 = parseInt(timelist[0]);
      const month1 = parseInt(timelist[1]);
      const day1 = parseInt(timelist[2]);

      const timelist2 = date2.split(",")[0].split("/");
      const year2 = parseInt(timelist2[2]);
      const month2 = parseInt(timelist2[0]);
      const day2 = parseInt(timelist2[1]);
      // Compare the date components
      if (
        year1 < year2 ||
        (year1 === year2 &&
          (month1 < month2 || (month1 === month2 && day1 < day2)))
      ) {
        return -1;
      } else if (
        year1 > year2 ||
        (year1 === year2 &&
          (month1 > month2 || (month1 === month2 && day1 > day2)))
      ) {
        return 1;
      } else {
        return 0; // Dates are equal
      }
    }

    const getAllPastSubmissions = async () => {
      try {
        const tasks1 = await axios.get(
          `https://hlh-v2-29a03c04aeb6.herokuapp.com/api/user/${user._id}/submissions`,
          {
            headers: {
              Authorization: `Bearer ${token}`,
            },
          }
        );
        // console.log(tasks1);
        const data = [];
        for (let i = 0; i < tasks1.data.length; i++) {
          const deadlineDate = tasks1.data[i].taskId.deadline;
          const currentDate = new Date();
          const options = { timeZone: "America/Los_Angeles" };
          const pstDateString = currentDate.toLocaleString("en-US", options);
          if (compareDatesOnly(deadlineDate, pstDateString) === -1) {
            data.push(tasks1.data[i]);
          }
        }
        console.log("In Past submissions ", data);
        setAllTasks(data);
      } catch (e) {
        console.log("error alltasks ", e);
      } finally {
        setLoading(false);
      }
    };
    getAllPastSubmissions();
  }, [token, user._id]);

  return (
    <div
      className="expired-container"
      style={{
        backgroundImage: `url(${Background})`,
        backgroundSize: "100% 100%",
        backgroundRepeat: "no-repeat",
      }}
    >
      <Navbar />
      <h1>PAST SUBMISSIONS</h1>
      {loading ? (
        // Display loading spinner while data is being fetched
        <div className="spinner-container">
          <Spin size="large" fullscreen />
        </div>
      ) : // Display fetched data or "No data available" message
      tasks ? (
        // Display fetched data here
        <div>
          {/* Your data rendering logic */}
          <Layout
            style={{
              padding: 12,
              minHeight: "100vh",
              backgroundColor: "transparent",
            }}
          >
            <Space direction="vertical" style={{ width: "100%" }}>
              {tasks ? (
                tasks.map((details, index) => (
                  <TaskTile key={index} data={details} CanSubmit={false} />
                ))
              ) : (
                <h1>No tasks</h1>
              )}
            </Space>
          </Layout>
        </div>
      ) : (
        <div>No data available</div>
      )}
    </div>
  );
}

export default pastsubmissions;
