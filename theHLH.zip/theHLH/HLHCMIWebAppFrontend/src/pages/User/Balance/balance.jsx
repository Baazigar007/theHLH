import { useContext, useState, useEffect } from "react";
import Navbar from "../Navbar/navbar";
import { AuthContext } from "../../../components/auth/AuthWrapper";
import { Card, Collapse, Descriptions, Spin } from "antd";
import "./BalanceStyle.css";
import axios from "axios";
import Background from "../../../assets/images/Background.png";

function Balance() {
  const { token } = useContext(AuthContext);
  const [unreviewedtask, setUnreviewedTask] = useState([]);
  const [isUnreviewedBalanceOpen, setIsUnreviewedBalanceOpen] = useState(false);
  const [username, setUserName] = useState("");
  const [total_earned, setTotal_earned] = useState("");
  const [userBalance, setUserBalance] = useState("");
  const [userunreviewed_balance, setUserunreviewed_balance] = useState("");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    setLoading(true);

    const fetchData = async () => {
      try {
        const [profileResponse, submissionsResponse] = await Promise.all([
          axios.get("https://hlh-v2-29a03c04aeb6.herokuapp.com/api/profile", {
            headers: {
              Authorization: `Bearer ${token}`,
            },
          }),
          axios.get(
            "https://hlh-v2-29a03c04aeb6.herokuapp.com/api/submissions",
            {
              headers: {
                Authorization: `Bearer ${token}`,
              },
            }
          ),
        ]);

        const profileData = profileResponse.data;
        const submissionsData = submissionsResponse.data;

        setUserName(profileData.name);
        setTotal_earned(profileData.total_earned);
        setUserBalance(profileData.balance);
        setUserunreviewed_balance(profileData.unreviewed_balance);

        const pendingTasks = submissionsData.filter(
          (task) => task.status === "Pending"
        );
        const pendingTasksInfo = pendingTasks.map((task) => ({
          title:
            task.taskId.name.length > 20
              ? `${task.taskId.name.slice(0, 20)}...`
              : task.taskId.name,
          amount: task.taskId.amount,
        }));
        setUnreviewedTask(pendingTasksInfo);
      } catch (error) {
        console.error("Error fetching data:", error);
      } finally {
        setLoading(false);
      }
    };

    if (token) {
      fetchData();
    }
  }, [token]);

  const toggleUnreviewedBalance = () => {
    setIsUnreviewedBalanceOpen(!isUnreviewedBalanceOpen);
  };

  return (
    <div
      className="walletcontainer"
      style={{ backgroundImage: `url(${Background})` }}
    >
      <Navbar />
      {loading ? (
        <Spin size="large" fullscreen />
      ) : (
        <div className="main-card-container">
          <Card
            title={`Here's your wallet ${username}`}
            className={`main-card ${isUnreviewedBalanceOpen ? "open" : ""}`}
            style={{ width: "100%", maxWidth: "100%" }}
          >
            <Descriptions bordered column={1}>
              <Descriptions.Item label="Earned" className="themefont">
                {total_earned}
              </Descriptions.Item>
              <Descriptions.Item label="Balance" className="themefont">
                {userBalance}
              </Descriptions.Item>
              <Descriptions.Item
                label="Unreviewed Balance"
                className="themefont"
                style={{ cursor: "pointer" }}
              >
                <span onClick={toggleUnreviewedBalance}>{`${
                  userunreviewed_balance ? userunreviewed_balance : "0"
                }`}</span>
              </Descriptions.Item>
            </Descriptions>
            <div
              className="dropdown-arrow"
              style={{ cursor: "pointer" }}
              onClick={toggleUnreviewedBalance}
            ></div>
          </Card>
          <Collapse
            activeKey={isUnreviewedBalanceOpen ? ["1"] : []}
            bordered={false}
            style={{
              position: "absolute",
              left: 0,
              width: "100%",
              zIndex: 1,
              marginTop: "10px",
            }}
          >
            <Collapse.Panel key="1" header={null} showArrow={false}>
              <Card
                title={`Unreviewed Balance: ${userunreviewed_balance}`}
                className="dropdown-card"
                style={{ width: "100%", maxWidth: "100%" }}
              >
                <Descriptions bordered column={1}>
                  {unreviewedtask.map((task, index) => (
                    <Descriptions.Item
                      key={index}
                      label={task.title}
                      className="themefont"
                    >
                      {task.amount}
                    </Descriptions.Item>
                  ))}
                </Descriptions>
              </Card>
            </Collapse.Panel>
          </Collapse>
        </div>
      )}
    </div>
  );
}

export default Balance;
