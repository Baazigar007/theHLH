function missing() {
  return <div>missing</div>;
}

export default missing;
