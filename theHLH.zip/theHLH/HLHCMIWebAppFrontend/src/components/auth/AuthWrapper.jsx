import { createContext, useState, useEffect } from "react";
import axios from "axios";
import App from "../../App";
import { notification } from "antd";

export const AuthContext = createContext();

function AuthWrapper() {
  const [user, setUser] = useState(null);
  const [token, setToken] = useState(localStorage.getItem("token"));

  useEffect(() => {
    const checkLoggedInUser = async () => {
      if (token) {
        try {
          const response = await axios.get(
            "https://hlh-v2-29a03c04aeb6.herokuapp.com/api/profile",
            {
              headers: {
                Authorization: `Bearer ${token}`,
              },
            }
          );
          setUser(response.data);
        } catch (error) {
          if (error.status === 401) {
            console.log("NO TOKEN VALUE", token);
          }
        }
      }
    };

    checkLoggedInUser();
  }, [token]);

  const storetokenInLocal = (serverToken) => {
    setToken(serverToken);
    localStorage.setItem("token", serverToken);
  };

  const login = async (mail, pwd) => {
    try {
      const response = await axios.post(
        "https://hlh-v2-29a03c04aeb6.herokuapp.com/api/login",
        {
          email: mail,
          password: pwd,
        },
        {
          headers: {
            "Access-Control-Allow-Origin": "*",
          },
        }
      );
      const token = response.data.token;
      storetokenInLocal(token);
      setUser(response.data);
      notification.success({
        message: "Login Success",
        description: "You have successfully logged in.",
        duration: 2,
      });
    } catch (error) {
      console.error("Login failed:", error);
      notification.error({
        message: "Login Failed",
        description: "Failed to login. Please check your credentials.",
        duration: 2,
      });
    }
  };

  const getAllUsers = async () => {
    try {
      const res = await axios.get(
        "https://hlh-v2-29a03c04aeb6.herokuapp.com/api/users/",
        {
          headers: {
            "Access-Control-Allow-Origin": "*",
            Authorization: `Bearer ${token}`,
          },
        }
      );
      // Sort the data based on user name (converted to lowercase) in ascending order
      const sortedData = res.data.sort((a, b) => {
        const nameA = a.name.toLowerCase(); // Convert names to lowercase
        const nameB = b.name.toLowerCase();
        if (nameA < nameB) {
          return -1;
        }
        if (nameA > nameB) {
          return 1;
        }
        return 0;
      });

      // console.log(sortedData);
      return sortedData;
    } catch (e) {
      console.log("Fetching error ", e);
    }
  };

  const getAllTasks = async () => {
    try {
      const tasks = await axios.get(
        `https://hlh-v2-29a03c04aeb6.herokuapp.com/api/tasks?expired=false`,
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );
      return tasks.data;
    } catch (e) {
      console.log("error alltasks ", e);
    }
  };

  const getAllTasksExpired = async () => {
    try {
      const tasks = await axios.get(
        `https://hlh-v2-29a03c04aeb6.herokuapp.com/api/tasks?expired=true`,
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );
      return tasks.data;
    } catch (e) {
      console.log("error alltasks ", e);
    }
  };

  const LogoutUser = () => {
    setToken("");
    setUser(null);
    localStorage.removeItem("token");
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        getAllTasksExpired,
        login,
        LogoutUser,
        getAllUsers,
        storetokenInLocal,
        getAllTasks,
        token,
      }}
    >
      <App />
    </AuthContext.Provider>
  );
}

export default AuthWrapper;
