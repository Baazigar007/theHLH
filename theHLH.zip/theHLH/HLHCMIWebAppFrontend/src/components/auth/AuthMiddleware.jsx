/* eslint-disable react/prop-types */
// AuthMiddleWare.jsx
import { useContext } from "react";
import { Navigate } from "react-router-dom";
import { AuthContext } from "../auth/AuthWrapper";

function AuthMiddleware({ children }) {
  const { user } = useContext(AuthContext);

  if (!user) {
    // If user is not logged in, redirect to login
    return <Navigate to="/" />;
  }

  if (user.isAdmin) {
    // If user is an admin, render the children for admin routes
    return children;
  } else {
    // If user is not an admin, render the children for user routes
    return children;
  }
}

export default AuthMiddleware;
