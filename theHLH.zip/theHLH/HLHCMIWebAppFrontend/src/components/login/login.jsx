import { useState, useContext, useEffect } from "react";
import { AuthContext } from "../auth/AuthWrapper";
import { useNavigate } from "react-router-dom";
import { Form, Input, Button } from "antd";
import hand from "../../assets/images/HLHlogo.svg";
import background from "../../assets/images/Background.png";
import "./login.css";

const Login = () => {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const { login, user } = useContext(AuthContext);
  const navigate = useNavigate();

  const handleLogin = async () => {
    try {
      await login(username, password);
    } catch (error) {
      console.error("Login error:", error);
    }
  };

  useEffect(() => {
    if (user && user.isAdmin) {
      navigate("/admin/dashboard");
    } else if (user) {
      navigate("/user/activetasks");
    } else {
      navigate("/");
    }
  }, [user, navigate]);

  return (
    <div className="login-container">
      <div
        className="background-image"
        style={{ backgroundImage: `url(${background})` }}
      ></div>
      <div className="login-content">
        <img src={hand} alt="logo" className="logo" />
        <Form
          name="login-form"
          initialValues={{ remember: true }}
          onFinish={handleLogin}
          layout="vertical"
        >
          <Form.Item
            name="username"
            rules={[{ required: true, message: "Please input your username!" }]}
          >
            <Input
              placeholder="Username"
              className="input-field"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
            />
          </Form.Item>

          <Form.Item
            name="password"
            rules={[{ required: true, message: "Please input your password!" }]}
          >
            <Input.Password
              placeholder="Password"
              className="input-field"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
          </Form.Item>

          <Form.Item style={{textAlign: 'right'}}>
              <Button
                type="secondary"
                onClick={() => navigate("/ForgotPassword")}
                className="forget-button"
              >
                Forgot Password?
              </Button>
            </Form.Item>
          <Form.Item>
            <Button type="secondary" htmlType="submit" className="login-button">
              Sign in
            </Button>
          </Form.Item>

          <Form.Item>
            <Button
              type="secondary"
              onClick={() => navigate("/signup")}
              className="signup-button"
            >
              Create an account
            </Button>
          </Form.Item>
        </Form>
      </div>
    </div>
  );
};

export default Login;
/****/
