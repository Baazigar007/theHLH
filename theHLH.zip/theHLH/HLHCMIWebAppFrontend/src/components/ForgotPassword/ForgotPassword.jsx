import { useState } from "react";
import { Form, Input, Button, notification } from "antd";
import hand from "../../assets/images/HLHlogo.svg";
import background from "../../assets/images/Background.png";
import axios from "axios";
import { useNavigate } from "react-router-dom";

const ForgotPassword = () => {
  const [username, setUsername] = useState("");
  const navigate = useNavigate();

  const handleLogin = async () => {
    try {
      await axios
        .get(
          `https://hlh-v2-29a03c04aeb6.herokuapp.com/api/users/${username}/forgotpassword`
        )
        .then(() => {
          notification.success({
            message: "Success",
            description: "Mail successfully sent to your account",
            duration: 2,
          });
          navigate("/admin/dashboard");
        })
        .catch((err) => {
          console.log(err);
          notification.error({
            message: "Error",
            description: "Not Registered Mail account",
            duration: 2,
          });
        });
    } catch (error) {
      notification.error({
        message: "Error",
        description: "Please try again or check whether your account exists.",
        duration: 2,
      });
    }
  };

  return (
    <div className="login-container">
      <div
        className="background-image"
        style={{ backgroundImage: `url(${background})` }}
      ></div>
      <div className="login-content">
        <img src={hand} alt="logo" className="logo" />
        <h3
          style={{
            fontFamily: "Hope Sans, sans-serif",
            textAlign: "left",
            fontWeight: "400",
            fontSize: "15px",
            color: "#000000c1",
          }}
        >
          Please enter the registered email address to send your password
        </h3>
        <Form
          name="login-form"
          initialValues={{ remember: true }}
          onFinish={handleLogin}
          layout="vertical"
        >
          <Form.Item
            name="username"
            rules={[{ required: true, message: "Please input your username!" }]}
          >
            <Input
              placeholder="Email Address"
              className="input-field"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
            />
          </Form.Item>

          <Form.Item>
            <Button type="secondary" htmlType="submit" className="login-button">
              Submit
            </Button>
          </Form.Item>
        </Form>
      </div>
    </div>
  );
};

export default ForgotPassword;
/****/
