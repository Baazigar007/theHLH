import React, { useState, useEffect } from "react";
import { Button, Input, Select, notification } from "antd";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import "./signup.css";

const CreateUser = () => {
  const navigate = useNavigate();
  const [schools, setSchools] = useState([]);
  const [sororities, setSororities] = useState([]);
  const [user, setUser] = useState({
    name: "",
    email: "",
    password: "",
    phoneNumber: "",
    college: "",
    sorority: "",
    paypalId: "",
    vemoId: "",
    tiktokId: "",
    instagramId: "",
  });

  const handleChange = (value, key) => {
    setUser({ ...user, [key]: value });
  };

  const registerNewUser = async () => {
    if (
      !user.name ||
      !user.email ||
      !user.phoneNumber ||
      !user.college ||
      !user.sorority ||
      !user.password
    ) {
      notification.warning({
        message: "Warning",
        description: "Please fill all required fields.",
        duration: 2,
      });
      return;
    }
    try {
      const response = await axios.post(
        "https://hlh-v2-29a03c04aeb6.herokuapp.com/api/register",
        user
      );
      notification.success({
        message: "Success",
        description: "Your account has been successfully created! Please log in to continue.",
        duration: 2,
      });
      navigate("/");
    } catch (error) {
      if (error.response && error.response.status === 400) {
        notification.error({
          message: "Email already registered",
          description: "Please log in or use a different email.",
          duration: 2,
        });
      } else {
        notification.error({
          message: "Please try again later",
          duration: 2,
        });
      }
    }
  };

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [sororityRes, collegeRes] = await Promise.all([
          axios.get("https://hlh-v2-29a03c04aeb6.herokuapp.com/api/sororities"),
          axios.get("https://hlh-v2-29a03c04aeb6.herokuapp.com/api/colleges"),
        ]);
        setSororities(sororityRes.data);
        setSchools(collegeRes.data);
      } catch (error) {
        console.error("Error fetching data:", error);
      }
    };
    fetchData();
  }, []);

  return (
    <div style={{ backgroundColor: "rgba(0, 0, 0, 0.02)", minHeight: "100vh" }}>
      <div className="createuser-body">
        <section className="create-user-form">
          <h1 className="title">Create a New Account</h1>
          <Input
            className="user-input"
            placeholder="* Full Name"
            onChange={(e) => handleChange(e.target.value, "name")}
            required
          />
          <Input
            className="user-input"
            placeholder="* Email Address"
            onChange={(e) => handleChange(e.target.value, "email")}
            required
          />
          <Input.Password
            className="user-input"
            placeholder="* Password"
            onChange={(e) => handleChange(e.target.value, "password")}
            required
          />
          <Input
            className="user-input"
            placeholder="* Phone Number"
            onChange={(e) => handleChange(e.target.value, "phoneNumber")}
            required
          />
          <Select
            className="type-drop"
            placeholder="* College"
            onChange={(value) => handleChange(value, "college")}
            showSearch
            optionFilterProp="children"
            filterOption={(input, option) =>
              option.children.toLowerCase().indexOf(input.toLowerCase()) >= 0
            }
            required
          >
            {schools.map((school) => (
              <Select.Option key={school._id} value={school.name}>
                {school.name}
              </Select.Option>
            ))}
            <Select.Option value="other">Other (Type Your College)</Select.Option>
          </Select>
          <Select
            className="type-drop"
            placeholder="* Sorority"
            onChange={(value) => handleChange(value, "sorority")}
            showSearch
            optionFilterProp="children"
            filterOption={(input, option) =>
              option.children.toLowerCase().indexOf(input.toLowerCase()) >= 0
            }
            required
          >
            {sororities.map((sorority) => (
              <Select.Option key={sorority._id} value={sorority.text}>
                {sorority.text}
              </Select.Option>
            ))}
            <Select.Option value="other">Other (Type Your Sorority)</Select.Option>
          </Select>
          <Input
            className="user-input"
            placeholder="PayPal Email"
            onChange={(e) => handleChange(e.target.value, "paypalId")}
          />
          <Input
            className="user-input"
            placeholder="Venmo Username"
            onChange={(e) => handleChange(e.target.value, "vemoId")}
          />
          <Input
            className="user-input"
            placeholder="Tiktok"
            onChange={(e) => handleChange(e.target.value, "tiktokId")}
          />
          <Input
            className="user-input"
            placeholder="Instagram"
            onChange={(e) => handleChange(e.target.value, "instagramId")}
          />
          <Button
            type="secondary"
            onClick={registerNewUser}
            className="submit-button"
          >
            Submit
          </Button>
        </section>
      </div>
    </div>
  );
};

export default CreateUser;
