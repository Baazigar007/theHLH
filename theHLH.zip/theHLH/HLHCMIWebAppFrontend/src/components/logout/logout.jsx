/* eslint-disable react-hooks/rules-of-hooks */
import { useContext, useEffect } from "react";
import { Navigate } from "react-router-dom";
import { AuthContext } from "../auth/AuthWrapper";

function logout() {
  const { LogoutUser } = useContext(AuthContext);
  useEffect(() => {
    LogoutUser();
  }, [LogoutUser]);
  return <Navigate to="/" />;
}

export default logout;
