import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

// https://vitejs.dev/config/
export default defineConfig({
  plugins: [react()],
  base: "/", // Ensure base path is set correctly
  server: {
    proxy: {
      "/api/shopify": {
        target: "https://volleyballjewels.myshopify.com/",
        changeOrigin: true,
        // rewrite: (path) => path.replace(/^\/api\/shopify/, ""),
        rewrite: (path) => {
          // console.log("Rewriting Shopify path:", path);
          return path.replace(/^\/api\/shopify/, "");
        },
      },
      "/api/quickbooks": {
        target: "https://sandbox-quickbooks.api.intuit.com/",
        changeOrigin: true,
        rewrite: (path) => path.replace(/^\/api\/quickbooks/, ""),
      },
    },
  },
});
