import { useEffect } from "react";
import { useNavigate } from "react-router-dom";
import realm_app from "./backend/UserContext"; // Replace with the actual import statement for your UserContext

const AuthMiddlewareAdmin = ({ children }) => {
  const navigate = useNavigate();
  useEffect(() => {
    // Check if currentUser is not null
    if (
      !realm_app.currentUser ||
      !realm_app.currentUser.customData ||
      realm_app.currentUser.customData.isAdmin === undefined
    ) {
      // Redirect to the 404 page or any other action
      console.error("ADMIN User not authenticated. Redirecting to 404 page.");
      navigate("/404"); // Replace '/404' with your actual 404 page URL
    }
  }, [navigate]);

  // Render the children if currentUser is not null
  if (
    realm_app.currentUser &&
    realm_app.currentUser.customData &&
    realm_app.currentUser.customData.isAdmin !== undefined
  ) {
    return children;
  } else {
    return null;
  }
};

export default AuthMiddlewareAdmin;
