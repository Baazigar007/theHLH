import "./BalanceTile.css"
const BalanceTile= (props) =>{
    return (
        <>
            <div className="tile-box">
                
                <div className="tile-right">
                    <div className="tile-info">
                        <p><b>Title :</b> {props.data.title}</p>
                        <p><b>Status :</b> {props.data.status}</p>
                        <p><b>Amount :</b> +{props.data.reward}$</p>
                        <p className="b-cmt"><b>Comment :</b> {props.data.comment}</p>
                        <p className="b-cmt"><b>Review :</b> {props.data.adminComment}</p>
                    </div>
                   
                </div>
            </div>
        </>
    )
}

export default BalanceTile;