import "./TasksTileUser.css";

const TasksTileUser = (props) => {
  return (
    <>
      <div className="taskstilebodyuser">
        <div>
        <p className="tile-desc-user"><b>Task Desc:</b> {props.data.description}</p>
          <p className="tile-desc-user"><b>Task Amount:</b> {props.data.amount}</p>
          <p className="tile-desc-user"><b>Task Deadline:</b> {props.data.deadline}</p>
        </div>
      </div>
    </>
  );
};

export default TasksTileUser;
