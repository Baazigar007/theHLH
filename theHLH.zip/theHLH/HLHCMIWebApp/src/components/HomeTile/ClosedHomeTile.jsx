import "./HomeTile.css";
import pinkhand from "../../images/hand-pink.svg";
const ClosedHomeTile = (props) => {
  return (
    <>
      <div
        className="home-tile-box"
      >
        <div className="home-tile-right">
          <div className="home-tile-info">
            <p className="home-tile-head">{props.data.title}</p>
            <p className="home-tile-desc">
              <b>Desc: </b>
              {props.data.description}
            </p>
            <p className="home-tile-para">
              <b>Deadline:</b> {props.data.deadline}
            </p>
            <p className="home-tile-para">
              <b>Task Amount:</b> $ {props.data.amount}
            </p>
          </div>
          <img src={pinkhand} alt="pink-hand-logo"></img>
        </div>
      </div>
    </>
  );
};

export default ClosedHomeTile;
