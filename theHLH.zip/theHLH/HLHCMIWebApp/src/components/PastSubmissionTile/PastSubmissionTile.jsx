
import "./PastSubmissionTile.css"
const PastSubmissionTile= (props) =>{
    return (
        <>
            <div className="tile-box">
                
                <div className="tile-right">
                    <div className="tile-info">
                        <p><b>Title : </b>{props.data.title}</p>
                        <p><b>Status : </b>{props.data.status}</p>
                        <p className="ps-cmt"><b>Comment : </b>{props.data.comment}</p>
                        <p className="ps-cmt"><b>Review : </b>{props.data.adminComment}</p>
                    </div>
                   
                </div>
            </div>
        </>
    )
}

export default PastSubmissionTile;