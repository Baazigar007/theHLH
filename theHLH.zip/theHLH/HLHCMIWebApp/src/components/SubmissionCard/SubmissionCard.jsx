import { useNavigate } from "react-router-dom";
import acc_icon from "../../images/account_icon.png";
import handyellow from "../../images/hand-yellow.svg";
import { useEffect, useState } from "react";
import fetchadminwallet from "../../backend/fetchadminwallet";
import "./SubmissionCard.css";

const SubmissionCard = (props) => {
  const [earn, setearn] = useState();
  const [bal, setbal] = useState();
  const navigate = useNavigate();
  async function fetchdetails() {
    // console.log('Fetching details');
    const res = await fetchadminwallet(props.data.userId);
    setearn(res[0]);
    setbal(res[1]);
  }
  useEffect(() => {
    fetchdetails();
  }, []);

  return (
    <>
      <div className="card-parent">
        <div className="card-left">
          <img src={acc_icon} alt="" srcset="" />
        </div>
        <div className="card-right">
          <div className="subcard-left">
            <strong>
              <p
                onClick={() =>
                  navigate("/admin/usertasks?userid=" + props.data.userId)
                }
                className="Username"
              >
                Name: {props.data.name}
              </p>
            </strong>

            <div
              style={{
                display: "flex",
                alignItems: "center",
                marginBottom: "8px",
              }}
            >
              <img
                src="https://cdn.pixabay.com/photo/2016/09/17/07/03/instagram-1675670_1280.png"
                alt="Instagram Logo"
                width="20"
                height="20"
                style={{ marginRight: "8px" }}
              />
              <a
                href={"https://www.instagram.com/" + props.data.instagram}
                target="_blank"
                rel="noreferrer"
              >
                {props.data.instagram}
              </a>
            </div>

            <div
              style={{
                display: "flex",
                alignItems: "center",
                marginBottom: "8px",
              }}
            >
              <img
                src="https://images.crunchbase.com/image/upload/c_lpad,f_auto,q_auto:eco,dpr_1/jpjprxh75yx1gvqkxflp"
                alt="Venmo Logo"
                width="20"
                height="20"
                style={{ marginRight: "8px" }}
              />
              <a
                href={"https://www.venmo.com/" + props.data.venmo}
                target="_blank"
                rel="noreferrer"
              >
                {props.data.venmo}
              </a>
            </div>

            <div
              style={{
                display: "flex",
                alignItems: "center",
                marginBottom: "8px",
              }}
            >
              <img
                src="https://cdn.pixabay.com/photo/2021/06/15/12/28/tiktok-6338430_1280.png"
                alt="TikTok Logo"
                width="20"
                height="20"
                style={{ marginRight: "8px" }}
              />
              <a
                href={"https://www.tiktok.com/@" + props.data.tiktok}
                target="_blank"
                rel="noreferrer"
              >
                {props.data.tiktok}
              </a>
            </div>

            <strong>
              <p>College: {props.data.college}</p>
            </strong>

            <p>
              Total Submissions:{" "}
              {props.data.taskSubmissions
                ? props.data.taskSubmissions.length
                : 0}
            </p>
            <p>Total Earned: {earn}</p>
            <p>Balance Remaining: {bal}</p>
          </div>
          <img src={handyellow} alt="" className="subcard-right" />
        </div>
      </div>
    </>
  );
};

export default SubmissionCard;
