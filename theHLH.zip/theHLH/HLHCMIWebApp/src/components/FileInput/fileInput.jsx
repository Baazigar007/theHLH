import React, { useState } from "react";
import heic2any from "heic2any";
import "./fileInput.css";
import ImageRenderer from "./ImageRenderer";
import Toast from "../Toast/Toast";

function FileInput({ imgArray, setImgArray }) {
  const [show, setShow] = useState(false);
  const [message, setMessage] = useState(
    "You can only upload a maximum of 10 images"
  );
  const [loading, setLoading] = useState(false);

  const handleFileChange = async (e) => {
    console.log("handlefilechange called");

    if (imgArray.length >= 10) {
      setShow(true);
      return;
    }

    const newImages = [];

    for (const file of e.target.files) {
      console.log("checking: ", file);

      if (imgArray.length + newImages.length >= 10) {
        setShow(true);
        break;
      }

      // Check if the file has a .heic extension
      if (
        file.name.toLowerCase().endsWith(".heic") ||
        file.name.toLowerCase().endsWith(".HEIC") ||
        file.name.toLowerCase().endsWith(".heif")
      ) {
        console.log("HEIC/heif file detected");
        setLoading(true);

        try {
          // Convert HEIC to JPEG using heic2any
          const jpegBlob = await heic2any({ blob: file });
          jpegBlob.name = file.name;
          newImages.push(jpegBlob);
        } catch (error) {
          console.error("HEIC to JPEG conversion error:", error);
          // If conversion fails, add the original HEIC file
          newImages.push(file);
        } finally {
          setLoading(false);
        }
      } else {
        console.log("Non-HEIC file detected");
        // If it's not a HEIC file, just add it to the newImages array
        newImages.push(file);
      }
    }

    setImgArray([...imgArray, ...newImages]);
  };

  const handleImageRemoval = (file) => {
    if (file) {
      const updatedArray = imgArray.filter((img) => img.name !== file);
      setImgArray(updatedArray);
    }
  };

  return (
    <>
      <div className="upload__box">
        <div className="upload__btn-box">
          <label className="upload__btn">
            <p>Upload images</p>
            <input
              type="file"
              multiple
              max={10}
              accept="image/* image/heic image/heif image/png image/jpeg image/jpg"
              className="upload__inputfile"
              onChange={handleFileChange}
            />
          </label>
        </div>
        {loading && <p>Converting images... Please wait.</p>}
        <div className="upload__img-wrap">
          {imgArray.map((file, index) => (
            <ImageRenderer
              key={index}
              file={file}
              handleImageRemoval={handleImageRemoval}
            />
          ))}
        </div>
      </div>
      {show && <Toast show={show} setShow={setShow} message={message} />}
    </>
  );
}

export default FileInput;
