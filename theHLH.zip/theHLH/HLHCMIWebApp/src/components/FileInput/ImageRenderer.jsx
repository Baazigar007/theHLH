import React, { useState } from "react";

const ImageRenderer = ({ file, handleImageRemoval }) => {
  const [img, setImg] = useState(null);
  const reader = new FileReader();
  reader.onload = (e) => {
    setImg(e.target.result);
  };
  reader.readAsDataURL(file);

  return (
    <div className="upload__img-box">
      <div style={{ backgroundImage: `url(${img})` }} className="img-bg">
        <div
          className="upload__img-close"
          onClick={() => handleImageRemoval(file.name)}
        ></div>
      </div>
    </div>
  );
};

export default ImageRenderer;
