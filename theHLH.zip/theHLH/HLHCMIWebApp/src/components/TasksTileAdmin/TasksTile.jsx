import "./TasksTile.css";
import edit from "../../images/pencil.svg";
import tick from "../../images/tick.svg";
import EditTask from "../../pages/admin/EditTask/EditTask";
import Modal from "react-modal";
import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import formatDate from "../../backend/functionDate";
import { useLocation } from "react-router-dom";

const TasksTile = (props) => {
  const date = formatDate(props.data.deadline);
  const [modalIsOpen1, setIsOpen1] = useState(false);
  const [inExpired, setinExpired] = useState(false);
  const navigate = useNavigate();
  // const history = useHistory();
  const location = useLocation();

  function closeModal1() {
    setIsOpen1(false);
  }

  useEffect(() => {
    function setboolean() {
      const yourPropValue = location.pathname;
      if (yourPropValue === "/admin/ExpiredTasks") {
        setinExpired(true);
      }
    }
    setboolean();
  });

  return (
    <>
      <div className="taskstilebody">
        <div className="tile-details">
          <strong>
            <p>{props.data.title}</p>
          </strong>
          <strong>
            <p>{props.data.status}</p>
          </strong>
          <p>
            <b>Task Desc: </b>
            {props.data.description}
          </p>

          <p>
            <b>Task Amount: </b>
            {props.data.amount}
          </p>
          <p>
            <b>Task Deadline: </b>
            {date}
          </p>
          {props.tasks && (
            <p>
              <b>Number of Submissions: </b>
              {props.data.completed_by.length}
            </p>
          )}
        </div>
        {/* SHOWING LIST */}
        <div className="modal-btn">
          <div
            onClick={() => {
              if (inExpired === true) {
                navigate("/admin/taskSubmissions", {
                  state: { data: props.data },
                });
              } else
                navigate("./taskSubmissions", { state: { data: props.data } });
            }}
            style={{ cursor: "pointer" }}
          >
            <img src={tick} alt="" />
          </div>
          {/* SHOWING EDIT OPTION */}
          <div
            onClick={() => {
              setIsOpen1(true);
            }}
            style={{ cursor: "pointer" }}
          >
            <img src={edit} alt="" />
          </div>
          <Modal
            style={{ content: { backgroundColor: "#E48EC3" } }}
            isOpen={modalIsOpen1}
            onRequestClose={closeModal1}
            contentLabel="Edit Task Modal"
          >
            <EditTask data={props.data} setOpen={closeModal1} />
          </Modal>
        </div>
      </div>
    </>
  );
};

export default TasksTile;
