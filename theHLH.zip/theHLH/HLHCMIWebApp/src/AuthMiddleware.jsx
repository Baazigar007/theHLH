import React, { useEffect } from "react";
import { useNavigate } from "react-router-dom";
import realm_app from "./backend/UserContext"; // Replace with the actual import statement for your UserContext

const AuthMiddleware = ({ children }) => {
  const navigate = useNavigate();

  useEffect(() => {
    // Check if currentUser is not null
    if (!realm_app.currentUser) {
      // Redirect to the 404 page or any other action
      console.error("User not authenticated. Redirecting to 404 page.");
      navigate("/404"); // Replace '/404' with your actual 404 page URL
    }
  }, [navigate]);

  // Render the children if currentUser is not null
  return realm_app.currentUser ? children : null;
};

export default AuthMiddleware;
