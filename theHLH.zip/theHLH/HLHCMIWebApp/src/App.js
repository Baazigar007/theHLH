import "./App.css";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import LoginPage from "./pages/Login/Login";
import AdminDashboard from "./pages/admin/AdminDashboard/AdminDashboard";
import BulkTasks from "./pages/admin/BulkTasks/BulkTasks";
import ProfilePage from "./pages/Login/Profile";
import PastSubmission from "./pages/Login/PastSubmission";
import Balance from "./pages/Login/Balance";
import UserTasks from "./pages/admin/UserTasks/UserTasks";
import TaskDetails from "./pages/admin/TaskDetails/TaskDetails";
import SubmitTask from "./pages/Login/SubmitTask";
import CreateUser from "./pages/admin/CreateUser/CreateUser";
import HomePage from "./pages/Login/Home";
import CreateTask from "./pages/admin/CreateTask/CreateTask";
import EditTask from "./pages/admin/EditTask/EditTask";
import TaskSubmission from "./pages/admin/Tasksubmission/Tasksubmission";
import ExpiredTasks from "./pages/admin/ExpiredTask/ExpiredTask";
import AuthMiddleware from './AuthMiddleware';
import NotFoundPage from "./pages/NotFoundPage";
import AuthMiddlewareAdmin from "./AuthMiddlewareAdmin";



const App = () => {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<LoginPage />} />
        <Route path="/createuser" element={<CreateUser />} />


        <Route path="/home" element={<AuthMiddleware><HomePage /></AuthMiddleware>} />
        <Route path="/profile" element={<AuthMiddleware><ProfilePage /></AuthMiddleware>} />
        <Route path="/pastsubmission" element={<AuthMiddleware><PastSubmission /></AuthMiddleware>} />
        <Route path="/balance" element={<AuthMiddleware><Balance /></AuthMiddleware>} />
        <Route path="/submit" element={<AuthMiddleware><SubmitTask /></AuthMiddleware>} />

        <Route path="/admin/" element={<AuthMiddlewareAdmin><BulkTasks /></AuthMiddlewareAdmin>} />
        <Route path="/admin/bulkusers" element={<AuthMiddlewareAdmin><AdminDashboard /></AuthMiddlewareAdmin>} />
        <Route path="/admin/usertasks" element={<AuthMiddlewareAdmin><UserTasks /></AuthMiddlewareAdmin>} />
        <Route path="/admin/taskdetails" element={<AuthMiddlewareAdmin><TaskDetails /></AuthMiddlewareAdmin>} />
        <Route path="/admin/createtask" element={<AuthMiddlewareAdmin><CreateTask /></AuthMiddlewareAdmin>} />
        <Route path="/admin/edittask" element={<AuthMiddlewareAdmin><EditTask /></AuthMiddlewareAdmin>} />
        <Route path="/admin/taskSubmissions" element={<AuthMiddlewareAdmin><TaskSubmission /></AuthMiddlewareAdmin>} />
        <Route path="/admin/ExpiredTasks" element={<AuthMiddlewareAdmin><ExpiredTasks /></AuthMiddlewareAdmin>} />
        <Route path="/404" element={<NotFoundPage />} />
      </Routes>
    </BrowserRouter>
  );
};

export default App;