import "./Home.css";
import TopSheet from "../../components/TopSheet/TopSheet";
import HomeTile from "../../components/HomeTile/HomeTile";
import ClosedHomeTile from "../../components/HomeTile/ClosedHomeTile";
import { useNavigate } from "react-router-dom";
import { useEffect, useState } from "react";
import loginStatus from "../../backend/loginStatus";
import avatar from "../../images/avatar.svg";
import realm_app from "../../backend/UserContext";
import fetchActiveTasks from "../../backend/fetchActiveTasks";
import fetchClosedTasks from "../../backend/fetchClosedTasks";

export default function HomePage() {
  const [list, setList] = useState([]);
  const [name, setName] = useState(null);
  const [closed_tasks, setClosedList] = useState([]);
  const [activetasks, setactivetasks] = useState(true);

  const navigate = useNavigate();
  useEffect(() => {
    async function checkLogin() {
      var x = await loginStatus();
      //console.log("checking", x);
      if (x.isLogged === true) {
        if (x.isAdmin) {
          navigate("/admin");
        }
      } else {
        navigate("/");
      }
    }
    checkLogin();
  }, [navigate]);

  useEffect(() => {
    try {
      let namee = null;
      if (realm_app.currentUser) {
        namee = realm_app.currentUser.customData.name;
        setName(namee);
      } else {
        console.log("ERROR-3");
        navigate("/");
      }
    } catch (error) {
      //console.log(error);
      console.log("ERROR-4");
      navigate("/");
    }
  }, []);

  useEffect(() => {
    // logic to fetch active data
    async function getTasks() {
      const tasks = await fetchActiveTasks();
      //  console.log("Gettasks-> ",tasks);
      tasks.sort((a, b) => new Date(a.deadline) - new Date(b.deadline));

      setList(tasks);
    }
    getTasks();
  }, []);

  useEffect(() => {
    // logic to fetch closed data
    async function getClosedTasks() {
      const tasks = await fetchClosedTasks();
      //  console.log("Getclosed-> ",tasks);
      tasks.sort((a, b) => new Date(a.deadline) - new Date(b.deadline));

      setClosedList(tasks);
    }
    getClosedTasks();
  }, []);
  return (
    <>
      <div className="homebody">
        <TopSheet />
        <div className="h-head">
          <h2>Home</h2>
        </div>

        <div className="h-bottom">
          <div className="p-image">
            <img className="image" src={avatar} alt="pfp" />
          </div>
          <div>
            <h2 className="u-head">Hi {name}</h2>
          </div>
          <div style={{ marginTop: "2rem" }}>
            <button
              onClick={() => setactivetasks(!activetasks)}
              style={{ padding: "1rem" }}
            >
              {activetasks ? "Show Closed Tasks" : "Show Active Tasks"}
            </button>
          </div>

          {activetasks ? (
            <>
              <h4>Checkout your active tasks!</h4>
              <div className="tasks">
                {list.length === 0 ? (
                  <p>No tasks!</p>
                ) : (
                  list.map((item) => {
                    return <HomeTile key={item._id} data={item} />;
                  })
                )}
              </div>
            </>
          ) : (
            <>
              <h4>Your closed tasks!</h4>
              <div className="tasks">
                {closed_tasks.length === 0 ? (
                  <p>No tasks!</p>
                ) : (
                  closed_tasks.map((item) => {
                    return <ClosedHomeTile key={item._id} data={item} />;
                  })
                )}
              </div>
            </>
          )}
        </div>
      </div>
    </>
  );
}
