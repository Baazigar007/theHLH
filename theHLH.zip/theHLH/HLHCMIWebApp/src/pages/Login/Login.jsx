import "./Login.css";
import logo from "../../images/logo.svg";
import logotext from "../../images/logotext.svg";
import handblue from "../../images/hand-blue.svg";
import { useEffect, useState } from "react";
import loginStatus from "../../backend/loginStatus";
import { useNavigate } from "react-router-dom";
import login from "../../backend/login";
import Loading from "../../components/Loading/Loading";
import realm_app from "../../backend/UserContext";
import Toast from "../../components/Toast/Toast";
import CreateUser from "../admin/CreateUser/CreateUser";

export default function LoginPage() {
  const [show, setShow] = useState(false);
  const [message, setMessage] = useState("");
  const [email, setEmail] = useState(null);
  const [pwd, setPwd] = useState(null);
  const [loading, setLoading] = useState(false);

  function loginWithEmailPass() {
    setLoading(true);
    console.log(email, pwd);

    if (email === null || pwd === null) {
      setShow(true);
      setMessage("Please fill all the fields");
      setLoading(false);
    } else {
      login(email, pwd).then((_) => {
          console.log("user logged in");
          setLoading(false);
          checkLogin();
        })
        .catch((error) => {
          //console.log(error.error);
          setShow(true);
          setMessage("Invalid Credentials!");
          setLoading(false);
        });
    }
  }

  async function checkLogin() {
    var x = await loginStatus();
    //console.log("checking", x);
    if (x.isLogged === true) {
      if (x.isAdmin) {
        navigate("/admin");
      } else {
        navigate("/home");
      }
    }
  }

  const navigate = useNavigate();
  useEffect(() => {
    async function checkLogin() {
      var x = await loginStatus();
      //console.log("checking", x);
      if (x.isLogged === true) {
        if (x.isAdmin) {
          navigate("/admin");
        } else {
          navigate("/home");
        }
      }
    }
    checkLogin();
  }, [navigate]);
  return (
    <>
      {loading ? (
        <Loading />
      ) : (
        <div className="loginbody">
          <img src={logotext} className="logotext" alt="" />
          <img src={logo} alt="" />
          <div className="loginbottom">
            <div className="campus-text">
              <p>Campus Ambassador Program</p>
            </div>
            <div className="loginfields">
              <input
                type="text"
                className="login-input"
                placeholder="Username"
                value={email}
                onChange={(event) => {
                  const val = event.target.value;
                  const val1 = val.split(" ");
                  const val2 = val1.join("");
                  setEmail(val2);
                }}
              />
              <input
                type="password"
                className="login-input"
                placeholder="Password"
                value={pwd}
                onChange={(event) => {
                  setPwd(event.target.value);
                }}
              />
              <button
                className="loginbtn-button"
                onClick={() => loginWithEmailPass()}
              >
                <div className="loginbtn">
                  <p>Sign In</p>
                  <img src={handblue} alt="" />
                </div>
              </button>
              <button
                className="loginbtn-button" onClick={() => navigate("/createuser")}>
                <div className="loginbtn">
                  <p>Register</p>
                  <img src={handblue} alt="" />
                </div>
              </button>
            </div>
          </div>
        </div>
      )}
      {show && <Toast show={show} setShow={setShow} message={message} />}
    </>
  );
}
