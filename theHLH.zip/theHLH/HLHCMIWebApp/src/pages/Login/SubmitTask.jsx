import { useNavigate, useParams } from "react-router-dom";
import TasksTileUser from "../../components/TasksTileUser/TasksTileUser";
import "./SubmitTask.css";
import { useEffect } from "react";
import loginStatus from "../../backend/loginStatus";
import { useState } from "react";
import SubmitData from "../../backend/submitTask";
import handblue from "../../images/hand-blue.svg";
import realm_app from "../../backend/UserContext";
import fetchSingleTask from "../../backend/fetchSingleTask";
import Modal from "react-modal";
import updateData from "../../backend/updateTask";
import Loading from "../../components/Loading/Loading";
import Topsheet from "../../components/TopSheet/TopSheet";
import FileInput from "../../components/FileInput/fileInput";
import Toast from "../../components/Toast/Toast";
import tasktouserId from "../../backend/tasktouserId";
import fetchImages from "../../backend/fetchImages";

const SubmitTask = () => {
  //checked logged in
  const [show, setShow] = useState(false);
  const [message, setMessage] = useState("");
  const [taskDetails, setTaskDetails] = useState({});
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [Imgloading, ImgsetLoading] = useState(false);
  const [images, setImages] = useState([]);
  const [oldimages, setoldImages] = useState([]);

  useEffect(() => {
    async function checkLogin() {
      var x = await loginStatus();
      if (x.isLogged === true) {
        if (x.isAdmin) {
          navigate("/admin");
        }
      } else {
        navigate("/");
      }
    }
    checkLogin();
  }, [navigate]);

  const params = useParams();

  useEffect(() => {
    setLoading(true);

    ImgsetLoading(true);
    const searchParams = new URLSearchParams(window.location.search);
    const id = searchParams.get("taskid");

    async function getTask(id) {
      const data = await fetchSingleTask(id);
      if (data !== null) {
        setTaskDetails(data);
      }

      const user_ID = await realm_app.currentUser.customData.userId;
      const getSubmitId = await tasktouserId(id, user_ID);
      const oldimages1 = await fetchImages(getSubmitId);
      ImgsetLoading(false);
      // console.log("Oldimages- ", oldimages1);
      setoldImages(oldimages1);
    }
    getTask(id);
    setLoading(false);
  }, [params]);
  let user_data,
    user_id = null;

  try {
    if (realm_app.currentUser) {
      user_data = realm_app.currentUser.customData;
      user_id = user_data.userId;
    } else {
      console.log("ERROR-6");
      navigate("/");
    }
  } catch (error) {
    console.log("ERROR-7");
    navigate("/");
  }

  const [comment, setComment] = useState(null);

  // Asynchronous function to read a file as a Data URL
  async function readAsDataURLAsync(file) {
    const reader = new FileReader();

    return new Promise((resolve, reject) => {
      reader.onload = function () {
        resolve(reader.result);
      };

      reader.onerror = function (error) {
        reject(error);
      };

      reader.readAsDataURL(file);
    });
  }

  // Asynchronous function to compress an image using a specified compression factor
  async function compressImageAsync(dataUrl, compressionFactor) {
    return new Promise((resolve) => {
      const img = new Image();
      img.src = dataUrl;
      img.onload = function () {
        const canvas = document.createElement("canvas");
        const ctx = canvas.getContext("2d");
        canvas.width = img.width;
        canvas.height = img.height;
        ctx.drawImage(img, 0, 0, img.width, img.height);
        canvas.toBlob(
          (blob) => {
            resolve(blob);
          },
          "image/webp",
          compressionFactor
        );
      };
    });
  }

  async function submission() {
    setLoading(true);
    try {
      if (oldimages && oldimages.length === 10) {
        setShow(true);
        setMessage(`You cannot upload anymore images`);
      } else if (oldimages && images.length + oldimages.length > 10) {
        setShow(true);
        let temp = 10 - oldimages.length;
        setMessage(`You can only upload ${temp} more images`);
      } else if (images.length < 1) {
        setShow(true);
        setMessage("Upload at least one image");
      } else {
        let imgarray = null;
        try {
          imgarray = await Promise.all(
            images.map(async (image) => {
              const dataUrl = await readAsDataURLAsync(image);
              const compressedBlob = await compressImageAsync(dataUrl, 0.1);
              const compressedImageDataUrl = await readAsDataURLAsync(
                compressedBlob
              );
              return compressedImageDataUrl;
            })
          );
        } catch (error) {
          console.log("Images didn't compress properly..");
        }

        // Prepare submission object
        const submitObject = {
          title: taskDetails.title,
          comment: comment,
          user_id: user_id,
          task_id: taskDetails._id,
          reward: 0,
          status: "pending",
          amount: taskDetails.amount,
          description: taskDetails.description,
          deadline: taskDetails.deadline,
          userdata: user_data,
        };

        // Submit data and update task details
        const var1 = await SubmitData(submitObject, imgarray, oldimages.length);
        console.log("Var1 ", var1);
        if (var1 === 0) {
          const resofUpdate = await updateData(taskDetails, user_id);
          if (resofUpdate === 0) {
            alert("Your Images have been updated..");
          } else {
            alert(
              "Could you please upload the task again, or alternatively, upload the images one at a time?"
            );
          }
        } else {
          alert(
            "Could you please upload the task again, or alternatively, upload the images one at a time?"
          );
        }

        // Display success message
        setShow(true);
        setMessage("Task submitted successfully!");

        // Navigate to the home page
        navigate("/home");
      }
    } catch (error) {
      // Handle any errors that occur during the submission process
      console.error("Submission error:", error);
      setShow(true);
      setMessage("An error occurred during submission");
    } finally {
      // Ensure loading indicator is turned off
      setLoading(false);
    }
  }

  const [isOpen, setIsOpen] = useState(false);

  const closeModal = () => {
    setIsOpen(false);
  };

  return (
    <>
      {loading ? (
        <Loading />
      ) : (
        <div className="submit-task-body">
          <Topsheet />
          <div className="submit-task-header">
            <p>{taskDetails.title}</p>
          </div>
          <TasksTileUser data={taskDetails} />

          {Imgloading ? (
            <p>Please wait...</p>
          ) : (
            <p>{`${oldimages.length}/10 Images Uploaded`}</p>
          )}

          <button
            onClick={() => {
              setIsOpen(true);
            }}
          >
            <div className="save-btn">
              <img src={handblue} alt="" />
              <p>View Files</p>
            </div>
          </button>

          <div className="add-files">
            <p className="add-photo-text">
              {"Add photos as proof of task (maximum 10)"}
            </p>

            <FileInput imgArray={images} setImgArray={setImages} />
            <p>{"Add comment (optional)"}</p>
            <input
              type="text"
              placeholder="Type your comment here"
              onChange={(evt) => setComment(evt.target.value)}
            />
            <button onClick={() => submission()} className="submit-task-btn">
              Submit
            </button>
          </div>
        </div>
      )}
      {show && <Toast show={show} setShow={setShow} message={message} />}
      <Modal isOpen={isOpen} onClose={closeModal}>
        <button
          className="close-btn"
          onClick={() => {
            setIsOpen(false);
          }}
        >
          close
        </button>
        <br />
        <br />
        {oldimages ? (
          <>
            {oldimages.map((image) => {
              return (
                <img
                  src={image}
                  alt=""
                  srcset=""
                  className="submitted-images"
                />
              );
            })}
          </>
        ) : (
          <></>
        )}
      </Modal>
    </>
  );
};

export default SubmitTask;
