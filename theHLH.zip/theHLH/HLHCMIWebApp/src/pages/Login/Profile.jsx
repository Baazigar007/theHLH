import "./Profile.css";
import avatar from "../../images/avatar.svg";
import handblue from "../../images/hand-blue.svg";
import TopSheet from "../../components/TopSheet/TopSheet";
import { useNavigate } from "react-router-dom";
import { useEffect } from "react";
import loginStatus from "../../backend/loginStatus";
import realm_app from "../../backend/UserContext";
import { useState } from "react";
import updateUserData from "../../backend/updateUserData";
import Loading from "../../components/Loading/Loading";
import Toast from "../../components/Toast/Toast";
import school_names from "./schooldata";
import soro_names from "./sororitydata";

// PROFILE BODY
export default function ProfilePage() {
  const [show, setShow] = useState(false);
  const [message, setMessage] = useState("");
  const [showPass, setShowPass] = useState(false);
  const [userinfo, setUserInfo] = useState({});
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [phone, setPhone] = useState("");
  const [college, setCollege] = useState("");
  const [sorority, setSorority] = useState("");
  const [loading, setLoading] = useState(false);
  const [paypal, setPaypal] = useState("");
  const [tiktok, setTiktok] = useState("");
  const [instagram, setInstagram] = useState("");
  const [schools, setSchools] = useState([]);
  const [soro, setSoros] = useState([]);
  const [data, userdata] = useState([]);
  //navigation for logged in
  const navigate = useNavigate();

  useEffect(() => {
    setSchools(school_names);
  }, []);
  useEffect(() => {
    setSoros(soro_names);
  }, []);

  useEffect(() => {
    async function checkLogin() {
      var x = await loginStatus();
      //console.log("checking", x);
      if (x.isLogged === true) {
        if (x.isAdmin) {
          navigate("/admin");
        }
      } else {
        navigate("/");
      }
    }
    checkLogin();
  }, [navigate]);

  // async function getData() {
  //   const f = await realm_app.currentUser
  //     .mongoClient("mongodb-atlas")
  //     .db("userinfo")
  //     .collection("userdata")
  //     .findOne({ userId: realm_app.currentUser.id });
  //   userdata(f);
  // }

  useEffect(() => {
    if (realm_app.currentUser) {
      const info = realm_app.currentUser.customData;
      setUserInfo(info);
      setName(info.name);
      setEmail(info.email);
      setPassword(info.password);
      setPhone(info.phone);
      setCollege(info.college);
      setSorority(info.sorority);
      setPaypal(info?.paypal);
      setTiktok(info?.tiktok);
      setInstagram(info?.instagram);
    } else {
      console.log("ERROR-4");
      navigate("/");
    }
  }, [data]);

  function is_10_digit_string(string) {
    return string.length === 10 && string.match(/^\d{10}$/) !== null;
  }
  async function saveData() {
    let x = userinfo;
    if (!is_10_digit_string(phone)) {
      setShow(true);
      setMessage("Phone number is not valid");
      setLoading(false);
    } else {
      x.name = name;
      // x.email = email;
      // x.password = password;
      x.college = college;
      x.phone = phone;
      x.sorority = sorority;
      x.paypal = paypal;
      x.tiktok = tiktok;
      x.instagram = instagram;
      await setUserInfo(x);
      await setLoading(true);
      await updateUserData(userinfo);
      // console.log("UserInfo-> ", userinfo);
      setLoading(false);
    }
  }

  //return part for design and structure
  return (
    <>
      {loading ? (
        <Loading />
      ) : (
        <div className="profilebody">
          <TopSheet />
          <div className="sb-head">
            <h2>Your Profile</h2>
          </div>
          <div className="profilebottom">
            <div className="profilefields">
              <div className="p-image">
                <img className="image" src={avatar} alt="pfp" />
              </div>
              <div className="p-info">
                <h4 className="p-head">Name</h4>
                <input
                  type="text"
                  value={name}
                  onChange={(evt) => {
                    setName(evt.target.value);
                  }}
                ></input>
                <h4 className="p-head">Email Address</h4>
                <input
                  type="email"
                  value={email}
                  // onChange={(evt) => {
                  //   setEmail(evt.target.value);
                  // }}
                  contentEditable="false"
                ></input>
                <h4 className="p-head">Password</h4>
                <div className="eye-pass">
                  <input
                    type={showPass ? "text" : "password"}
                    value={password}
                    // onChange={(evt) => {
                    //   setPassword(evt.target.value);
                    // }}
                    contentEditable="false"
                  ></input>

                  {!showPass ? (
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      fill="none"
                      viewBox="0 0 24 24"
                      strokeWidth={1}
                      stroke="#000"
                      className="eye"
                      onClick={() => {
                        setShowPass(true);
                      }}
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        d="M2.036 12.322a1.012 1.012 0 010-.639C3.423 7.51 7.36 4.5 12 4.5c4.638 0 8.573 3.007 9.963 7.178.07.207.07.431 0 .639C20.577 16.49 16.64 19.5 12 19.5c-4.638 0-8.573-3.007-9.963-7.178z"
                      />
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"
                      />
                    </svg>
                  ) : (
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      fill="none"
                      viewBox="0 0 24 24"
                      strokeWidth={1}
                      stroke="#000"
                      className="eye-closed"
                      onClick={() => {
                        setShowPass(false);
                      }}
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        d="M3.98 8.223A10.477 10.477 0 001.934 12C3.226 16.338 7.244 19.5 12 19.5c.993 0 1.953-.138 2.863-.395M6.228 6.228A10.45 10.45 0 0112 4.5c4.756 0 8.773 3.162 10.065 7.498a10.523 10.523 0 01-4.293 5.774M6.228 6.228L3 3m3.228 3.228l3.65 3.65m7.894 7.894L21 21m-3.228-3.228l-3.65-3.65m0 0a3 3 0 10-4.243-4.243m4.242 4.242L9.88 9.88"
                      />
                    </svg>
                  )}
                </div>
                <h4 className="p-head">Phone</h4>
                <input
                  type="tel"
                  value={phone}
                  onChange={(evt) => {
                    setPhone(evt.target.value);
                  }}
                ></input>
                {/* <h4 className="p-head">College</h4>
                <input
                  type="text"
                  value={college}
                  onChange={(evt) => {
                    setCollege(evt.target.value);
                  }}
                ></input> */}
                <div className="">
                  <h4 className="p-head">College</h4>
                  <select
                    name="status"
                    id="status"
                    value={college}
                    className="type-drop-user"
                    onChange={(evt) => {
                      setCollege(evt.target.value);
                    }}
                  >
                    <option value="all">{college}</option>
                    {schools.map((element) => {
                      return <option value={element}>{element}</option>;
                    })}
                  </select>
                </div>
                <div className="">
                  <h4 className="p-head">Sorority</h4>
                  <select
                    name="status"
                    id="status"
                    value={sorority}
                    className="type-drop-user"
                    onChange={(evt) => {
                      setSorority(evt.target.value);
                    }}
                  >
                    <option value="all">{sorority}</option>
                    {soro.map((element) => {
                      return <option value={element}>{element}</option>;
                    })}
                  </select>
                </div>
                {/* <h4 className="p-head">Sorority</h4>
                <input
                  type="text"
                  value={sorority}
                  onChange={(evt) => {
                    setSorority(evt.target.value);
                  }}
                ></input> */}
                <h4 className="p-head">Paypal Email</h4>
                <input
                  type="email"
                  value={paypal}
                  onChange={(evt) => {
                    setPaypal(evt.target.value);
                  }}
                ></input>
                <h4 className="p-head">TikTok Profile</h4>
                <input
                  type="text"
                  value={tiktok}
                  onChange={(evt) => {
                    setTiktok(evt.target.value);
                  }}
                ></input>
                <h4 className="p-head">Instagram Profile</h4>
                <input
                  type="text"
                  value={instagram}
                  onChange={(evt) => {
                    setInstagram(evt.target.value);
                  }}
                ></input>
              </div>
              <button
                onClick={() => {
                  saveData();
                }}
              >
                <div className="savebtn">
                  <img src={handblue} alt="" />
                  <p>Save</p>
                </div>
              </button>
            </div>
          </div>
        </div>
      )}

      {show && <Toast show={show} setShow={setShow} message={message} />}
    </>
  );
}
