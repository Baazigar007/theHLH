import "./ExpiredTask.css";
import { useState, useEffect } from "react";
import TasksTile from "../../../components/TasksTileAdmin/TasksTile";
import fetchExpiredTasks from "../../../backend/fetchExpiredTasks";
import AdminSheet from "../../../components/AdminSheet/AdminSheet";

const ExpiredTasks = () => {
  const [data, setData] = useState([]);
  useEffect(() => {
    async function fetchExpired() {
      const tasks = await fetchExpiredTasks();
      setData(tasks);
    }
    fetchExpired();
  }, []);

  return (
    <div className="bulk-task-body">
      <AdminSheet />
      <div className="bulk-task-header">
        <p className="add-a-bulk-task">Expired Tasks</p>
      </div>

      <div className="tasks-list">
        {data.map((item, index) => {
          return (
            <div key={index}>
              <TasksTile data={item} tasks={true} />
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default ExpiredTasks;
