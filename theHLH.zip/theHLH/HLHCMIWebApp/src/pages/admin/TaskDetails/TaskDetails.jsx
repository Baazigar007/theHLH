import "./TaskDetails.css";
import avatar from "../../../images/avatar.svg";
import handblue from "../../../images/hand-blue.svg";
import Modal from "react-modal";
import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import loginStatus from "../../../backend/loginStatus";
import fetchSubmissionDetails from "../../../backend/fetchSubmissionDetails";
import fetchImages from "../../../backend/fetchImages";
import updateSubmission from "../../../backend/updateSubmission";
import Loading from "../../../components/Loading/Loading";
import AdminSheet from "../../../components/AdminSheet/AdminSheet";
import Toast from "../../../components/Toast/Toast";

const TaskDetails = () => {
  const [submissionId, setSubmissionId] = useState(null);
  const [submission, setSubmission] = useState({});
  const [images, setImages] = useState([]);
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [show, setShow] = useState(false);
  const [message, setMessage] = useState("");
  const [adminComment, setAdminComment] = useState("");
  const [payStatus, setPayStatus] = useState(null);
  const [completionStatus, setCompletionStatus] = useState(null);

  async function saveTask() {
    const data = submission;

    //console.log(completionStatus,data.status,payStatus );
    // if(payStatus ==="partiallAccepted" && ) {
    if (completionStatus === "partiallyAccepted" && payStatus === "accepted") {
      //PARTIAL + PAID
      data.reward = data.amount;
      data.status = "partiallyAccepted";
      //console.log("In PA+PAID");
    } else if (
      completionStatus === "partiallyAccepted" &&
      payStatus === "pending"
    ) {
      //PARTIAL + UNPAID
      //console.log("In PA+UNPAID");
      data.amount = submission.amount;
      //console.log(data.amount,submission.amount);
      data.status = "partiallyAccepted";
    } else if (payStatus === "accepted" && data.reward !== data.amount) {
      data.reward = data.amount;
      //console.log("Received1");
    } else if (payStatus === "pending" && data.reward === data.amount) {
      data.reward = 0;
      //console.log("Received2");
    }
    if (completionStatus === "pending" && completionStatus !== data.status) {
      data.status = "pending";
      //console.log("Received3");
    } else if (
      completionStatus === "accepted" &&
      completionStatus !== data.status
    ) {
      data.status = "accepted";
      //console.log("Received4");
    } else if (
      completionStatus === "rejected" &&
      completionStatus !== data.status
    ) {
      data.status = "rejected";
      //console.log("Received5");
    } else if (
      completionStatus === "partiallyAccepted" &&
      completionStatus !== data.status
    ) {
      data.status = "partiallyAccepted";
      //console.log("Received6 ",completionStatus,data.status);
    }

    data.adminComment = adminComment;
    setLoading(true);
    //console.log("Data-> ",data);
    const res = await updateSubmission(data);
    make_reload();
    // window.location.reload();
    // setShow(true);
    // setLoading(false);
  }

  async function make_reload() {
    await window.location.reload();
  }
  useEffect(() => {
    async function checkLogin() {
      var x = await loginStatus();
      //console.log("checking", x);
      if (!x.isAdmin) {
        navigate("/");
      }
    }

    async function callFunctions() {
      setLoading(true);
      await checkLogin();
      const searchParams = new URLSearchParams(window.location.search);
      const id = searchParams.get("submissionid");
      //console.log(id);
      setSubmissionId(id);
      const datax = await fetchSubmissionDetails(id);
      // console.log("Datax- ",datax);
      setSubmission(datax);
      const imgs = await fetchImages(id);
      setImages(imgs);
      // console.log("idhar ka data ", imgs);
      setLoading(false);
      setAdminComment(datax.adminComment);
      setPayStatus(
        datax.reward.toString() === datax.amount.toString()
          ? "accepted"
          : "pending"
      );
      if (datax.status === "accepted") {
        setCompletionStatus("accepted");
      } else if (datax.status === "partiallyAccepted") {
        setCompletionStatus("partiallyAccepted");
      }
    }

    callFunctions();
  }, [navigate, submissionId]);

  const [isOpen, setIsOpen] = useState(false);

  const closeModal = () => {
    setIsOpen(false);
  };
  return (
    <>
      {show && <Toast message={message} setShow={setShow} show={show} />}
      {loading ? (
        <Loading />
      ) : (
        <div className="task-details-body">
          <AdminSheet />
          <div className="task-details-header">
            <div>
              <img src={avatar} className="task-details-avatar" alt="" />
            </div>
            <div className="user-task-header-l">
              <strong>
                <p>{submission.userdata ? submission.userdata.name : ""}</p>
              </strong>
              <p>
                Email: {submission.userdata ? submission.userdata.email : ""}
                <br />
                Phone : {submission.userdata ? submission.userdata.phone : ""}
                <br />
                College :{" "}
                {submission.userdata ? submission.userdata.college : ""}
                <br />
                Sorority :{" "}
                {submission.userdata ? submission.userdata.sorority : ""}
              </p>
            </div>
          </div>

          {isOpen ? (
            <div></div>
          ) : (
            <div className="taskname-details">
              <p>{submission.title}</p>
            </div>
          )}

          <div className="task-info-parent">
            <div className="toggles">
              <div className="status-filter">
                <label for="status" className="label-details">
                  Status:
                </label>
                <br />
                <select
                  name="status"
                  className="taskdetails-select"
                  value={completionStatus}
                  id="status"
                  onChange={(evt) => {
                    if (evt.target.value === "rejected") {
                      setPayStatus("pending");
                    }
                    setCompletionStatus(evt.target.value);
                  }}
                >
                  <option value="pending">Pending</option>
                  <option value="accepted">Accepted</option>
                  <option value="rejected">Rejected</option>
                  <option value="partiallyAccepted">Partially Accepted</option>
                </select>
              </div>
              <div className="status-filter">
                <label for="paystatus" className="label-details">
                  Amount: $
                  {completionStatus === "partiallyAccepted" &&
                  payStatus !== "accepted" ? (
                    <>
                      <span>{submission.amount}</span>
                      <input
                        type="number"
                        onChange={(e) =>
                          setSubmission({
                            ...submission,
                            amount: e.target.value,
                          })
                        }
                      />
                    </>
                  ) : (
                    <span>{submission.amount}</span>
                  )}
                </label>
                <br />
                <select
                  name="paystatus"
                  className="taskdetails-select"
                  value={payStatus}
                  id="paystatus"
                  onChange={(evt) => {
                    setPayStatus(evt.target.value);
                  }}
                >
                  <option value="pending">Unpaid</option>
                  <option
                    value="accepted"
                    disabled={completionStatus === "rejected" && true}
                  >
                    Paid
                  </option>
                </select>
              </div>
            </div>

            <div className="added-files">
              <p className="label-details">Added files</p>
              <button
                onClick={() => {
                  setIsOpen(true);
                }}
              >
                <div className="save-btn">
                  <img src={handblue} alt="" />
                  <p>View Files</p>
                </div>
              </button>
            </div>

            <div className="Comments">
              <p className="comments">User's Comment</p>
              <center>
                <div className="comment">
                  <p>{submission.comment}</p>
                </div>
              </center>
            </div>
            <div className="Comments">
              <p className="comments">Add Review</p>
              <center>
                <div className="comment">
                  <input
                    type="text"
                    value={adminComment}
                    onChange={(e) => setAdminComment(e.target.value)}
                  />
                </div>
              </center>
            </div>

            <div className="save-btn-parent">
              <button
                onClick={() => {
                  saveTask();
                }}
              >
                <div className="save-btn">
                  <img src={handblue} alt="" />
                  <p>Save</p>
                </div>
              </button>
            </div>
          </div>
          <Modal isOpen={isOpen} onClose={closeModal}>
            <button
              className="close-btn"
              onClick={() => {
                setIsOpen(false);
              }}
            >
              close
            </button>
            <br />
            <br />
            {images.map((image) => {
              return (
                <img
                  src={image}
                  alt=""
                  srcset=""
                  className="submitted-images"
                />
              );
            })}
          </Modal>
        </div>
      )}
    </>
  );
};

export default TaskDetails;
