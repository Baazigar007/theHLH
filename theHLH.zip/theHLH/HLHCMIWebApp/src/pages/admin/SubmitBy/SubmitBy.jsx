import "./SubmitBy.css";
import { useEffect, useState } from "react";
import loginStatus from "../../../backend/loginStatus";
import { useNavigate } from "react-router-dom";
import Loading from "../../../components/Loading/Loading";
import logo from "../../../images/logo.svg";
import fetchUsersByIDs from "../../../backend/fetchUsersByIds";
import redirectPage from "../../../backend/redirectPageadmin";
import fetchSubmissionDetails from "../../../backend/fetchSubmissionDetails";

const SubmitBy = (props) => {
  const [loading, setLoading] = useState(false);
  const [userdata, setUserdata] = useState([]);
  const [statusMap, setStatusMap] = useState({});
  const [paymentStatusMap, setPaymentStatusMap] = useState({});
  const navigate = useNavigate();

  useEffect(() => {
    async function checkLogin() {
      var x = await loginStatus();
      if (!x.isAdmin) {
        navigate("/");
      }
    }
    checkLogin();
  }, [navigate]);

  const userIDsToFetch = props.data.completed_by;

  useEffect(() => {
    setLoading(true);
    async function getUserData() {
      const data = await fetchUsersByIDs(userIDsToFetch);

      setUserdata(data);
    }
    getUserData();
    setLoading(false);
  }, [userIDsToFetch]);

  function getStatusColor(status) {
    switch (status) {
      case "pending":
        return "yellow";
      case "accepted":
        return "lightgreen";
      case "rejected":
        return "red";
      default:
        return "white";
    }
  }

  function getPaymentStatusColor(status) {
    switch (status) {
      case "UNPAID":
        return "yellow";
      case "PAID":
        return "lightgreen";
      default:
        return "white";
    }
  }

  useEffect(() => {
    setLoading(true);

    async function getStatusForAllUsers() {
      const promises = userdata.map(async (user) => {
        const sub_id = await redirectPage(props.data._id, user.userId);

        const datax = await fetchSubmissionDetails(sub_id);

        if (datax && datax.status) {
          setStatusMap((prevStatusMap) => ({
            ...prevStatusMap,
            [user.userId]: datax.status,
          }));
          setPaymentStatusMap((prevPaymentStatusMap) => ({
            ...prevPaymentStatusMap,
            [user.userId]: datax.reward === 0 ? "UNPAID" : "PAID",
          }));
        } else {
          console.error("Datax or status property not found.");
        }
      });

      await Promise.all(promises);

      setLoading(false);
    }

    getStatusForAllUsers();
  }, [userdata, props.data._id]);

  return (
    <>
      {loading ? (
        <Loading />
      ) : (
        <div className="submit-body">
          <img
            className="logo-right"
            src={logo}
            onClick={() => navigate("/admin")}
            alt=""
          />
          <h1>Submitted By:</h1>
          <section className="submit-by-section">
            {userdata.length === 0 ? (
              <p>No Submissions!</p>
            ) : (
              userdata
                .filter((user) => statusMap.hasOwnProperty(user.userId))
                .map((user, index) => (
                  <div
                    className="submit-card"
                    key={index}
                    onClick={async () => {
                      await redirectPage(props.data._id, user.userId).then(
                        (val) => {
                          if (val) {
                            window.open(
                              "/admin/taskdetails?submissionid=" + val,
                              "_blank"
                            );
                          } else {
                            alert(
                              "There's some error fetching the task details"
                            );
                          }
                        }
                      );
                    }}
                  >
                    <p>
                      <b>Name :</b> {user.name}
                    </p>
                    <p>
                      <b>College :</b> {user.college}
                    </p>
                    <p>
                      <b>Sorority :</b> {user.sorority}
                    </p>
                    <button
                      style={{
                        backgroundColor: getStatusColor(statusMap[user.userId]),
                      }}
                    >
                      {statusMap[user.userId]
                        ? statusMap[user.userId].toUpperCase()
                        : ""}
                    </button>
                    <button
                      style={{
                        backgroundColor: getPaymentStatusColor(
                          paymentStatusMap[user.userId]
                        ),
                      }}
                    >
                      {paymentStatusMap[user.userId]}
                    </button>
                  </div>
                ))
            )}
          </section>
        </div>
      )}
    </>
  );
};

export default SubmitBy;
