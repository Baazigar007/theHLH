import { useEffect, useState } from "react";
import "./CreateUser.css";
import createUserFromData from "../../../backend/createUser";
import Loading from "../../../components/Loading/Loading";
import school_names from "../../Login/schooldata";
import soro_names from "../../Login/sororitydata";
import Toast from "../../../components/Toast/Toast";
import checkDuplicate from "../../../backend/duplicate";

const CreateUser = () => {
  const [name, setName] = useState(null);
  const [email, setEmail] = useState(null);
  const [pwd, setPwd] = useState(null);
  const [phone, setPhone] = useState(null);
  const [college, setCollege] = useState(null);
  const [sorority, setSorority] = useState(null);
  const [paypal, setPaypal] = useState(null);
  const [tiktok, setTiktok] = useState(null);
  const [instagram, setInstagram] = useState(null);
  const [loading, setLoading] = useState(false);
  const [schools, setSchools] = useState([]);
  const [soronames, setSoronames] = useState([]);
  const [show, setShow] = useState(false);
  const [message, setMessage] = useState("");

  useEffect(() => {
    setSchools(school_names);
  }, []);
  useEffect(() => {
    setSoronames(soro_names);
  }, []);
  async function createNewUser() {
    if (
      name === null ||
      email === null ||
      pwd === null ||
      phone === null ||
      college === null
    ) {
      setShow(true);
      setMessage("Please fill all the fields");
    } else {
      const userObject = {
        name: name,
        email: email,
        password: pwd,
        phone: phone,
        college: college,
        sorority: sorority,
        paypal: paypal,
        tiktok: tiktok,
        instagram: instagram,
        isAdmin: false,
        balance: 0,
        totalEarned: 0,
        taskSubmissions: [],
      };
      let var1 = 0;

      async function checkDup() {
        try {
          var1 = await checkDuplicate(userObject);
          console.log(var1);

          if (var1 === 1) {
            alert("User already exists! Please create a new one..");
          } else if (var1 === -1) {
            alert(
              "Please try again later or contact the admin if the problem persists.."
            );
          } else if (var1 === 0) {
            setLoading(true);
            await createUserFromData(userObject);
            setLoading(false);
          }
        } catch (error) {
          console.error("Error in checkDup:", error);
          // Handle error appropriately
        }
      }

      async function runCheckAndCreateUser() {
        try {
          await checkDup();
        } catch (error) {
          console.error("Error in runCheckAndCreateUser:", error);
          // Handle error appropriately
        }
      }

      // Usage
      runCheckAndCreateUser();
    }
  }
  return (
    <>
      {show && <Toast message={message} setShow={setShow} show={show} />}
      {loading ? (
        <Loading />
      ) : (
        <div className="createuser-body">
          {/* <AdminSheet /> */}
          <h1>Create a new User</h1>
          <section className="create-user-form">
            <input
              type="text"
              className="user-input"
              name="name"
              placeholder="name"
              id=""
              onChange={(evt) => setName(evt.target.value)}
            />
            <input
              type="text"
              className="user-input"
              name="email"
              placeholder="email"
              id=""
              onChange={(evt) => {
                const input = evt.target.value;
                const emailPattern = /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i;
                if (emailPattern.test(input)) {
                  setEmail(input);
                }
              }}
            />
            <input
              type="password"
              className="user-input"
              name="password"
              placeholder="password"
              id=""
              onChange={(evt) => setPwd(evt.target.value)}
            />
            <input
              type="tel"
              className="user-input"
              name="phone"
              placeholder="phone number"
              id=""
              onChange={(evt) => {
                const input = evt.target.value;

                const phonePattern = /^\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}$/;

                if (phonePattern.test(input)) {
                  setPhone(input);
                }
              }}
            />

            <div className="">
              <select
                name="status"
                id="status"
                className="type-drop"
                onChange={(evt) => {
                  setCollege(evt.target.value);
                }}
              >
                <option value="all">College</option>
                {schools.map((element) => {
                  return <option value={element}>{element}</option>;
                })}
              </select>
            </div>
            <div className="">
              <select
                name="status"
                id="status"
                className="type-drop"
                onChange={(evt) => {
                  setSorority(evt.target.value);
                }}
              >
                <option value="all">Sorority</option>
                {soronames.map((element) => {
                  return <option value={element}>{element}</option>;
                })}
              </select>
            </div>
            <input
              type="text"
              className="user-input"
              name="name"
              placeholder="PayPal Email"
              id=""
              onChange={(evt) => setPaypal(evt.target.value)}
            />
            <input
              type="text"
              className="user-input"
              name="name"
              placeholder="Tiktok"
              id=""
              onChange={(evt) => setTiktok(evt.target.value)}
            />
            <input
              type="text"
              className="user-input"
              name="name"
              placeholder="Instagram"
              id=""
              onChange={(evt) => setInstagram(evt.target.value)}
            />

            <button onClick={() => createNewUser()} className="submit-button">
              Submit
            </button>
          </section>
        </div>
      )}
    </>
  );
};

export default CreateUser;
