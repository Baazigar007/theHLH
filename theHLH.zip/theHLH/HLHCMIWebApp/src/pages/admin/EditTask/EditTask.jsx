import "./EditTask.css";
import { useEffect, useState } from "react";
import loginStatus from "../../../backend/loginStatus";
import { useNavigate } from "react-router-dom";
import Loading from "../../../components/Loading/Loading";
import updateBulkTaskData from "../../../backend/updateBulkTask";
import logo from "../../../images/logo.svg";
import Toast from "../../../components/Toast/Toast";
import createTaskFromData from "../../../backend/createTask";
import fetchAllUsers from "../../../backend/fetchAllUsers";
import deleteData from "../../../backend/deleteTasks";

const EditTask = (props) => {
  const navigate = useNavigate();
  const [show, setShow] = useState(false);
  const [message, setMessage] = useState("");

  useEffect(() => {
    async function checkLogin() {
      var x = await loginStatus();
      //console.log("checking", x);
      if (!x.isAdmin) {
        navigate("/");
      }
    }
    checkLogin();
  }, [navigate]);

  const [title, setTitle] = useState(props.data.title);
  const [desc, setDesc] = useState(props.data.description);
  const [amt, setAmt] = useState(props.data.amount);
  const [deadline, setDeadline] = useState(props.data.deadline);
  const [loading, setLoading] = useState(false);
  const [isSingle, setisSingle] = useState(false);
  const [users, setUsers] = useState([]);
  const [assigned, setAssigned] = useState(null);
  const [type, setType] = useState(null);

  // Edit tasks
  async function createNewTask() {
    if (title == null || desc == null || amt == null || deadline == null) {
      setShow(true);
      setMessage("Please fill all the fields");
    } else {
      const taskObject = {
        taskid: props.data._id,
        title: title,
        description: desc,
        amount: amt,
        deadline: deadline,
      };

      setLoading(true);
      await updateBulkTaskData(taskObject);
      setLoading(false);
      setShow(true);
      setMessage("Refresh to show updates");
    }
  }

  async function duplicateTask() {
    if (
      title === null ||
      desc === null ||
      amt === null ||
      deadline === null ||
      type === null
    ) {
      setShow(true);
      setMessage("Fill in all the necessary fields.");
    }

    if (type === "Bulk Task") {
      const taskObject = {
        title: title,
        description: desc,
        amount: amt,
        deadline: deadline,
        type: type,
      };
      setLoading(true);
      await createTaskFromData(taskObject);
      setShow(true);
      setMessage("Task created successfully!");
      setLoading(false);
    } else if (type === "Single Task") {
      if (assigned === "none" || assigned == null) {
        setShow(true);
        setMessage("Please assign the task to someone");
      } else {
        const taskObject = {
          title: title,
          description: desc,
          amount: amt,
          deadline: deadline,
          type: type,
          assigned_to: assigned,
        };
        setLoading(true);
        await createTaskFromData(taskObject);
        setShow(true);
        setMessage("Task created successfully!");
        setLoading(false);
      }
    }
  }

  async function toggleType(val) {
    setType(val);
    if (
      val === "Bulk Task" ||
      val === "Social Media" ||
      val === "Inperson" ||
      val === "Seminar" ||
      val === "PopUpShop" ||
      val === "Bonus"
    ) {
      setisSingle(false);
    } else {
      setisSingle(true);
    }
  }

  useEffect(() => {
    async function getUsers() {
      const users = await fetchAllUsers();
      setUsers(users);
    }
    getUsers();
  }, []);

  return (
    <>
      {show && <Toast message={message} setShow={setShow} show={show} />}
      {loading ? (
        <Loading />
      ) : (
        <div className="edit-body">
          <img
            className="logo-right"
            src={logo}
            onClick={() => props.setOpen()}
            alt=""
          />
          <h1>Edit Task</h1>
          <section>
            <input
              type="text"
              className="user-edit-input"
              name="title"
              placeholder="Task Title"
              id=""
              value={title}
              onChange={(evt) => setTitle(evt.target.value)}
            />
            <input
              type="text"
              className="user-edit-input-desc"
              name="desc"
              placeholder="Task Description"
              id=""
              value={desc}
              onChange={(evt) => setDesc(evt.target.value)}
            />
            <input
              type="text"
              className="user-edit-input"
              name="amt"
              placeholder="Amount"
              id=""
              value={amt}
              onChange={(evt) => setAmt(evt.target.value)}
            />
            <input
              type="date"
              className="user-edit-input"
              name="deadline"
              placeholder="Deadline"
              id=""
              value={deadline}
              onChange={(evt) => setDeadline(evt.target.value)}
            />

            {/* d */}
            <select
              className="type-drop"
              name="type"
              id=""
              onChange={(evt) => toggleType(evt.target.value)}
            >
              <option value="None">None</option>
              <option value="Bulk Task">Bulk Task</option>
              <option value="Single Task">Single Task</option>
              <option value="Social Media">Social Media</option>
              <option value="Inperson">In-person</option>
              <option value="Seminar">Seminar</option>
              <option value="PopUpShop">PopUpShop</option>
              <option value="Bonus">Bonus</option>
            </select>
            {isSingle ? (
              <select
                className="type-drop"
                name="type"
                id=""
                onChange={(evt) => setAssigned(evt.target.value)}
              >
                <option value="none">Assign to</option>
                {users.map((user) => {
                  if (!user.isAdmin) {
                    return <option value={user.userId}>{user.name}</option>;
                  }
                  return <p></p>;
                })}
              </select>
            ) : (
              <div></div>
            )}
            {/* end */}
            <button onClick={() => createNewTask()} className="submit-button">
              Save Changes
            </button>
            <button onClick={() => duplicateTask()} className="submit-button">
              Duplicate Task
            </button>
            <button
              onClick={() => deleteData(props.data)}
              className="submit-button"
            >
              Delete task
            </button>
          </section>
        </div>
      )}
    </>
  );
};

export default EditTask;
