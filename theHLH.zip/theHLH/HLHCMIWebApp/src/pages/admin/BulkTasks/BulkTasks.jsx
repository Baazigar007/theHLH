import React from "react";
import add from "../../../images/add_icon.svg";
import "./BulkTasks.css";
import TasksTile from "../../../components/TasksTileAdmin/TasksTile";
import { useNavigate } from "react-router-dom";
import { useEffect, useState } from "react";
import loginStatus from "../../../backend/loginStatus";
import fetchAllTasks from "../../../backend/fetchAllTasks";
import Loading from "../../../components/Loading/Loading";
import AdminSheet from "../../../components/AdminSheet/AdminSheet";
import realm_app from "../../../backend/UserContext";
import DelteAllInvalids from "../../../backend/tempScript";

const BulkTasks = () => {
  const [tasks, setTasks] = useState([]);
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();
  const dragItem = React.useRef(null);
  const dragOverItem = React.useRef(null);
  const [temp, settemp] = useState(false);
  const handleSort = () => {
    settemp(true);
    let _tasks = [...tasks];
    //remove and save dragged item
    const draggedItemContent = _tasks.splice(dragItem.current, 1)[0];
    //switch
    _tasks.splice(dragOverItem.current, 0, draggedItemContent);
    //reset the position
    dragItem.current = null;
    dragOverItem.current = null;
    //update
    setTasks(_tasks);
  };

  const saveOrder = async () => {
    if (realm_app.currentUser) {
      const temp = tasks.map((item) => item._id);
      const delall = await realm_app.currentUser
        .mongoClient("mongodb-atlas")
        .db("Priority")
        .collection("OrderList")
        .deleteMany();

      const updateArray = await realm_app.currentUser
        .mongoClient("mongodb-atlas")
        .db("Priority")
        .collection("OrderList")
        .insertOne({ newArray: temp })
        .then((e) => console.log("Updated"))
        .catch((e) => console.log(e));
      settemp(false);
    } else {
      console.log("ERROR 1");
      navigate("/");
    }
  };

  useEffect(() => {
    async function checkLogin() {
      var x = await loginStatus();
      //console.log("checking", x);
      if (!x.isAdmin) {
        navigate("/");
      }
    }
    checkLogin();
  }, [navigate]);

  useEffect(() => {
    setLoading(true);
    async function getData() {
      if (realm_app.currentUser) {
        const data = await fetchAllTasks();
        const orderOfIds = await realm_app.currentUser
          .mongoClient("mongodb-atlas")
          .db("Priority")
          .collection("OrderList")
          .find();
        // Your array containing the desired order of string IDs
        const newOrder = orderOfIds[0].newArray;
        // console.log("1 ", newOrder);
        // Sorting the array of objects based on the order of IDs
        // let x = [];
        // for (let i = 0; i < orderOfIds.length; i++) {
        //   const id = newOrder[i];
        //   const foundObject = data.find((obj) => obj._id === id);
        //   console.log(foundObject);
        //   x.push(foundObject);
        // }
        let x = newOrder.map((id) => data.find((obj) => obj._id === id));
        x = x.filter((value) => value !== undefined);

        // console.log("Len ", x);
        //TO UPDATE PRIORITY LIST IF SOMETHING HAPPENS
        // setTasks(data);
        setTasks(x);
        // console.log("new-> ", x);
      } else {
        // If currentUser is null or undefined, redirect to the base URL
        console.error("currentUser is null or undefined,ERROR 2");
        //window.location.href = '/';
        return [];
      }
    }
    getData();
    setLoading(false);
  }, []);

  return (
    <>
      {loading ? (
        <Loading />
      ) : (
        <div className="bulk-task-body">
          <AdminSheet />
          <div className="bulk-task-header">
            <p className="add-a-bulk-task">Checkout All Tasks</p>
            {/* <button onClick={DelteAllInvalids}>DELETE INVALID</button> */}
          </div>
          {temp ? (
            <button className="bulk-task-header1" onClick={saveOrder}>
              CLICK TO SAVE ORDER
            </button>
          ) : (
            <></>
          )}

          <div className="tasks-list">
            {tasks.map((item, index) => {
              return (
                <div
                  draggable
                  key={index}
                  onDragStart={(e) => (dragItem.current = index)}
                  onDragEnter={(e) => (dragOverItem.current = index)}
                  onDragEnd={handleSort}
                >
                  <TasksTile data={item} tasks={true} />
                </div>
              );
            })}
          </div>

          <div>
            <button
              className="add-bulk-task-btn"
              onClick={() => {
                navigate("/admin/createtask");
              }}
            >
              <img src={add} className="add-bulk-task-btn-img" alt="" />
              <h4>Add Task</h4>{" "}
            </button>
          </div>
        </div>
      )}
    </>
  );
};

export default BulkTasks;
