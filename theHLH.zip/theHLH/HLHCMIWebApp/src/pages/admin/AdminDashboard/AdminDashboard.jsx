import "./AdminDashboard.css";
import SubmissionCard from "../../../components/SubmissionCard/SubmissionCard";
import { useNavigate } from "react-router-dom";
import { useEffect, useState } from "react";
import loginStatus from "../../../backend/loginStatus";
import Loading from "../../../components/Loading/Loading";
import convertArrayOfObjectsToCSV from "../../../backend/convertToCSV";
import fetchAllUsers from "../../../backend/fetchAllUsers";
import AdminSheet from "../../../components/AdminSheet/AdminSheet";
import school_names from "../../Login/schooldata";

const AdminDashboard = () => {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [schools, setSchools] = useState(school_names);
  const [submissions_list, setSubmissions_list] = useState([]);
  const [submissions_list_copy, setSubmissions_list_copy] = useState([]);
  const [currentSchool, setCurrentSchool] = useState("all");
  const [sortOrder, setSortOrder] = useState("ascending");
  const [currentSort, setCurrentSort] = useState("Default");

  const toggleSortOrder = () => {
    setSortOrder((prevOrder) =>
      prevOrder === "ascending" ? "descending" : "ascending"
    );
  };

  const toggleSort = (sortType) => {
    setCurrentSort((prevSort) =>
      prevSort === sortType ? "Default" : sortType
    );
  };

  const filterSubmissions = () => {
    return submissions_list.filter(
      (item) =>
        !item.isAdmin &&
        (item.college === currentSchool || currentSchool === "all")
    );
  };

  const sortSubmissionsByName = (data) => {
    return data.sort((a, b) => {
      return sortOrder === "ascending"
        ? a.name.localeCompare(b.name)
        : b.name.localeCompare(a.name);
    });
  };

  const sortSubmissionsByCount = (data) => {
    return data.sort((a, b) => {
      const submissionsA = a.taskSubmissions.length;
      const submissionsB = b.taskSubmissions.length;

      return sortOrder === "ascending"
        ? submissionsA - submissionsB
        : submissionsB - submissionsA;
    });
  };

  const sortSubmissionsByBalance = (data) => {
    return data.sort((a, b) => {
      const balanceA = a.balance;
      const balanceB = b.balance;

      return sortOrder === "ascending"
        ? balanceA - balanceB
        : balanceB - balanceA;
    });
  };

  const sortSubmissionsByEarned = (data) => {
    return data.sort((a, b) => {
      const balanceA = a.totalEarned;
      const balanceB = b.totalEarned;
      // console.log(balanceA, balanceB);
      return sortOrder === "ascending"
        ? balanceA - balanceB
        : balanceB - balanceA;
    });
  };

  const renderSubmissionCards = () => {
    const filteredSubmissions = filterSubmissions();
    let sortedSubmissions;

    switch (currentSort) {
      case "ByCount":
        sortedSubmissions = sortSubmissionsByCount(filteredSubmissions);
        break;
      case "ByBalance":
        sortedSubmissions = sortSubmissionsByBalance(filteredSubmissions);
        break;
      case "ByEarned":
        sortedSubmissions = sortSubmissionsByEarned(filteredSubmissions);
        break;
      default:
        sortedSubmissions = sortSubmissionsByName(filteredSubmissions);
    }

    return sortedSubmissions.map((item) => (
      <SubmissionCard data={item} key={item._id} />
    ));
  };

  async function setSchoolFilter(val) {
    setCurrentSchool(val);
    if (val === "all") {
      setSubmissions_list(submissions_list_copy);
    } else {
      const filteredArray = submissions_list.filter(
        (object) => object.college === val
      );
      await setSubmissions_list(filteredArray);
    }
  }

  async function exportToCSV() {
    convertArrayOfObjectsToCSV();
  }

  useEffect(() => {
    setLoading(true);
    async function checkLogin() {
      var x = await loginStatus();
      if (!x.isAdmin) {
        navigate("/");
      }
    }

    async function getData() {
      const data = await fetchAllUsers();
      setSubmissions_list(data);
      setSubmissions_list_copy(data);
    }

    checkLogin();
    getData();
    setLoading(false);
  }, []);

  useEffect(() => {
    // Set the default sorting order when the component mounts
    setSortOrder("ascending");
  }, []);
  return (
    <>
      {loading ? (
        <Loading />
      ) : (
        <div className="admin-dash-parent">
          <AdminSheet />
          <div className="topblue">
            {/* <img className="logo-right" src={logo} alt="" /> */}

            <p className="setfilter">Set Filters:</p>

            <div className="filters">
              <div className="status-filter">
                <label for="status">School:</label>
                <br />
                <select
                  name="status"
                  id="status"
                  onChange={(evt) => {
                    setSchoolFilter(evt.target.value);
                  }}
                >
                  <option value="all">All</option>
                  {schools.map((element) => {
                    return <option value={element}>{element}</option>;
                  })}
                </select>
              </div>
              <div className="status-filter">
                <button
                  className="export-csv-button"
                  onClick={() => {
                    exportToCSV();
                  }}
                >
                  Export To CSV
                </button>
              </div>
            </div>
          </div>

          <div className="submission-parent-admin">
            <div className="submissions-admin">
              <p>Users</p>
            </div>
          </div>
          <div className="submissions-list">
            <div className="sort-buttons" style={{ textAlign: "center" }}>
              <button
                onClick={() => toggleSort("Default")}
                style={{
                  backgroundColor:
                    currentSort === "Default" ? "lightgreen" : "lightblue",
                }}
              >
                Default Sorting
              </button>
              <button
                onClick={() => toggleSort("ByCount")}
                style={{
                  backgroundColor:
                    currentSort === "ByCount" ? "lightgreen" : "lightblue",
                }}
              >
                Sort by Count
              </button>
              <button
                onClick={() => toggleSort("ByBalance")}
                style={{
                  backgroundColor:
                    currentSort === "ByBalance" ? "lightgreen" : "lightblue",
                }}
              >
                Sort by Balance
              </button>
              <button
                onClick={() => toggleSort("ByEarned")}
                style={{
                  backgroundColor:
                    currentSort === "ByEarned" ? "lightgreen" : "lightblue",
                }}
              >
                Sort by Earned
              </button>
              <button onClick={toggleSortOrder}>
                Toggle Order:
                {sortOrder === "ascending" ? "Descending" : "Ascending"}
              </button>
            </div>
            {submissions_list.length === 0 ? (
              <p>No submissions!</p>
            ) : (
              renderSubmissionCards()
            )}
          </div>
        </div>
      )}
    </>
  );
};

export default AdminDashboard;
