import { useEffect, useState } from "react";
import "./EditUser.css";
import createUserFromData from "../../../backend/createUser";
import Loading from "../../../components/Loading/Loading";
import AdminSheet from "../../../components/AdminSheet/AdminSheet";
import school_names from "../../Login/schooldata";
import updateUserData from "../../../backend/updateUserData";
import Toast from "../../../components/Toast/Toast";
import soro_names from "../../Login/sororitydata";
const EditUser = (props) => {
  const [show, setShow] = useState(false);
  const [message, setMessage] = useState("");

  const [email, setEmail] = useState(props.data.email);
  const [phone, setPhone] = useState(props.data.phone);
  const [college, setCollege] = useState(props.data.college);
  const [sorority, setSorority] = useState(props.data.sorority);
  const [loading, setLoading] = useState(false);
  const [schools, setSchools] = useState([]);
  // const [paypal, setPaypal] = useState(props.data.paypal);
  const [tiktok, setTiktok] = useState(props.data.tiktok);
  const [insta, setinsta] = useState(props.data.instagram);
  const [venmo,setvenmo] = useState(props.data.venmo);
  const [soro, setSoros] = useState([]);
  // console.log(props.data);
  // console.log(insta,+" "+paypal+" "+tiktok);
  function is_10_digit_string(string) {
    return string.length === 10 && string.match(/^\d{10}$/) !== null;
  }

  useEffect(() => {
    setSchools(school_names);
  }, []);
  useEffect(() =>{
    setSoros(soro_names);
  }, []);
  async function EditUserDetails() {
    if (
      email === null ||
      phone === null ||
      college === null ||
      !is_10_digit_string(phone)
    ) {
      setShow(true);
      setMessage("Please fill all the fields");
    } else {
      const userObject = {
        email: email,
        phone: phone,
        college: college,
        sorority: sorority,
        instagram:insta,
        tiktok:tiktok,
        userId: props.data.userId,
      };
      async function Edit() {
        await updateUserData(userObject);
      }
      setLoading(true);
      await Edit();
      setLoading(false);
    }
  }
  return (
    <>
      {loading ? (
        <Loading />
      ) : (
        <div className="edituser-body">
          <h1>Edit User Details</h1>
          <section>
            <input
              type="text"
              className="user-input"
              name="email"
              placeholder="email"
              id=""
              value={email}
              
            />
            <input
              type="tel"
              value={phone}
              className="user-input"
              name="phone"
              placeholder="phone number"
              id=""
              onChange={(evt) => {
                setPhone(evt.target.value);

                // If it's not a valid phone number, you can choose to ignore it or display an error message.
              }}
            />

            <div className="">
              <select
                name="status"
                id="status"
                value={college}
                className="type-drop"
                onChange={(evt) => {
                  setCollege(evt.target.value);
                }}
              >
                <option value="all">{college}</option>
                {schools.map((element) => {
                  return <option value={element}>{element}</option>;
                })}
              </select>
            </div>
            {/* <input
            type="text"
            className="user-input"
            name="college"
            placeholder="college"
            id=""
            onChange={(evt) => setCollege(evt.target.value)}
          /> */}
           <div className="">
         
              <select
                name="status"
                id="status"
                value={sorority}
                className="type-drop"
                onChange={(evt) => {
                  setSorority(evt.target.value);
                }}
              >
                <option value="all">{sorority}</option>
                {soro.map((element) => {
                  return <option value={element}>{element}</option>;
                })}
              </select>
            </div>
            <input
              type="text"
              className="user-input"
              name="instagram"
              value={insta}
              placeholder="instagram"
              id=""
              onChange={(evt) => setinsta(evt.target.value)}
            />

            <input
              type="text"
              className="user-input"
              name="tiktok"
              value={tiktok}
              placeholder="tiktok"
              id=""
              onChange={(evt) => setTiktok(evt.target.value)}
            />

            <input
              type="text"
              className="user-input"
              name="paypal"
              value={venmo}
              placeholder="paypal"
              id=""
              onChange={(evt) => setvenmo(evt.target.value)}
            />

            <button onClick={() => EditUserDetails()} className="submit-button">
              Submit
            </button>
          </section>
        </div>
      )}
      {show && <Toast show={show} setShow={setShow} message={message} />}
    </>
  );
};

export default EditUser;
