import SubmitBy from "../SubmitBy/SubmitBy";
import { useLocation } from 'react-router-dom';

const TaskSubmission = () => {
  const location = useLocation();
  const yourPropValue = location.state?.data;
  // console.log(yourPropValue);
  return (
    <div
      style={{ content: { backgroundColor: "#E48EC3" } }}
      contentLabel="Submitted By:"
    >
      <SubmitBy data={yourPropValue} />
    </div>

  )

}

export default TaskSubmission;