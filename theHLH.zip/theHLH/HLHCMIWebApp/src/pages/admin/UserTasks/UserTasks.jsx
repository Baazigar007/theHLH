// import TasksTile from "../../../components/TasksTileAdmin/TasksTile";
// import logo from "../../../images/logo.svg";
// import edit from "../../../images/pencil.svg";
// import "./UserTasks.css";
// import { useNavigate } from "react-router-dom";
// import { useEffect, useState } from "react";
// import loginStatus from "../../../backend/loginStatus";
// import fetchSubmissionsByUsers from "../../../backend/fetchSubmissionsByUsers";
// import fetchUserData from "../../../backend/fetchUserData";
// import Loading from "../../../components/Loading/Loading";
// import AdminSheet from "../../../components/AdminSheet/AdminSheet";
// import Modal from 'react-modal';
// import EditUser from "../EditUser/EditUser";

// const UserTasks = () => {
//   // const tasks = [1,2,2,2,2,2,34,4]
//   const [modalIsOpen, setIsOpen] = useState(false);

//   function closeModal() {
//     setIsOpen(false);
//   }

//   const [loading, setLoading] = useState(false);
//   const [submissions, setSubmissions] = useState([]);
//   const [userData, setUserData] = useState({
//     name: "",
//     email: "",
//     phone: "",
//     college: "",
//     sorority: "",
//   });
//   const [userid, setUserid] = useState(null);
//   const navigate = useNavigate();
//   useEffect(() => {
//     async function checkLogin() {
//       var x = await loginStatus();
//       //console.log("checking", x);
//       if (!x.isAdmin) {
//         navigate("/");
//       }
//     }

//     async function getUserId() {
//       const searchParams = new URLSearchParams(window.location.search);
//       const id = await searchParams.get("userid");
//       //console.log("userid is ", id);
//       setUserid(id);
//     }

//     async function getData() {
//       const data = await fetchSubmissionsByUsers(userid);
//       setSubmissions(data);
//     }
//     async function getUserData() {
//       const datax = await fetchUserData(userid);
//       //console.log("user id is ", userid);
//       //console.log("data aaya hai ", datax);
//       setUserData(datax);
//     }

//     async function callfunctions() {
//       setLoading(true);
//       await getUserId();
//       await checkLogin();
//       await getUserData();
//       await getData();
//       setLoading(false);
//     }

//     callfunctions();
//   }, [navigate, userid]);
//   return (
//     <>
//       {loading ? (
//         <Loading />
//       ) : (
//         <div className="bulk-task-body">
//           <AdminSheet/>
//           {/* <img className="logo-right" src={logo} alt="" /> */}
//           <div className="user-task-header">
//             <div className="user-task-header-l">
//               <strong>
//                 <p>{userData.name}</p>
//               </strong>
//               <p>
//                 Email: {userData.email}
//                 <br />
//                 Phone : {userData.phone}
//                 <br />
//                 College : {userData.college}
//                 <br />
//                 Sorority : {userData.sorority}
//               </p>
//             </div>
//             <div className="user-task-header-r">
//     <img src={edit} alt="" onClick={()=>{setIsOpen(true)}} />
//   </div>
//           </div>

//           <div className="tasks-list">
//             {submissions.length > 0 ? (
//               submissions.map((element) => {
//                 return (
//                   <div
//                     onClick={() => {
//                       navigate(
//                         "/admin/taskdetails?submissionid=" + element._id
//                       );
//                     }}
//                   >
//                     <TasksTile data={element} key={element._id} />
//                   </div>
//                 );
//               })
//             ) : (
//               <p>No Submissions!</p>
//             )}
//           </div>

//           {/* <div>
//             <button className="add-bulk-task-btn"><img src={add} className="add-bulk-task-btn-img" alt="" /></button>
//         </div> */}
//         </div>
//       )}
//       <Modal
//         style={{"content": {"backgroundColor": "#E48EC3", }}}
//         isOpen={modalIsOpen}
//         onRequestClose={closeModal}
//         contentLabel="Edit Task Modal"
//       >
//         <EditUser data={userData}/>
//        {/* <EditTask data={props.data}/> */}
//       </Modal>
//     </>
//   );
// };

// export default UserTasks;



//CONSISTENT VERSION-TRIAL 
import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import AdminSheet from "../../../components/AdminSheet/AdminSheet";
import Loading from "../../../components/Loading/Loading";
import TasksTile from "../../../components/TasksTileAdmin/TasksTile";
import Modal from 'react-modal';
import EditUser from "../EditUser/EditUser";
import logo from "../../../images/logo.svg";
import edit from "../../../images/pencil.svg";
import "./UserTasks.css";
import loginStatus from "../../../backend/loginStatus";
import fetchSubmissionsByUsers from "../../../backend/fetchSubmissionsByUsers";
import fetchUserData from "../../../backend/fetchUserData";
import avatar from "../../../images/avatar.svg";

const UserTasks = () => {
  function closeModal() {
         setIsOpen(false);
       }
  const [modalIsOpen, setIsOpen] = useState(false);
  const [loading, setLoading] = useState(true);
  const [submissions, setSubmissions] = useState([]);
  const [userData, setUserData] = useState({
    name: "",
    email: "",
    phone: "",
    college: "",
    sorority: "",
  });
  const [userid, setUserid] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    async function fetchData() {
      try {
        const searchParams = new URLSearchParams(window.location.search);
        const id = searchParams.get("userid");
        //console.log("userid is ", id);
        setUserid(id);

        const isLoggedIn = await loginStatus();
        //console.log("checking login status", isLoggedIn);

        if (!isLoggedIn.isAdmin) {
          navigate("/");
          return;
        }

        const userData = await fetchUserData(id);
        //console.log("user id is ", id);
        //console.log("user data", userData);
        setUserData(userData);

        const submissionData = await fetchSubmissionsByUsers(id);
        //console.log("submission data", submissionData);
        setSubmissions(submissionData);
      } catch (error) {
        console.error("Error fetching data: ", error);
      } finally {
        setLoading(false);
      }
    }

    fetchData();
  }, [navigate]);

  return (
    <>
      {loading ? (
        <Loading />
      ) : (
        <div className="bulk-task-body">
          <AdminSheet />
          <div className="user-task-header">
            {/* <div className="user-task-header-l">
              <strong>
                <p>{userData.name}</p>
              </strong>
              <p>
                Email: {userData.email}
                <br />
                Phone: {userData.phone}
                <br />
                College: {userData.college}
                <br />
                Sorority: {userData.sorority}
              </p>
            </div> */}
             <div className="task-details-header">
          <div>
            <img src={avatar} className="task-details-avatar" alt="" />
          </div>
          <div className="user-task-header-l">
            <strong>
              <p>{userData.name}</p>
            </strong>
            <p>
              Email: {userData.email}
              <br />
              Phone : {userData.phone}
              <br />
              College : {userData.college}
              <br />
              Sorority : {userData.sorority}
            </p>
          </div>
        </div>
            <div className="user-task-header-r">
              <img src={edit} alt="" onClick={() => { setIsOpen(true) }} />
            </div>
          </div>

          <div className="tasks-list">
            {submissions.length > 0 ? (
              submissions.map((element) => {
                return (
                  <div
                    onClick={() => {
                      navigate(
                        "/admin/taskdetails?submissionid=" + element._id
                      );
                    }}
                  >
                    <TasksTile data={element} key={element._id} />
                  </div>
                );
              })
            ) : (
              <p>No Submissions!</p>
            )}
          </div>
        </div>
      )}
      <Modal
        style={{"content": {"backgroundColor": "#E48EC3"}}}
        isOpen={modalIsOpen}
        onRequestClose={closeModal}
        contentLabel="Edit Task Modal"
      >
        <EditUser data={userData}/>
      </Modal>
    </>
  );
};

export default UserTasks;
