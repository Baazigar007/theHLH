import "../notfound.css";
import logo from "../images/logo.svg";

export default function LoginPage() {
  return (
    <div className="notfoundbody">
      <div class="container">
        <img src={logo} alt="Your Logo" />
        <h1>404 - Page Not Found</h1>
        <p>Oops! It seems our fashion path got a little tangled.</p>
        <p>
          Explore your tasks here <a href="/">home</a>.
        </p>
      </div>
    </div>
  );
}
