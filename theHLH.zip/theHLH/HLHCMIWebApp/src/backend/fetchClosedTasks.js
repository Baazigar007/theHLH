import realm_app from "./UserContext";
function compareDatesOnly(date1, date2) {

  const timelist = date1.split("-");
  // Extract the date components from each Date object
  const year1 = parseInt(timelist[0]);
  const month1 = parseInt(timelist[1]);
  const day1 = parseInt(timelist[2]);

  const timelist2 = date2.split(",")[0].split("/");
  const year2 = parseInt(timelist2[2]);
  const month2 = parseInt(timelist2[0]);
  const day2 = parseInt(timelist2[1]);
  // Compare the date components
  if (year1 < year2 || (year1 === year2 && (month1 < month2 || (month1 === month2 && day1 < day2)))) {
    return -1;
  } else if (year1 > year2 || (year1 === year2 && (month1 > month2 || (month1 === month2 && day1 > day2)))) {
    return 1;
  } else {
    return 0; // Dates are equal
  }
}

async function fetchClosedTasks() {
  const userId = await realm_app.currentUser.id;
  const currentDate = new Date();

  const tasksCollection = realm_app.currentUser
    .mongoClient("mongodb-atlas")
    .db("taskinfo")
    .collection("taskdata");

  const subtasksCollection = await realm_app.currentUser
    .mongoClient("mongodb-atlas")
    .db("subinfo")
    .collection("subdata").find({
      user_id: userId
    })



  // Get the current date in PST (Pacific Standard Time)
  const options = { timeZone: 'America/Los_Angeles' }; // 'America/Los_Angeles' is the timezone identifier for PST
  const pstDateString = currentDate.toLocaleString('en-US', options);

  const filtered_data = [];
  const data = await tasksCollection.find();

  const intersection_array = new Set();
  for (let i = 0; i < subtasksCollection.length; i++) {
    if ((subtasksCollection[i].status === "accepted" &&
      (subtasksCollection[i].amount === subtasksCollection[i].reward))
      || (subtasksCollection[i].status === "partiallyAccepted" &&
        (subtasksCollection[i].reward !== 0 || subtasksCollection[i].deadline !== data.find(x => x._id === subtasksCollection[i].task_id).deadline))
      || (subtasksCollection[i].status === "accepted" &&
        (subtasksCollection[i].deadline !== data.find(x => x._id === subtasksCollection[i].task_id).deadline))
    ) {
      intersection_array.add(subtasksCollection[i].task_id);
    }

  }

  for (let i = 0; i < data.length; i++) {
    const taskDeadline = data[i].deadline;
    // taskDeadline.setHours(taskDeadline.getHours() + 20);
    if (data[i].assigned_to === userId) { //SINGLE
      if ((compareDatesOnly(taskDeadline, pstDateString) === -1) || intersection_array.has(data[i]._id)) {
        filtered_data.push(data[i]);
      }
    }
    else if (data[i].type === "Bulk Task" &&
      ((compareDatesOnly(taskDeadline, pstDateString) === -1) || intersection_array.has(data[i]._id))) {
      filtered_data.push(data[i]);
    }

  }

  return filtered_data;
}
export default fetchClosedTasks;