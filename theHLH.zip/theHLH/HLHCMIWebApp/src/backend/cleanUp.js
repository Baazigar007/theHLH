import realm_app from "./UserContext";

async function cleanup(taskId) {
    console.log("Cleanup function triggered");
    try {
        // Connect to MongoDB
        const client = await realm_app.currentUser
            .mongoClient("mongodb-atlas")
        // Delete documents in the 'images' collection
        const imgdoc = await client.db('uploads').collection('images').findOne({ _id: taskId });
        if (imgdoc && imgdoc.images.length > 0) {
            return;
        } else {
            // Delete documents in the collection
            await client.db('uploads').collection('images').deleteOne({ _id: taskId });
            await client.db('subinfo').collection('subdata').deleteOne({ _id: taskId });
        }
        console.log("Cleanup completed");
    } catch (error) {
        console.error("Error during cleanup:", error.message);
    }
}

export default cleanup;
