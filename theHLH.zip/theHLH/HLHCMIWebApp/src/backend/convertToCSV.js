import realm_app from "./UserContext";


function downloadFileFromString(string, filename) {
  // Create a new Blob object from the string.
  const blob = new Blob([string]);

  // Create a URL object from the Blob object.
  const url = window.URL.createObjectURL(blob);

  // Create a new anchor element and set its `href` attribute to the URL object.
  const anchorElement = document.createElement('a');
  anchorElement.href = url;

  // Set the `download` attribute of the anchor element to the desired filename.
  anchorElement.download = filename;

  // Append the anchor element to the document body.
  document.body.appendChild(anchorElement);

  // Click the anchor element.
  anchorElement.click();

  // Remove the anchor element from the document body.
  document.body.removeChild(anchorElement);
}

async function convertArrayOfObjectsToCSV() {

  const subcollection = realm_app.currentUser
    .mongoClient("mongodb-atlas")
    .db("subinfo")
    .collection("subdata");
  const data2 = await subcollection.find();
  help(data2, "User-Data.csv");

}

async function help(data, filename) {
  const keys = ["Name", "Rewarded", "Balance", "Venmo"];
  // console.log("Keys- ", keys);
  // console.log("data- ", data);
  const groupedData = data.reduce((acc, data) => {
    // console.log(data);
    const name = data.userdata["name"];
    const id = data["user_id"];
    const venmoId = data.userdata["venmo"] !== undefined ? data.userdata["venmo"] : '';
    // const taskAmount = data["amount"];
    // const reward = data["reward"];
    if (!acc[id]) {
      acc[id] = { user_id: name, earned: 0, balance: 0, venmo: venmoId };
    }
    if (data.status === "accepted" || data.status === "partiallyAccepted") {
      if(data.reward != 0){
        acc[id].earned += Number(data.reward);
      }else{
        acc[id].balance += Number(data.amount);
      }   
    }
    return acc;
  }, {});

  const groupedArray = Object.values(groupedData);
  // console.log("GA ", groupedArray);
  const headerRow = keys.join(",");
  const csvRows = groupedArray.map((object) => {
    const combinedRow = [object.user_id, object.earned, object.balance, object.venmo].join(",");
    return combinedRow;
  });

  const csvString = [headerRow, ...csvRows].join("\n");
  downloadFileFromString(csvString, filename);
}



async function toCSV_1(data, filename) {
  console.log("1 ", data);
  // Get the keys of the objects.
  // const keys = Object.keys(data[0]);
  // Create a CSV header row.
  const columnNames = ['Name', 'Balance', 'ToalEarned', 'venmo'];
  const headerRow = columnNames.join(",");
  // Map over the array of objects and create a row for each object.
  const csvRows = data.map((object) => {
    const nameValue = object["name"] !== undefined ? object["name"] : '';
    const balanceValue = object["balance"] !== undefined ? object["balance"] : '';
    const totalEarnedValue = object["totalEarned"] !== undefined ? object["totalEarned"] : '';
    const venmoId = object["venmo"] !== undefined ? object["venmo"] : '';

    // Combine the values into a single row.
    const combinedRow = [nameValue, balanceValue, totalEarnedValue, venmoId].join(",");
    return combinedRow;
  });
  //   //console.log(csvString)
  const csvString = [headerRow, ...csvRows].join("\n");
  downloadFileFromString(csvString, filename);
}


export default convertArrayOfObjectsToCSV