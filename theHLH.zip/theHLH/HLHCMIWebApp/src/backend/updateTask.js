import realm_app from "./UserContext";

async function updateData(taskDetails, user_id) {
    const data = taskDetails.completed_by
    if (data.includes(user_id)) {
        console.log("taskDetails already contains user_id");
        return 0;
    } else {
        // data.push(user_id);
        //console.log("Taskdetails- ", taskDetails);
        const updateTaskPromise = realm_app.currentUser
            .mongoClient("mongodb-atlas")
            .db("taskinfo")
            .collection("taskdata")
            .updateOne(
                { _id: taskDetails._id },
                { $push: { completed_by: user_id } }
            ).then(() => console.log("task.completed_by id inserted"));

        const updateUserPromise = realm_app.currentUser
            .mongoClient("mongodb-atlas")
            .db("userinfo")
            .collection("userdata")
            .updateOne(
                { userId: user_id },
                { $push: { taskSubmissions: taskDetails._id } }
            ).then(() => console.log("Everything Work fine!"));

        // Combine both promises and wait for them to complete
        try {
            await Promise.all([updateTaskPromise, updateUserPromise]);
            console.log("Both updates completed successfully!");
            return 0;
        } catch (error) {
            console.error("Error updating task or user data:", error);
            return 1;
        }

    }


}

export default updateData;