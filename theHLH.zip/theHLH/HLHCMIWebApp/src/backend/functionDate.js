

function formatDate(date) {
    var arr1 = date.split('-');
    const day = arr1[2];
    const month = arr1[1];
    const year = arr1[0];
    return [month, day, year].join('-');
    //return ans;
}
export default formatDate;

// console.log(formatDate('Sun May 11,2014'));