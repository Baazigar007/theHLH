import realm_app from "./UserContext";
import fetchSingleTask from "./fetchSingleTask";

async function updateBulkTaskData(taskObject) {
    //console.log("3 ", taskObject)
    const newId = taskObject.taskid;
    const res1 = await fetchSingleTask(newId);
    const OldDeadline = res1.deadline;

    if (OldDeadline !== taskObject.deadline) {
        console.log("3 ", taskObject.deadline);
        console.log("4 ", OldDeadline);
        const orderOfIds = await realm_app.currentUser.mongoClient("mongodb-atlas")
            .db("Priority").collection("OrderList").find()
        const newOrder = (orderOfIds[0].newArray);
        if (!newOrder.includes(newId)) newOrder.push(newId);

        const delall = await realm_app.currentUser.mongoClient("mongodb-atlas")
            .db("Priority").collection("OrderList")
            .deleteMany();

        const updateArray = await realm_app.currentUser.mongoClient("mongodb-atlas")
            .db("Priority").collection("OrderList")
            .insertOne(
                { newArray: newOrder }
            ).then((e) => console.log("updated List of deadline")).catch((e) => console.log(e));
    }


    const res = await realm_app.currentUser
        .mongoClient("mongodb-atlas")
        .db("taskinfo")
        .collection("taskdata")
        .updateOne(

            { _id: taskObject.taskid },
            {
                $set: {
                    title: taskObject.title, description: taskObject.description, amount: taskObject.amount,
                    deadline: taskObject.deadline
                }
            }
        ).then((val) => console.log("success")).catch((err) => {
            alert(err + "\nPlease try again!")
        })
    // console.log(res)
}

export default updateBulkTaskData;