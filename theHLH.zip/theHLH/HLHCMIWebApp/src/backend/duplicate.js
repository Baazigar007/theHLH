import realm_app from "./UserContext";

async function checkDuplicate(userObject) {
    try {
        await realm_app.emailPasswordAuth.registerUser({
            email: userObject.email,
            password: userObject.password,
        });
        // Registration successful
        return 0;
    } catch (error) {
        if (error.statusCode === 409) {
            // Email already in use
            return 1;
        } else {
            // Other registration error
            console.error(error);
            return -1;
        }
    }
}

export default checkDuplicate;
