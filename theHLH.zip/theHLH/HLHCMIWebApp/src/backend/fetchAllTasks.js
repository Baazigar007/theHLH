import realm_app from "./UserContext";

function compareDatesOnly(date1, date2) {
    
  const timelist = date1.split("-");
  // Extract the date components from each Date object
  const year1 = parseInt(timelist[0]);
  const month1 = parseInt(timelist[1]);
  const day1 = parseInt(timelist[2]);
  
  const timelist2 = date2.split(",")[0].split("/");
  const year2 = parseInt(timelist2[2]);
  const month2 = parseInt(timelist2[0]);
  const day2 = parseInt(timelist2[1]);
  // console.log("year2=>", year2);
  // console.log("year1=>", year1);
  // console.log("month2=>", month2);
  // console.log("month1=>",month1);
  // console.log("day2=>", day2);
  // console.log("day1=>", day1);

  // Compare the date components
  if (year1 < year2 || (year1 === year2 && (month1 < month2 || (month1 === month2 && day1 < day2)))) {
      return -1;
  } else if (year1 > year2 || (year1 === year2 && (month1 > month2 || (month1 === month2 && day1 > day2)))) {
      return 1;
  } else {
      return 0; // Dates are equal
  }
}

async function fetchAllTasks() {
  const currentDate = new Date();

  const tasksCollection = realm_app.currentUser
    .mongoClient("mongodb-atlas")
    .db("taskinfo")
    .collection("taskdata");

  const data = await tasksCollection.find();
  const options = { timeZone: 'America/Los_Angeles' };
  const pstDateString = currentDate.toLocaleString('en-US', options);
  // console.log(pstDateObject);
  const arr = [];
  for (let i = 0; i < data.length; i++) {
    const taskDeadline = data[i].deadline;
    // taskDeadline.setHours(taskDeadline.getHours()+30);
    // if (taskDeadline >= pstDateObject) {
    //   arr.push(data[i]);
    // }
    if (compareDatesOnly(taskDeadline, pstDateString) !== -1) {
      arr.push(data[i]);
    }
  }
  // console.log("All tasks Len", arr.length);
  return arr;

}

export default fetchAllTasks;
