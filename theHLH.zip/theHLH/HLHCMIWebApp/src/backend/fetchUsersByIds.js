import realm_app from "./UserContext";

async function fetchUsersByIDs(userIDs) {
  //console.log("Fetching user data by IDs");
  const tasksCollection = realm_app.currentUser
    .mongoClient("mongodb-atlas")
    .db("userinfo")
    .collection("userdata");

  const users = await tasksCollection.find({ userId: { $in: userIDs } });

  //console.log("fetched data", users);
  return users;
}

export default fetchUsersByIDs;

