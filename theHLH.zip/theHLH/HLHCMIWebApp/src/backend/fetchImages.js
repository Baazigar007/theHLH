import realm_app from "./UserContext";

async function fetchImages(subid) {
  if (subid === 0) {
    console.log("SUBMIT ID IS 0");
    return [];
    // return 0; WRONG!! 
  }
  const subCollection = realm_app.currentUser
    .mongoClient("mongodb-atlas")
    .db("uploads")
    .collection("images");

  //console.log("submitted ID ", subid)

  const data = await subCollection.findOne({ _id: subid })

  if (data === null) {
    return [];
  }
  //   cons
  return data.images;

}

export default fetchImages;
