import realm_app from "./UserContext";
import logoutUser from "./logout";




async function updateUserData(userObject) {
  const id = userObject.userId
  // console.log(userObject._id);
  delete userObject._id
  // console.log("ID-> ", id);
  // console.log(userObject);

  const res = await realm_app.currentUser
    .mongoClient("mongodb-atlas")
    .db("userinfo")
    .collection("userdata").updateOne(
      { userId: id },
      { $set: userObject }
    ).then(() =>
      logoutUser().then((_) => {
        window.location.href = "/";
      })
    )
    .catch((err) => {
      alert(err + "\nPlease try again!")
    })
  //console.log(res);
}

export default updateUserData;
