import realm_app from "./UserContext";
async function createTaskFromData(taskObject) {
  const characters = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
  let task_id = ""
  for (let i = 0; i < 16; i++) {
    task_id += characters.charAt(Math.floor(Math.random() * characters.length));
  }

  taskObject._id = task_id;
  taskObject.completed_by = []

  const newId = taskObject._id;
  const orderOfIds = await realm_app.currentUser.mongoClient("mongodb-atlas")
    .db("Priority").collection("OrderList").find()
  const newOrder = (orderOfIds[0].newArray);
  newOrder.push(newId);

  const delall = await realm_app.currentUser.mongoClient("mongodb-atlas")
    .db("Priority").collection("OrderList")
    .deleteMany();

  const updateArray = await realm_app.currentUser.mongoClient("mongodb-atlas")
    .db("Priority").collection("OrderList")
    .insertOne(
      { newArray: newOrder }
    ).then((e) => console.log("Created+updated")).catch((e) => console.log(e));

  // console.log("-> ", taskObject);
  const res = await realm_app.currentUser
    .mongoClient("mongodb-atlas")
    .db("taskinfo")
    .collection("taskdata")
    .insertOne(taskObject);
  //console.log(res);
}

export default createTaskFromData;
