import "./UserContext"
import realm_app from "./UserContext";


const fetchadminwallet = async (userId) => {
    const subCollection = realm_app.currentUser
        .mongoClient("mongodb-atlas")
        .db("subinfo")
        .collection("subdata");
    // console.log("subid" + JSON.stringify(userId))

    const data = await subCollection.find({ user_id: userId });
    let earn = 0;
    let bal = 0;

    for (let i = 0; i < data.length; i++) {
        //console.log(data[i]);
        if (data[i].status === "accepted" || data[i].status === "partiallyAccepted") {
            if(data[i].reward == 0){
                bal += Number(data[i].amount);
            }else{
                earn += Number(data[i].reward);
            }
        }
    }
    // console.log("subid is", earn + " " + bal);
    const tasksCollection = realm_app.currentUser
        .mongoClient("mongodb-atlas")
        .db("userinfo")
        .collection("userdata").updateOne({ userId: userId }, { $set: { balance: bal, totalEarned: earn } });

    return [earn, bal];
}

export default fetchadminwallet;