import realm_app from "./UserContext";
import * as Realm from "realm-web";
import logoutUser from "./logout";

async function createUserFromData(userObject) {
  // await realm_app.emailPasswordAuth
  //   .registerUser({
  //     email: userObject.email,
  //     password: userObject.password,
  //   }).then(() => {
  //     console.log("Register DONE");
  //   }).catch(err => {
  //     console.log("SAME HAI!!!");
  //     alert("SAME HAI!!!");
  //     return 0;
  //   });
  console.log("CREATING USER");
  const credentials = Realm.Credentials.emailPassword(
    userObject.email,
    userObject.password
  );
  const user = await realm_app.logIn(credentials);
  const usersCollection = await realm_app.currentUser
    .mongoClient("mongodb-atlas")
    .db("userinfo")
    .collection("userdata");
  userObject.userId = user.id;
  usersCollection.insertOne(userObject)
    .then(() => {
      //console.log("User data inserted into MongoDB");
      logoutUser().then((_) => {
        window.location.href = "/";
      });
    })
    .catch((error) => {
      console.error("Error inserting user data:", error);
    });

}

export default createUserFromData;
