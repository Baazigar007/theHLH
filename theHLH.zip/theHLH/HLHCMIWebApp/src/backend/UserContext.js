import * as Realm from "realm-web";
// Add your App ID
const realm_app = new Realm.App({ id: "application-0-hnblo" });

export default realm_app;