import realm_app from "./UserContext";

// async function loginStatus() {
//   if (realm_app.currentUser) {
//     return { "isLogged": true, "isAdmin": realm_app.currentUser.customData.isAdmin };
//   }
//   //console.log("user doesnt exist")
//   return { "isLogged": false, "isAdmin": false };
// }
async function loginStatus() {
  try {
    if (realm_app.currentUser) {
      if (realm_app.currentUser.customData && realm_app.currentUser.customData.isAdmin !== undefined) {
        return { "isLogged": true, "isAdmin": realm_app.currentUser.customData.isAdmin };
      } else {
        // Handle the case where customData or isAdmin is not found
        console.error("Custom data or isAdmin not found for the current user.");
        return { "isLogged": true, "isAdmin": false }; // You can set isAdmin to a default value or handle it as per your requirement
      }
    }
    //console.log("user doesnt exist")
    return { "isLogged": false, "isAdmin": false };
  } catch (error) {
    // Handle any unexpected errors
    alert("Please try refreshing the website once");
    return { "isLogged": false, "isAdmin": false }; // Return a default value or handle the error as per your requirement
  }
}


export default loginStatus;