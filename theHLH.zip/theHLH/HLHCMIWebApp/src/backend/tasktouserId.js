import realm_app from "./UserContext";

async function tasktouserId(params, userid) {
    try {
        const res2Array = await Array.from(
            await realm_app.currentUser
                .mongoClient("mongodb-atlas")
                .db("subinfo")
                .collection("subdata")
                .find({
                    $and: [
                        { task_id: params },
                        { user_id: userid }
                    ]
                })
        );
        console.log("Tasktouser id ", res2Array)
        console.log(params, userid)
        return res2Array.length > 0 ? res2Array[0]._id : 0;
    } catch (error) {
        console.error("Error in tasktouserId:", error.message);
        return 0;
    }
}

export default tasktouserId;
