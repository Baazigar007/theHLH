import realm_app from "./UserContext";

async function deleteData(taskDetails) {
    // console.log(taskDetails);
    const res1 = await realm_app.currentUser
        .mongoClient("mongodb-atlas")
        .db("taskinfo")
        .collection("taskdata")
        .find(
            { _id: taskDetails._id }, //DO OPERATION WITH IDS
        );
    // console.log(res1);
    if (res1[0].completed_by.length > 0) {
        return alert("It is Already Accepted By Someone");
    }
    //Alert before delete
    alert("Confirm Delete");
    const orderOfIds = await realm_app.currentUser.mongoClient("mongodb-atlas")
        .db("Priority").collection("OrderList").find()

    const Order = (orderOfIds[0].newArray);
    const newOderAfterDelete = Order.filter(obj => obj !== res1[0]._id);

    const delall = await realm_app.currentUser.mongoClient("mongodb-atlas")
        .db("Priority").collection("OrderList").deleteMany();

    const updateArray = await realm_app.currentUser.mongoClient("mongodb-atlas")
        .db("Priority").collection("OrderList").insertOne(
            { newArray: newOderAfterDelete }
        ).then((e) => console.log("Deleated+updated")).catch((e) => console.log(e));


    const res = await realm_app.currentUser
        .mongoClient("mongodb-atlas")
        .db("subinfo")
        .collection("subdata")
        .deleteMany(
            { title: taskDetails },
        ).then((val) => console.log("DELETED FROM SUB")).catch((err) => {
            alert(err + "\nNOT DELETED FROM sub!")
        });
    const res2 = await realm_app.currentUser
        .mongoClient("mongodb-atlas")
        .db("taskinfo")
        .collection("taskdata")
        .deleteMany(
            { _id: taskDetails._id },
        ).then((val) => console.log("DELETED FROM TASK")).catch((err) => {
            alert(err + "\nNOT DELETED from task!")
        });

    // Refresh the page
    window.location.reload(true);

}

export default deleteData;