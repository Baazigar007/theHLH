import realm_app from "./UserContext";


async function updateAllTaskId(params, userdata) {
    console.log('updateAllTaskId', params);
    const subCollection = realm_app.currentUser
        .mongoClient("mongodb-atlas")
        .db("subinfo")
        .collection("subdata");
    const submitted = await subCollection.find({ title: params.title });

    for (let i = 0; i < submitted.length; i++) {
        const curuser = submitted[i];

        // Assuming you want to update the TaskId field for each document
        const query = { _id: curuser._id }; // Use the appropriate identifier for your documents
        const update = { $set: { task_id: params._id } };
        // console.log(query, update);
        await subCollection.updateOne(query, update);
    }
    console.log("Done");

}

export default updateAllTaskId;