import realm_app from "./UserContext";

// async function DelteAllInvalids() {
//     const subdataCollection = realm_app.currentUser
//         .mongoClient("mongodb-atlas")
//         .db("subinfo")
//         .collection("subdata");

//     const imageCollection = realm_app.currentUser
//         .mongoClient("mongodb-atlas")
//         .db("uploads")
//         .collection("images");

//     // const data = await subdataCollection.find();
//     const Delarray = ["IKR5W9VDOQ746QzC", "qU8O3aWTkx2NeSxR", "xOSC3wH5Ntve4gNq", "chrECN4iUNCY7p2q", "278WsClxFXgtkkwh", "Vw85M9btgaQuc4r1", "pOwNXwwTXHimk5C7", "fFsTnWW8cFi7SImQ", "ShGfGXQhdauNXUEa", "gQzYljve8h5iOlIc", "q9oPta1OsrYCsFkW", "GQx53cygralRtvDq", "iRyoHAkJsrctjjo2", "pcQ0NNnFgggw06Id", "iNI6Qp1mtl1RCayr", "RPME0wN6tRBRZtMq", "7FGX9enHRNBg0klS", "oElsWqxnDXzJ7xVX", "U168q7fuWBaSkr4E", "vW2Y3CxGVPjyPLmB", "MV0lwNyo3GzlXm3j", "pGrVyYzaPKEXCJrn", "fdNXMm1owYWm5Egi", "A1tHcKnzR9Vu8Hpo", "02wL8I3pTGy56H6P", "e3BDjrSsE7EH2OVb", "zs3vESiwYPZs9iy9", "2m6jooc7cJhhmtpB", "HlYiNmRJzzsjOotW", "4JhlKaJPmXcICt3N", "eUbyWy6NSl7aZdcA", "rmDlbqIefMZtyXkt", "06xGplILpFj9W3ix", "qBQDiKsBKoXfqKre", "aC90Z9puBeqUUtZ3", "UWvRt5upsjg2onqf", "vPmC8a6A6dDJkopx", "fWoJXCipH0bThChG", "PZTcJ9UMcNg1nBok", "Ji05Tyv0xVjBte5O", "aKcuxCGDJ76wWAdy", "3K4hzYzmEiFPeVOE", "0enJbHbAfr7HiMGf", "6Mf8bzpfwiPbRWIX", "v6Q51uQPC7lrsNk1", "AKnuyHdq9sEoTuHt", "QjdRDF0ezMfblXUM", "xExhQvnet00K00fe", "gMSqTlgUSouEF9Pd", "EEK7QailXSllebtN", "ZTLL5hwHguTUzcwJ", "7WvTJ2q6Jjc9MgxH", "g5dx4NByxgjo4tmL", "4Mg2jO0aOd0BJNpY"];
//     for (const imgdata of Delarray) {
//         const image = await subdataCollection.deleteMany({ _id: imgdata });
//         console.log(image);
//     }
// }

async function DelteAllInvalids1() {
    // const userCollection = realm_app.currentUser
    //     .mongoClient("mongodb-atlas")
    //     .db("userinfo")
    //     .collection("userdata");
    const subCollection = realm_app.currentUser
        .mongoClient("mongodb-atlas")
        .db("subinfo")
        .collection("subdata");

    const taskCollection = realm_app.currentUser
        .mongoClient("mongodb-atlas")
        .db("taskinfo")
        .collection("taskdata");

    const taskData = await taskCollection.find();
    // const userData = await userCollection.find();
    const map = new Map();

    for (let i = 0; i < taskData.length; i++) {
        const completed_by = taskData[i].completed_by;
        //["654d8d0ca45337a07daaea81","654d639507603216f7a760b4","654e61bd07603216f77e8724"]
        const task_id1 = taskData[i]._id;
        for (let j = 0; j < completed_by.length; j++) {
            const res2 = await subCollection.find({
                $and: [
                    { task_id: task_id1 },
                    { user_id: completed_by[j] }
                ]
            });
            // if (!res2) {
            //     if (map.has(task_id1).has(completed_by[j])) {
            //         const val = map.get(task_id1).get(completed_by[j]);
            //         // console.log(val);
            //         map.set(task_id1, map.set(completed_by[j], val + 1));
            //     } else {
            //         const temp = new Map();
            //         temp.set(completed_by[j], 1);
            //         map.set(task_id1, temp);
            //     }
            // } else {
            if (res2.length > 1) {
                console.log(res2);
            }

            // }
        }
    }
    console.log("ok");
    console.log(map);

}


async function DelteAllInvalids() {
    const subCollection = realm_app.currentUser
        .mongoClient("mongodb-atlas")
        .db("subinfo")
        .collection("subdata");
    const subData = await subCollection.find();


    const imageCollection = await realm_app.currentUser
        .mongoClient("mongodb-atlas")
        .db("uploads")
        .collection("images");

    for (let i = 0; i < subData.length; i++) {
        const sub_id = subData[i]._id;
        let f = false;
        const d = await imageCollection.findOne({ _id: sub_id })
        if (d !== null) {
            // console.log(d);
            f = true;
        }
        if (f === false) {
            console.log("RT ", sub_id);
        }
    }

}

async function DelteAllInvalids2() {

    const userCollection = realm_app.currentUser
        .mongoClient("mongodb-atlas")
        .db("userinfo")
        .collection("userdata");
    const userData = await userCollection.findOne({ name: "Testuser4" });
    const taskSubmission = await userData.taskSubmissions;
    console.log(taskSubmission);


    const subCollection = realm_app.currentUser
        .mongoClient("mongodb-atlas")
        .db("subinfo")
        .collection("subdata");
    // const subData = await subCollection.find();

    const taskCollection = realm_app.currentUser
        .mongoClient("mongodb-atlas")
        .db("taskinfo")
        .collection("taskdata");
    // const taskData = await taskCollection.find();


    const imageCollection = await realm_app.currentUser
        .mongoClient("mongodb-atlas")
        .db("uploads")
        .collection("images");

    for (let i = 0; i < taskSubmission.length; i++) {
        const task_id1 = taskSubmission[i];
        // let f = false;
        // console.log(task_id1);
        const d = await realm_app.currentUser
            .mongoClient("mongodb-atlas")
            .db("subinfo")
            .collection("subdata").find(

                { _id: task_id1 }

            );
        console.log(d);
        // if (d !== null) {
        //     console.log(d);
        //     const dimage = await realm_app.currentUser
        //         .mongoClient("mongodb-atlas")
        //         .db("uploads")
        //         .collection("images").deleteOne({ _id: d._id });
        //     console.log(dimage[0]);

        // }
        // if (d===null) {
        //     console.log("RT ", d);
        //     await subCollection.deleteOne({})
        // }
    }

}


export default DelteAllInvalids;
