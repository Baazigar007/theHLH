import realm_app from "./UserContext";

async function redirectPage(props, useridfinded) {
    const res2 = await realm_app.currentUser
        .mongoClient("mongodb-atlas")
        .db("subinfo")
        .collection("subdata")
        .find({
            "$and": [
                { task_id: props },
                { user_id: useridfinded }
            ]
        }
        );
    if (res2[0]) {
        return res2[0]._id;
    } else {
        //console.log(props, useridfinded);
        console.error('Document or _id property not found.');
        return null;
    }
}

export default redirectPage;
