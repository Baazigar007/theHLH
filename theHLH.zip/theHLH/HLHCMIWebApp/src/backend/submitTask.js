import realm_app from "./UserContext";
import tasktouserId from "../backend/tasktouserId";
import cleanUp from "./cleanUp";

async function SubmitData(submitObject, imgarray, OldImage_length) {
    console.log("Submit data function starts");
    //console.log(submitObject, imgarray, OldImage_length);

    const userId = submitObject.user_id;
    const searchParams = new URLSearchParams(window.location.search);
    const id = searchParams.get("taskid");
    const getSubmitId = await tasktouserId(id, userId);

    if ((OldImage_length + imgarray.length) > 10) {
        return alert("Cannot upload more than 10 images for one task");
    }

    else if (getSubmitId && getSubmitId !== 0) {
        console.log("OLD IMAGES IN DB ALREADY!!");
        try {
            const collection = await realm_app.currentUser
                .mongoClient("mongodb-atlas")
                .db("uploads")
                .collection("images");

            console.log("2 ", getSubmitId)
            // Use Promise.all to parallelize update operations
            await Promise.all(imgarray.map(async (img) => {
                await collection.updateOne(
                    { _id: getSubmitId },
                    { $push: { images: img } }, { upsert: true }
                );
            }));
            console.log("Submit data function ends");

            return 0;
        } catch (error) {
            console.log("Error updating images:", error);
            await cleanUp(getSubmitId);
            return 1;
        }
    }
    else {

        console.log("NO OLD IMAGES!!");

        // console.log("Submit Object- ", submitObject);
        try {
            const characters = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
            let task_id = "";
            for (let i = 0; i < 16; i++) {
                task_id += characters.charAt(Math.floor(Math.random() * characters.length));
            }
            submitObject._id = task_id;

            await Promise.all([
                await realm_app.currentUser.mongoClient("mongodb-atlas").db('subinfo')
                    .collection('subdata').insertOne(submitObject),
                await realm_app.currentUser.mongoClient("mongodb-atlas").db('uploads')
                    .collection('images').insertOne({ _id: task_id, images: imgarray })
            ]);

            return 0;
        } catch (error) {
            console.log("Error during operations:", error.message);
            await cleanUp(getSubmitId);
            return 1;
        }
    }
}



export default SubmitData;