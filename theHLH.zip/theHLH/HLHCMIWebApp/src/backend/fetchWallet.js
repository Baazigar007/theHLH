import realm_app from "./UserContext";

async function fetchWallet() {
  const tasksCollection = realm_app.currentUser
    .mongoClient("mongodb-atlas")
    .db("subinfo")
    .collection("subdata");
  const userid = await realm_app.currentUser.id;
  const filtered_data = [];
  let pending = 0;
  let accepted = 0;
  let earn = 0;
  let bal = 0;
  const data = await tasksCollection.find();
  for (let i = 0; i < data.length; i++) {

    if (data[i].user_id === userid) {
      filtered_data.push(data[i]);
      if (data[i].status == 'accepted' || data[i].status == 'partiallyAccepted'){
        accepted++;
        if(data[i].reward == 0){
          bal += Number(data[i].amount); 
        }else{
          earn += Number(data[i].reward);
        }
      }
      else{
        pending++;
      }
    }
  }
  return [filtered_data, pending, accepted, bal, earn];
}

export default fetchWallet;
