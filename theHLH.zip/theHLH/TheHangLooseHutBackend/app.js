const express = require("express");
var cors = require("cors");
var axios = require("axios");
const app = express();
const crypto = require("crypto");
const FormData = require("form-data");
var bodyParser = require('body-parser');
var dbconnection = require('./dbcon');

function storeRawBody(req, res, buf) {
  if (buf && buf.length) {
    req.rawBody = buf.toString("utf8");
  }
}

app.use(express.static("public"));
app.use(cors());
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ limit: '50mb' }));
app.use(
  express.json({
    verify: storeRawBody,
  })
);

app.use(express.urlencoded({ verify: storeRawBody, extended: true }));

function isValidSignature(body, signature) {
  let hmac = crypto.createHmac(process.env.SIGNING_SECRET_ALGORITHM, process.env.SIGNING_SECRET);
  let sig = hmac.update(body).digest("base64");
  console.log(sig);
  console.log("signature" + Buffer.from(signature));
  console.log("signature" + Buffer.from(sig.toString("base64")));

  return (
    Buffer.compare(
      Buffer.from(signature),
      Buffer.from(sig.toString("base64"))
    ) === 0
  );
}

const tagIDs = new Map([
  ['12', '1202248977191917'],
  ['14', '1202248977191920'],
  ['15', '1202248977191923'],
  ['1', '1202253595593936'],
  ['3', '1202253595593946'],
  ['7', '1202253595593938'],
  ['8', '1202253595593939'],
  ['13', '1202253595593941'],
  ['2', '1202253595593937'],
  ['0', '1202390870070832'],
])

function GetSubtaskConfig(id) {
  return {
    method: 'get',
    url: `https://app.asana.com/api/1.0/tasks/${id}`,
    headers: {
      'Authorization': `Bearer ${process.env.BEARER}`
    }
  }
}

function makeid(length) {
  let result = '';
  const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  const charactersLength = characters.length;
  let counter = 0;
  while (counter < length) {
    result += characters.charAt(Math.floor(Math.random() * charactersLength));
    counter += 1;
  }
  return result;
}

// Dummy
app.get("/", function (req, res) {
  console.log("Dummy get");
  res.send("GET: Server is running.");
});

// To get all the listed designs
app.get("/designs", function (req, res) {
  console.log("Designs get");
  var config = {
    method: "get",
    url: "https://api.affinitygateway.com/designs",
    headers: {
      "X-Api-Key": process.env.X_API_KEY,
    },
  };

  axios(config)
    .then((data) => {
      res.send({ designs: data.data });
    })
    .catch((error) => {
      res.send({ error: error });
    });
});

// To get all the licensed organizations
app.get("/clients", function (req, res) {
  console.log("Clients get");
  var config = {
    method: "get",
    url: "https://api.affinitygateway.com/clients",
    headers: {
      "X-Api-Key": process.env.X_API_KEY,
    },
  };

  axios(config)
    .then((data) => {
      res.send({ clients: data.data });
    })
    .catch((error) => {
      res.send({ error: error });
    });
});

// Will be used for dropdowns while uploading designs
app.get("/categories", function (req, res) {
  console.log("Categories get");
  var config = {
    method: "get",
    url: "https://api.affinitygateway.com/product_categories",
    headers: {
      "X-Api-Key": process.env.X_API_KEY,
    },
  };

  axios(config)
    .then((data) => {
      res.send({ categories: data.data.data });
    })
    .catch((error) => {
      res.send({ error: error });
    });
});

// Will be used to get tasks in each section for the logistics
app.get("/fetchtasks", function (req, res) {
  if (req.query.gid) {
    var config = {
      method: 'get',
      url: `https://app.asana.com/api/1.0/sections/${req.query.gid}/tasks`,
      headers: {
        'Authorization': `Bearer ${process.env.BEARER}`
      }
    };

    axios(config)
      .then(function (response) {
        res.send({
          tasks: response.data,
        });
      })
      .catch(function (error) {
        console.log(error);
      });
  } else {
    res.send('No Task ID')
  }
});

// Will be used to mock login
app.get("/login", function (req, res) {
  const ID = req.query.id.toUpperCase().replace(/ /g, '')
  const PWD = req.query.pwd

  console.log(ID)
  console.log(PWD)

  if (ID === process.env.USERNAME && PWD === process.env.PASSWORD) {
    res.send({ status: true, userType: "asanatron" })
  }
  else if (ID === process.env.USERNAME_ADMIN && PWD === process.env.PASSWORD_ADMIN) {
    res.send({ status: true, userType: "admin" })
  }
  else if (ID === process.env.USERNAME_QUOTE && PWD === process.env.PASSWORD_QUOTE) {
    res.send({ status: true, userType: "quotemaster" })
  }
  else if (ID === process.env.USERNAME_QUOTE2 && PWD === process.env.PASSWORD_QUOTE2) {
    res.send({ status: true, userType: "quotemaster" })
  }
  else if (ID === process.env.USERNAME_QUOTE3 && PWD === process.env.PASSWORD_QUOTE3) {
    res.send({ status: true, userType: "quotemaster" })
  }
  else {
    res.send({ status: false, userType: null })
  }
});

// Will be used to add Pending review tag to a task
app.post("/tagreview", (req, TagRes) => {
  if (req.query.taskid) {
    var Tagdata = new FormData();
    Tagdata.append('tag', '1202253595593946');

    var Tagconfig = {
      method: 'post',
      url: `https://app.asana.com/api/1.0/tasks/${req.query.taskid}/addTag`,
      headers: {
        'Authorization': `Bearer ${process.env.BEARER}`,
        ...Tagdata.getHeaders()
      },
      data: Tagdata
    };

    axios(Tagconfig).then((res) => {
      var GetSubTaskconfig = {
        method: 'get',
        url: `https://app.asana.com/api/1.0/tasks/${req.query.taskid}`,
        headers: {
          'Authorization': `Bearer ${process.env.BEARER}`
        }
      };

      axios(GetSubTaskconfig)
        .then((ParentRes) => {
          if (JSON.parse(JSON.stringify(ParentRes.data)).data.parent !== null) {
            var ParentTagdata = new FormData();
            ParentTagdata.append('tag', '1202253595593946');

            var ParentTagconfig = {
              method: 'post',
              url: `https://app.asana.com/api/1.0/tasks/${JSON.parse(JSON.stringify(ParentRes.data)).data.parent.gid}/addTag`,
              headers: {
                'Authorization': `Bearer ${process.env.BEARER}`,
                ...ParentTagdata.getHeaders()
              },
              data: ParentTagdata
            };

            axios(ParentTagconfig).then((res) => {
              TagRes.send('Moved')
            }).catch(function (error) {
              console.log(error);
            });
          } else {
            TagRes.send('Moved')
          }
        }).catch(function (error) {
          console.log(error);
        });
    }).catch(function (error) {
      console.log(error);
    });
  } else {
    TagRes.send('No Task ID')
  }
});

// Will be used to get a task
app.get("/gettask", (req, TaskRes) => {
  if (req.query.taskid) {
    var GetTaskConfig = {
      method: 'get',
      url: `https://app.asana.com/api/1.0/tasks/${req.query.taskid}`,
      headers: {
        'Authorization': `Bearer ${process.env.BEARER}`
      }
    };

    axios(GetTaskConfig).then((res) => {
      TaskRes.send({ task: res.data })
    }).catch(function (error) {
      console.log(error);
    });
  } else {
    res.send('No Task ID')
  }
});

// Will be used to get subtasks of a task
app.get("/getsubtask", (req, SubtaskRes) => {
  if (req.query.taskid) {
    var GetTaskConfig = {
      method: 'get',
      url: `https://app.asana.com/api/1.0/tasks/${req.query.taskid}/subtasks`,
      headers: {
        'Authorization': `Bearer ${process.env.BEARER}`
      }
    };

    axios(GetTaskConfig).then((res) => {
      SubtaskRes.send({ subtasks: res.data })
    }).catch(function (error) {
      console.log(error);
    });
  } else {
    res.send('No Task ID')
  }
});

// Will be used to move a task
app.post("/movetask", async (req, MoveRes) => {
  if (req.query.taskid && req.query.sectionid) {
    var MoveParentTaskdata = new FormData();
    MoveParentTaskdata.append('task', req.query.taskid);

    var MoveParentTaskconfig = {
      method: 'post',
      url: `https://app.asana.com/api/1.0/sections/${req.query.sectionid}/addTask`,
      headers: {
        'Authorization': `Bearer ${process.env.BEARER}`,
        ...MoveParentTaskdata.getHeaders()
      },
      data: MoveParentTaskdata
    };

    axios(MoveParentTaskconfig)
      .then((res) => {
        MoveRes.send(200)
      })
      .catch(function (error) {
        console.log(error);
      });
  } else {
    res.send('No task ID or section ID')
  }
});

// Will be used to get projectID of a task
app.get("/getprojectid", (req, ProjectIDRes) => {
  if (req.query.taskid) {
    var GetTaskConfig = {
      method: 'get',
      url: `https://app.asana.com/api/1.0/tasks/${req.query.taskid}/projects`,
      headers: {
        'Authorization': `Bearer ${process.env.BEARER}`
      }
    };

    axios(GetTaskConfig).then((res) => {
      ProjectIDRes.send({ projectID: JSON.parse(JSON.stringify(res.data)).data[0].gid })
    }).catch(function (error) {
      console.log(error);
    });
  } else {
    ProjectIDRes.send('No Task ID')
  }
});

// Will be used to get projectID of a task
app.get("/getsections", (req, SectionsList) => {
  if (req.query.projectid) {
    var GetSectionsConfig = {
      method: 'get',
      url: `https://app.asana.com/api/1.0/projects/${req.query.projectid}/sections`,
      headers: {
        'Authorization': `Bearer ${process.env.BEARER}`
      }
    };

    axios(GetSectionsConfig).then((res) => {
      if (JSON.parse(JSON.stringify(res.data)).data.find(o => o.name === 'PENDING IN AFFINITY')) {
        SectionsList.send({ sectionID: JSON.parse(JSON.stringify(res.data)).data.find(o => o.name === 'PENDING IN AFFINITY').gid })
      } else if (JSON.parse(JSON.stringify(res.data)).data.find(o => o.name === 'PENDING AFFINITY')) {
        SectionsList.send({ sectionID: JSON.parse(JSON.stringify(res.data)).data.find(o => o.name === 'PENDING AFFINITY').gid })
      } else {
        SectionsList.send({ sectionID: '' })
      }
    }).catch(function (error) {
      console.log(error);
    });
  } else {
    SectionsList.send('No Task ID')
  }
});

// Webhook handler
app.post("/hook", (req, MainRes) => {
  GreenID = [14, 15]
  RedID = [7, 8, 9, 12, 13, 1, 2]
  YellowID = [0]

  console.log("phase id: ", req.body.payload.data.phase.id)
  console.log("payload : ", req.body.payload.data)

  if (GreenID.includes(req.body.payload.data.phase.id)) {
    console.log('Approved')

    if (req.body.payload.data.description) {
      var GetTagsconfig = {
        method: 'get',
        url: `https://app.asana.com/api/1.0/tasks/${req.body.payload.data.description}/tags`,
        headers: {
          'Authorization': `Bearer ${process.env.BEARER}`
        }
      };

      axios(GetTagsconfig)
        .then((res) => {
          var RemoveTagdata = new FormData();
          console.log('removing tags')
          RemoveTagdata.append('tag', JSON.parse(JSON.stringify(res.data)).data[0].gid);
          var RemoveDataconfig = {
            method: 'post',
            url: `https://app.asana.com/api/1.0/tasks/${req.body.payload.data.description}/removeTag`,
            headers: {
              'Authorization': `Bearer ${process.env.BEARER}`,
              ...RemoveTagdata.getHeaders()
            },
            data: RemoveTagdata
          };

          axios(RemoveDataconfig)
            .then((res) => {
              var AddTagdata = new FormData();
              console.log('adding tags')
              AddTagdata.append('tag', tagIDs.get(String(req.body.payload.data.phase.id)));

              var AddTagconfig = {
                method: 'post',
                url: `https://app.asana.com/api/1.0/tasks/${req.body.payload.data.description}/addTag`,
                headers: {
                  'Authorization': `Bearer ${process.env.BEARER}`,
                  ...AddTagdata.getHeaders()
                },
                data: AddTagdata
              };

              axios(AddTagconfig).then((res) => {
                console.log('getting subtask')
                var GetSubTaskconfig = {
                  method: 'get',
                  url: `https://app.asana.com/api/1.0/tasks/${req.body.payload.data.description}`,
                  headers: {
                    'Authorization': `Bearer ${process.env.BEARER}`
                  }
                };

                axios(GetSubTaskconfig)
                  .then((ParentRes) => {
                    console.log('getting parent')

                    var ParentGID = ''
                    //parent check
                    if (JSON.parse(JSON.stringify(ParentRes.data)).data.parent !== null) {
                      ParentGID = JSON.parse(JSON.stringify(ParentRes.data)).data.parent.gid
                    } else {
                      ParentGID = JSON.parse(JSON.stringify(ParentRes.data)).data.gid
                    }

                    var GetParentTaskconfig = {
                      method: 'get',
                      url: `https://app.asana.com/api/1.0/tasks/${ParentGID}/subtasks`,
                      headers: {
                        'Authorization': `Bearer ${process.env.BEARER}`
                      }
                    };

                    axios(GetParentTaskconfig).then((res) => {
                      console.log('parent to subtask check')
                      var IsComplete = true;

                      Promise.all(JSON.parse(JSON.stringify(res.data)).data.map((subtask) => {
                        return axios(GetSubtaskConfig(subtask.gid))
                      })).then((values) => {
                        values.map(value => {
                          if (value.data.data.tags.length === 0) {
                            IsComplete = false
                          } else if (value.data.data.tags[0].gid !== '1202248977191920' && value.data.data.tags[0].gid !== '1202248977191923') {
                            IsComplete = false
                          }
                        })

                        if (IsComplete) {
                          var MoveParentTaskdata = new FormData();
                          MoveParentTaskdata.append('task', ParentGID);

                          console.log('complete')
                          console.log("parent :" + ParentGID)

                          var GetProjectForTask = {
                            method: 'get',
                            url: `https://app.asana.com/api/1.0/tasks/${ParentGID}/projects`,
                            headers: {
                              'Authorization': `Bearer ${process.env.BEARER}`
                            }
                          };

                          console.log("getting project")

                          axios(GetProjectForTask).then((res) => {
                            var projectID = JSON.parse(JSON.stringify(res.data)).data[0].gid

                            if (projectID) {
                              var GetSectionIDOfTask = {
                                method: 'get',
                                url: `https://app.asana.com/api/1.0/projects/${projectID}/sections`,
                                headers: {
                                  'Authorization': `Bearer ${process.env.BEARER}`
                                }
                              };

                              console.log("getting sectionID")
                              console.log(projectID)

                              axios(GetSectionIDOfTask).then((res) => {

                                var sectionID = ''

                                console.log(JSON.parse(JSON.stringify(res.data)))

                                if (JSON.parse(JSON.stringify(res.data)).data.find(o => o.name === 'FORMAT FOR SOCIALS (Approved by Affinity)')) {
                                  sectionID = JSON.parse(JSON.stringify(res.data)).data.find(o => o.name === 'FORMAT FOR SOCIALS (Approved by Affinity)').gid
                                } else if (JSON.parse(JSON.stringify(res.data)).data.find(o => o.name === 'APPROVED BY AFFINITY')) {
                                  sectionID = JSON.parse(JSON.stringify(res.data)).data.find(o => o.name === 'APPROVED BY AFFINITY').gid
                                }

                                console.log(sectionID)

                                if (sectionID != '') {
                                  var MoveParentTaskconfig = {
                                    method: 'post',
                                    url: `https://app.asana.com/api/1.0/sections/${sectionID}/addTask`,
                                    headers: {
                                      'Authorization': `Bearer ${process.env.BEARER}`,
                                      ...MoveParentTaskdata.getHeaders()
                                    },
                                    data: MoveParentTaskdata
                                  };

                                  console.log("moving parent")

                                  axios(MoveParentTaskconfig)
                                    .then((res) => {
                                      var RemoveParentTagdata = new FormData();
                                      console.log('removing parent tags')
                                      RemoveParentTagdata.append('tag', '1202253595593946');
                                      var RemoveParentDataconfig = {
                                        method: 'post',
                                        url: `https://app.asana.com/api/1.0/tasks/${ParentGID}/removeTag`,
                                        headers: {
                                          'Authorization': `Bearer ${process.env.BEARER}`,
                                          ...RemoveParentTagdata.getHeaders()
                                        },
                                        data: RemoveParentTagdata
                                      };

                                      console.log("removing parent tags")

                                      axios(RemoveParentDataconfig).then((res) => {
                                        var ParentAddTagdata = new FormData();
                                        console.log('adding parent tags')
                                        ParentAddTagdata.append('tag', '1202248977191920');

                                        var ParentAddTagConfig = {
                                          method: 'post',
                                          url: `https://app.asana.com/api/1.0/tasks/${ParentGID}/addTag`,
                                          headers: {
                                            'Authorization': `Bearer ${process.env.BEARER}`,
                                            ...ParentAddTagdata.getHeaders()
                                          },
                                          data: ParentAddTagdata
                                        };

                                        console.log("adding parent tags")

                                        axios(ParentAddTagConfig).then((res) => {
                                          MainRes.send('Approved All')
                                        }).catch(function (error) {
                                          console.log(error);
                                        });
                                      }).catch(function (error) {
                                        console.log(error);
                                      });
                                    }).catch(function (error) {
                                      console.log(error);
                                    });
                                }
                              }).catch(function (error) {
                                console.log(error);
                              });
                            } else {
                              SectionsList.send('No Project ID')
                            }
                          }).catch(function (error) {
                            console.log(error);
                          });
                        } else {
                          var MoveParentTaskdata = new FormData();
                          MoveParentTaskdata.append('task', ParentGID);

                          console.log('not complete')
                          var ParentAddTagdata = new FormData();
                          console.log('adding tags')
                          ParentAddTagdata.append('tag', '1204959433738542');

                          var ParentAddTagConfig = {
                            method: 'post',
                            url: `https://app.asana.com/api/1.0/tasks/${ParentGID}/addTag`,
                            headers: {
                              'Authorization': `Bearer ${process.env.BEARER}`,
                              ...ParentAddTagdata.getHeaders()
                            },
                            data: ParentAddTagdata
                          };

                          axios(ParentAddTagConfig).then((res) => {
                            var MoveParentTaskconfig = {
                              method: 'post',
                              url: `https://app.asana.com/api/1.0/sections/1201668317676106/addTask`,
                              headers: {
                                'Authorization': `Bearer ${process.env.BEARER}`,
                                ...MoveParentTaskdata.getHeaders()
                              },
                              data: MoveParentTaskdata
                            };

                            console.log("moving parent")
                          }).catch(function (error) {
                            console.log(error);
                          });

                          MainRes.send('Approved')
                        }
                      })
                    }).catch((err) => {
                      console.log(err)
                    })
                  })
                  .catch(function (error) {
                    console.log(error);
                  });
              }).catch(function (error) {
                console.log(error);
              });

            }).catch(function (error) {
              console.log(error);
            });
        }).catch(function (error) {
          console.log(error);
        });
    } else {
      MainRes.send('No description')
    }
  } else if (RedID.includes(req.body.payload.data.phase.id)) {
    console.log('Rejected')

    if (req.body.payload.data.description) {
      var GetTagsconfig = {
        method: 'get',
        url: `https://app.asana.com/api/1.0/tasks/${req.body.payload.data.description}/tags`,
        headers: {
          'Authorization': `Bearer ${process.env.BEARER}`
        }
      };

      axios(GetTagsconfig)
        .then((res) => {
          var RemoveTagdata = new FormData();
          console.log('removing tags')
          RemoveTagdata.append('tag', JSON.parse(JSON.stringify(res.data)).data[0].gid);
          var RemoveDataconfig = {
            method: 'post',
            url: `https://app.asana.com/api/1.0/tasks/${req.body.payload.data.description}/removeTag`,
            headers: {
              'Authorization': `Bearer ${process.env.BEARER}`,
              ...RemoveTagdata.getHeaders()
            },
            data: RemoveTagdata
          };

          axios(RemoveDataconfig)
            .then((res) => {
              var AddTagdata = new FormData();
              console.log('adding tags')
              AddTagdata.append('tag', tagIDs.get(String(req.body.payload.data.phase.id)));

              var AddTagconfig = {
                method: 'post',
                url: `https://app.asana.com/api/1.0/tasks/${req.body.payload.data.description}/addTag`,
                headers: {
                  'Authorization': `Bearer ${process.env.BEARER}`,
                  ...AddTagdata.getHeaders()
                },
                data: AddTagdata
              };

              axios(AddTagconfig).then((res) => {
                console.log('getting subtask')
                var GetSubTaskconfig = {
                  method: 'get',
                  url: `https://app.asana.com/api/1.0/tasks/${req.body.payload.data.description}`,
                  headers: {
                    'Authorization': `Bearer ${process.env.BEARER}`
                  }
                };

                axios(GetSubTaskconfig)
                  .then((ParentRes) => {
                    console.log('getting parent')

                    var ParentGID = ''
                    //parent check
                    if (JSON.parse(JSON.stringify(ParentRes.data)).data.parent !== null) {
                      ParentGID = JSON.parse(JSON.stringify(ParentRes.data)).data.parent.gid
                    } else {
                      ParentGID = JSON.parse(JSON.stringify(ParentRes.data)).data.gid
                    }

                    var GetParentTagsconfig = {
                      method: 'get',
                      url: `https://app.asana.com/api/1.0/tasks/${ParentGID}/tags`,
                      headers: {
                        'Authorization': `Bearer ${process.env.BEARER}`
                      }
                    };

                    axios(GetParentTagsconfig).then((res) => {
                      var RemoveParentTagdata = new FormData();
                      console.log('removing parent tags')
                      RemoveParentTagdata.append('tag', JSON.parse(JSON.stringify(res.data)).data[0].gid);
                      var RemoveDataconfig = {
                        method: 'post',
                        url: `https://app.asana.com/api/1.0/tasks/${ParentGID}/removeTag`,
                        headers: {
                          'Authorization': `Bearer ${process.env.BEARER}`,
                          ...RemoveParentTagdata.getHeaders()
                        },
                        data: RemoveParentTagdata
                      };

                      axios(RemoveDataconfig).then((res) => {
                        var AddTagOnParentdata = new FormData();
                        console.log('adding parent tag')
                        AddTagOnParentdata.append('tag', '1202390870070832');

                        var AddParentTagconfig = {
                          method: 'post',
                          url: `https://app.asana.com/api/1.0/tasks/${ParentGID}/addTag`,
                          headers: {
                            'Authorization': `Bearer ${process.env.BEARER}`,
                            ...AddTagOnParentdata.getHeaders()
                          },
                          data: AddTagOnParentdata
                        };

                        axios(AddParentTagconfig).then((data) => {
                          var MoveParentTaskdata = new FormData();
                          MoveParentTaskdata.append('task', ParentGID);

                          console.log('moving parent task')

                          var GetTaskConfig = {
                            method: 'get',
                            url: `https://app.asana.com/api/1.0/tasks/${ParentGID}/projects`,
                            headers: {
                              'Authorization': `Bearer ${process.env.BEARER}`
                            }
                          };

                          axios(GetTaskConfig).then((res) => {
                            var projectID = JSON.parse(JSON.stringify(res.data)).data[0].gid

                            if (projectID) {
                              var GetSectionsConfig = {
                                method: 'get',
                                url: `https://app.asana.com/api/1.0/projects/${projectID}/sections`,
                                headers: {
                                  'Authorization': `Bearer ${process.env.BEARER}`
                                }
                              };

                              axios(GetSectionsConfig).then((res) => {

                                var sectionID = ''

                                if (JSON.parse(JSON.stringify(res.data)).data.find(o => o.name === 'NEEDS REVISION')) {
                                  sectionID = JSON.parse(JSON.stringify(res.data)).data.find(o => o.name === 'NEEDS REVISION').gid
                                } else if (JSON.parse(JSON.stringify(res.data)).data.find(o => o.name === 'CUSTOMER DESIGNS')) {
                                  sectionID = JSON.parse(JSON.stringify(res.data)).data.find(o => o.name === 'CUSTOMER DESIGNS').gid
                                } else {
                                  sectionID = ''
                                }

                                var MoveParentTaskconfig = {
                                  method: 'post',
                                  url: `https://app.asana.com/api/1.0/sections/${sectionID}/addTask`,
                                  headers: {
                                    'Authorization': `Bearer ${process.env.BEARER}`,
                                    ...MoveParentTaskdata.getHeaders()
                                  },
                                  data: MoveParentTaskdata
                                };

                                axios(MoveParentTaskconfig).then((data) => {
                                  MainRes.send('Complete')
                                })

                              }).catch(function (error) {
                                console.log(error);
                              });
                            } else {
                              SectionsList.send('No Project ID')
                            }
                          }).catch(function (error) {
                            console.log(error);
                          });
                        })
                      }).catch(err => {
                        console.log(err)
                      })
                    }).catch(err => {
                      console.log(err)
                    })
                  })
                  .catch(function (error) {
                    console.log(error);
                  });
              }).catch(function (error) {
                console.log(error);
              });

            }).catch(function (error) {
              console.log(error);
            });
        }).catch(function (error) {
          console.log(error);
        });
    } else {
      MainRes.send('No description')
    }
  } else if (YellowID.includes(req.body.payload.data.phase.id)) {
    console.log('Pending')

    if (req.body.payload.data.description) {
      var GetTagsconfig = {
        method: 'get',
        url: `https://app.asana.com/api/1.0/tasks/${req.body.payload.data.description}/tags`,
        headers: {
          'Authorization': `Bearer ${process.env.BEARER}`
        }
      };

      axios(GetTagsconfig)
        .then((res) => {
          var RemoveTagdata = new FormData();
          console.log('removing tags')
          RemoveTagdata.append('tag', JSON.parse(JSON.stringify(res.data)).data[0].gid);
          var RemoveDataconfig = {
            method: 'post',
            url: `https://app.asana.com/api/1.0/tasks/${req.body.payload.data.description}/removeTag`,
            headers: {
              'Authorization': `Bearer ${process.env.BEARER}`,
              ...RemoveTagdata.getHeaders()
            },
            data: RemoveTagdata
          };

          axios(RemoveDataconfig)
            .then((res) => {
              var AddTagdata = new FormData();
              console.log('adding tags')
              AddTagdata.append('tag', tagIDs.get(String(req.body.payload.data.phase.id)));

              var AddTagconfig = {
                method: 'post',
                url: `https://app.asana.com/api/1.0/tasks/${req.body.payload.data.description}/addTag`,
                headers: {
                  'Authorization': `Bearer ${process.env.BEARER}`,
                  ...AddTagdata.getHeaders()
                },
                data: AddTagdata
              };

              axios(AddTagconfig).then((res) => {
                MainRes.send('Pending')
              }).catch((err) => { console.log(err) })
            }).catch((err) => {
              console.log(err)
            })
        }).catch((err) => {
          console.log(err)
        })
    } else {
      MainRes.send('No description')
    }
  } else {
    console.log('No defined State')
  }
});

// To post a new design
app.post("/designs", (req, Designres) => {
  const sendInfo = {
    title: req.body.title,
    product_category_id: Number(req.body.product_category_id),
    image: String(req.body.image),
    image_filename: String(req.body.image_filename),
    description: String(req.body.description.substr(req.body.description.lastIndexOf('/')+1)),
    primary_client_id: String(req.body.primary_client_id),
    is_expedited: req.body.is_expedited,
    upi: [String(makeid(8))]
  };

  console.log(sendInfo)

  var config = {
    method: "post",
    url: "https://api.affinitygateway.com/designs",    headers: {
      "X-Api-Key": process.env.X_API_KEY,
    },
    data: sendInfo,
  };

  axios(config)
    .then((res) => {
      
      dbconnection.query(`INSERT INTO asanatasks VALUES ('${sendInfo.description}', '${sendInfo.upi}', '${sendInfo.title}', '${sendInfo.product_category_id}', '${sendInfo.primary_client_id}')`, function (error, results, fields) {
        if (error){
          console.log(error.message)
        };
        var solutionset = Object.values(JSON.parse(JSON.stringify(results)));
        Designres.send({solution : solutionset})
      });
    })
    .catch((error) => {
      console.log(error);
    });
});

// To fetch SQL data
app.get('/sql', function (req, res) {
  var sqlSel = ``
  
  if(req.query.tblName === 'dtf' || req.query.tblName === 'screenprint' || req.query.tblName === 'embroidery' || req.query.tblName === 'schools' || req.query.tblName === 'sorority') {
    sqlSel = `Select * from ${req.query.tblName} order by 1`
  } else{
    sqlSel  = `Select * from ${req.query.tblName}`
  }
  
  dbconnection.query(sqlSel, function (error, results, fields) {
    if (error) throw error;
    var solutionset = Object.values(JSON.parse(JSON.stringify(results)));
    res.send({ solution: solutionset })
  });
});

app.post("/update", (req, resTable) => {
  console.log(`Update ${req.query.tblName} set ${req.query.updColumn} = ${req.query.newValue} where ${req.query.keyColumn} = '${req.query.keyValue}'`)

  dbconnection.query(`Update ${req.query.tblName} set ${req.query.updColumn} = "${req.query.newValue}" where ${req.query.keyColumn} = "${req.query.keyValue}"`, function (error, results, fields) {
    if (error) {
      console.log(error)
      resTable.send({ error: error })
    }
    console.log(results)
    var solutionset = Object.values(JSON.parse(JSON.stringify(results)));
    console.log(solutionset)
    resTable.send({ solution: solutionset })

  });
});

app.post("/insertSchool", (req, resTable) => {
  console.log(`Insert into schools values ('${req.query.newValue}')`)

  dbconnection.query(`Insert into schools values ('${req.query.newValue}')`, function (error, results, fields) {
    if (error) {
      console.log(error)
      resTable.send({ error: error })
    }
    console.log(results)
    var solutionset = Object.values(JSON.parse(JSON.stringify(results)));
    console.log(solutionset)
    resTable.send({ solution: solutionset })

  });
});

app.post("/insertSorority", (req, resTable) => {
  console.log(`Insert into sorority values ('${req.query.newValue}')`)

  dbconnection.query(`Insert into sorority values ('${req.query.newValue}')`, function (error, results, fields) {
    if (error) {
      console.log(error)
      resTable.send({ error: error })
    }
    console.log(results)
    var solutionset = Object.values(JSON.parse(JSON.stringify(results)));
    console.log(solutionset)
    resTable.send({ solution: solutionset })

  });
});


app.listen(process.env.PORT || 8080, () => console.log("Server is running..."));
