"""
DUMPING DATA FROM MONGO DB TO MYSQL
At every 4 hour interval
"""
from pymongo.mongo_client import MongoClient
from pymongo.server_api import ServerApi
from pymongo.collection import Collection
import pandas as pd
import mysql.connector
from sqlalchemy import create_engine
import os
import time

MONGODB_USER = os.environ.get("MONGODB_USER")
MONGODB_PWD = os.environ.get("MONGODB_PWD")
MONGODB_URI = os.environ.get("MONGODB_URI")
MYSQL_HOST = os.environ.get("MYSQL_HOST")
MYSQL_USER = os.environ.get("MYSQL_USER")
MYSQL_PWD = os.environ.get("MYSQL_PWD")

WAIT_TIME = 14400 # 4 hours

MONGODB_MAP = {
    1: {
        "database": "userinfo",
        "collection": "userdata",
        "exclude_fields": ["taskSubmissions"],
        "destination_table": "User_Data",
        "destination_database": "qbo"
    },
    2: {
        "database": "taskinfo",
        "collection": "taskdata",
        "exclude_fields": ["completed_by"],
        "destination_table": "Task_Data",
        "destination_database": "qbo"
    },
    3: {
        "database": "taskinfo",
        "collection": "taskdata",
        "include_fields": ["_id", "completed_by"],
        "destination_table": "Task_Completed_Info",
        "destination_database": "qbo",
        "field_naming_map": {
            "_id": "task_id",
            "completed_by": "user_id"
        },
        "relationship_map": {
            "column1": "_id",
            "column2": "completed_by",
            "relationship": "one_to_many" 
        }
    },
    4: {
        "database": "userinfo",
        "collection": "userdata",
        "include_fields": ["userId", "taskSubmissions"],
        "destination_table": "Task_Submissions_Info",
        "destination_database": "qbo",
        "field_naming_map": {
            "taskSubmissions": "task_id",
            "userId": "user_id"
        },
        "relationship_map": {
            "column1": "userId",
            "column2": "taskSubmissions",
            "relationship": "one_to_many" 
        }
    },
    5: {
        "database": "subinfo",
        "collection": "subdata",
        "exclude_fields": ["userdata"],
        "destination_table": "Submission_Data",
        "destination_database": "qbo"
    }
}

IDEAL_BATCH_SIZE = 10

def main():
    client = build_mongodb_client()

    for _, info in MONGODB_MAP.items():
        collection = info["collection"]
        database = info["database"]
        print(f"Processing Collection: {collection}...")
        collection_reader = client.get_database(database).get_collection(collection)
        data = extract_data_from_mongodb(collection_reader, info.get("exclude_fields", None), info.get("include_fields", None))
        if info.get("relationship_map", None):
            data = handle_relationship(data, info["relationship_map"])
        df = prepare_dataframe(data)
        if info.get("field_naming_map", None):
            df.rename(columns = info["field_naming_map"], inplace = True)
        dump_data_into_mysql(
            df,
            info["destination_database"],
            info["destination_table"]
        )
        print("Processing Completed!")
    client.close()

def handle_relationship(data: list[dict], relationship_map: dict):
    new_dataset = []
    relationship = relationship_map["relationship"]
    col1 = relationship_map["column1"]
    col2 = relationship_map["column2"]
    index = 1

    if relationship == "one_to_many":
        for entry in data:
            value1 = entry[col1]
            value2 = entry[col2]
            if value2:
                for value in value2:
                    new_dataset.append({
                        "id": index,
                        col1: value1,
                        col2: value
                    })
                    index += 1
    return new_dataset

def prepare_dataframe(dataset: list):
    df = pd.DataFrame(dataset)
    return df

def extract_data_from_mongodb(collection: Collection, exclude_fields: list = [], include_fields: list = []):
    print("collecting data...")
    total_records = collection.count_documents({})
    skip_value = 0
    dataset = []
    index = 1
    while skip_value < total_records:
        results = collection.find().skip(skip_value).limit(IDEAL_BATCH_SIZE).sort('_id')
        print('===========================================================')
        for data in results:
            if exclude_fields:
                for field in exclude_fields:
                    if field in data:
                        data.pop(field)
                if "_id" in data:
                    data["_id"] = str(data["_id"])
                dataset.append(data)
            elif include_fields:
                new_dict = {}
                for field in include_fields:
                    if field in data:
                        new_dict[field] = data.get(field)
                    else:
                        new_dict[field] = None
                if "_id" in new_dict:
                    new_dict["_id"] = str(new_dict["_id"])
                dataset.append(new_dict)
        print(f"[BATCH {index}] processed!")
        print('===========================================================')
        skip_value += IDEAL_BATCH_SIZE
        index += 1
    print(f"{total_records} records fetched!")
    return dataset

def build_mongodb_client():
    client = MongoClient(MONGODB_URI, server_api=ServerApi('1'))

    return client

def dump_data_into_mysql(df: pd.DataFrame, database: str, table: str):
    print(f"dumping data into {database}.{table}")
    conn = mysql.connector.connect(
        host=MYSQL_HOST,
        user=MYSQL_USER,
        password=MYSQL_PWD,
        database=database
    )
    engine = create_engine(f"mysql+mysqlconnector://{MYSQL_USER}:{MYSQL_PWD}@{MYSQL_HOST}/{database}")
    df.to_sql(table, con=engine, if_exists='replace', index=False)
    conn.close()

if __name__ == '__main__':
    while True:
        main()
        time.sleep(WAIT_TIME)